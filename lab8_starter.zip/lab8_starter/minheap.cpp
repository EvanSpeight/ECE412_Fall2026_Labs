/* ------------------------------------------------------------------ *
 * minheap.cpp -- ECE 412 Lab 8.  Your implementation of minheap.h.
 *
 * README section 4.2 has the specification, including the exact
 * rules for when siftUp and siftDown swap: the autograder checks the
 * two swap counters.
 * ------------------------------------------------------------------ */
#include "minheap.h"

MinHeap::MinHeap()
{
    /* TODO: initializer list: an empty a_, both counters 0 */

    /* PLACEHOLDER: delete these casts once your code uses the
     * members. */
    (void)upSwaps_; (void)downSwaps_;
}

void MinHeap::siftUp(int i)
{
    /* TODO: while a_[i] has a parent with a strictly LARGER key, swap
     * the two and count the swap.  An equal key stops the climb. */
    (void)i;
}

void MinHeap::siftDown(int i)
{
    /* TODO: pick the child with the smaller key (the LEFT one when
     * the two are equal).  If its key is strictly smaller than
     * a_[i]'s, swap, count the swap, and continue from the child. */
    (void)i;
}

void MinHeap::insert(int key, int value)
{
    /* TODO: append at the end of a_, then siftUp from there */
    (void)key; (void)value;
}

bool MinHeap::extractMin(int *key, int *value)
{
    /* TODO: report a_[0]; move the last entry to a_[0] (popBack),
     * then siftDown(0).  false, outputs untouched, when empty. */
    (void)key; (void)value;
    return false;
}

bool MinHeap::peekMin(int *key, int *value) const
{
    /* TODO */
    (void)key; (void)value;
    return false;
}

int MinHeap::size() const
{
    return 0;                             /* TODO */
}

bool MinHeap::empty() const
{
    return true;                          /* TODO */
}

long MinHeap::swapsUp() const
{
    return 0;                             /* TODO */
}

long MinHeap::swapsDown() const
{
    return 0;                             /* TODO */
}
