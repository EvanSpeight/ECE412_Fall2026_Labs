/* ------------------------------------------------------------------ *
 * minheap.h -- ECE 412 Lab 8.  MinHeap: a binary min-heap of
 *              (key, value) pairs, stored in your DynamicArray<T>.
 *
 * The public section and the data members are the specification.
 * Do not change them.  You MAY add private member functions.
 *
 * The heap orders entries by key only; the value rides along with
 * its key.  Dijkstra stores (distance, vertex); Prim stores
 * (edge weight, vertex).
 *
 *   a_[0] is the root.  The children of a_[i] are a_[2i+1] and
 *   a_[2i+2]; its parent is a_[(i-1)/2].
 *
 *            (2,a)                 a_:  (2,a) (5,b) (3,c) (9,d)
 *           /     \                       0     1     2     3
 *        (5,b)   (3,c)
 *        /
 *     (9,d)
 *
 * Invariant to keep true before and after every public function:
 *   I1. for every i > 0:  a_[(i-1)/2].key <= a_[i].key
 *
 * Sifting moves an entry by SWAPPING it with its parent (siftUp) or
 * with a child (siftDown), one level at a time.  The two counters
 * count those swaps (README section 4.2 gives the exact rules).
 *
 * No destructor, copy constructor or operator= is declared: a_ is a
 * DynamicArray, which already follows the Rule of Three, so the
 * compiler-generated ones are correct (the Rule of Zero).
 * ------------------------------------------------------------------ */
#ifndef MINHEAP_H
#define MINHEAP_H

#include "dynamic_array.h"

class MinHeap {
public:
    MinHeap();                            // empty; counters 0

    void insert(int key, int value);      // add, then siftUp
    bool extractMin(int *key, int *value);
                                          // remove the root: move the
                                          // last entry to a_[0], then
                                          // siftDown.  false (outputs
                                          // untouched) if empty
    bool peekMin(int *key, int *value) const;
                                          // false if empty

    int  size()  const;
    bool empty() const;

    // Instrumentation: swaps made over this object's lifetime.
    long swapsUp()   const;
    long swapsDown() const;

private:
    struct Entry {
        int key;
        int value;
    };

    DynamicArray<Entry> a_;               // the heap, a_[0] the root
    long upSwaps_;
    long downSwaps_;

    void siftUp(int i);                   // PROVIDED as declarations:
    void siftDown(int i);                 // write their bodies

    // Add private helper functions here if you want them.  Add no
    // data members.
};

#endif /* MINHEAP_H */
