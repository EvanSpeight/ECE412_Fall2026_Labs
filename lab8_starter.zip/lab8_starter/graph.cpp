/* ------------------------------------------------------------------ *
 * graph.cpp -- ECE 412 Lab 8.  Your implementation of graph.h.
 *
 * Every stub compiles and does nothing useful.  README section 4.1
 * has the full specification; the comment in each stub says what it
 * must do.
 *
 * Allowed here: std::string, your Deque<T> (deque.h), your MinHeap.
 * Not allowed: any standard container (including
 * std::priority_queue), std::sort (README section 7).
 * ------------------------------------------------------------------ */
#include "graph.h"

#include <cstddef>

#include "deque.h"
#include "minheap.h"

const int Graph::INF;            // the definition that goes with the
                                 // declaration in graph.h

/* ---- lifetime ---------------------------------------------------- */

Graph::Graph(int numVertices)
{
    /* TODO: initializer list (a negative count becomes 0), then
     * new Edge*[n_] with every head NULL.  No array when n_ is 0. */
    (void)numVertices; /* avoid unused warnings */

    /* PLACEHOLDER: clang (g++ on macOS) rejects a private member that
     * no function uses.  These casts use them until your code does.
     * Delete them. */
    (void)adj_; (void)n_; (void)m_;
}

Graph::~Graph()
{
    /* TODO: delete every Edge in every list, then the array */
}

Graph::Graph(const Graph &other)
{
    /* TODO: deep copy -- each list copied IN ORDER, same ids */
    (void)other; /* avoid unused parameter warning */
}

Graph &Graph::operator=(const Graph &other)
{
    /* TODO: self-assignment guard; release, then deep copy */
    (void)other; /* avoid unused parameter warning */
    return *this;
}

/* ---- building ---------------------------------------------------- */

bool Graph::addEdge(int u, int v, int weight)
{
    /* TODO: reject bad input (README 4.1).  Otherwise TWO new Edges,
     * one at the front of u's list and one at the front of v's list,
     * both with id m_; then m_++. */
    (void)u; (void)v; (void)weight; /* avoid unused warnings */
    return false;
}

/* ---- observers --------------------------------------------------- */

int Graph::vertexCount() const
{
    return 0;                             /* TODO */
}

int Graph::edgeCount() const
{
    return 0;                             /* TODO */
}

int Graph::degree(int v) const
{
    /* TODO: count v's list; -1 if v is out of range */
    (void)v;
    return -1;
}

int Graph::edgeWeight(int u, int v) const
{
    /* TODO: the smallest weight among u's edges to v; -1 if none */
    (void)u; (void)v;
    return -1;
}

int Graph::neighbors(int v, int *to, int *weight) const
{
    /* TODO: copy v's list into to[] and weight[], front first */
    (void)v; (void)to; (void)weight;
    return 0;
}

long Graph::listBytes() const
{
    /* TODO: the array of heads plus two Edges per passage */
    return 0;
}

long Graph::matrixBytes() const
{
    /* TODO: an n x n matrix of int */
    return 0;
}

/* ---- traversals -------------------------------------------------- */

void Graph::bfs(int src, int *dist, int *parent, const bool *closed) const
{
    /* TODO: every dist INF and parent -1; then dist[src] = 0 and a
     * Deque<int> as the FIFO frontier.  Skip a neighbor already
     * discovered or closed. */
    (void)src; (void)dist; (void)parent; (void)closed;
}

void Graph::dfs(int src, bool *visited) const
{
    /* TODO: mark every vertex reachable from src without passing
     * through one already visited.  Do not clear visited first. */
    (void)src; (void)visited;
}

int Graph::connectedComponents(int *componentOf) const
{
    /* TODO: label 0, 1, 2, ... in order of each component's smallest
     * vertex; return the number of components */
    (void)componentOf;
    return 0;
}

/* ---- Dijkstra ---------------------------------------------------- */

void Graph::dijkstra(int src, int *dist, int *parent, const bool *closed,
                     PathStats *stats) const
{
    /* TODO: README 4.3.  YOUR MinHeap of (distance, vertex), lazy
     * deletion:
     *
     *     while (pq.extractMin(&d, &u)) {
     *         if (done[u]) { stale++; continue; }  // stale entry
     *         done[u] = true;
     *         ... relax u's edges: an improved dist[v] is pushed as a
     *             NEW entry; the old one stays in the heap
     *     }
     *
     * Fill in *stats when stats is not NULL. */
    (void)src; (void)dist; (void)parent; (void)closed; (void)stats;
}

/* ---- minimum spanning tree (Prim) -------------------------------- */

int Graph::minimumSpanningTree(bool *inTree, int *treeEdges) const
{
    /* TODO: README 4.4.  Prim with YOUR MinHeap of (edge weight,
     * vertex) and lazy deletion -- your Dijkstra with one change:
     * key[v] is the weight of the cheapest single edge joining v to
     * the tree, and via[v] is that edge's id.
     *
     *     for each vertex s, 0 .. n-1, not yet in a tree:
     *         key[s] = 0; insert (0, s)
     *         while (pq.extractMin(&k, &u)) {
     *             if (done[u]) continue;           // stale entry
     *             done[u] = true;
     *             if (via[u] >= 0) ... edge via[u] joins the tree
     *             ... for each edge u--v with v not done:
     *                 if weight < key[v], set key[v] and via[v],
     *                 and insert (key[v], v)
     *         }
     *
     * Set every inTree[id], set *treeEdges, return the total weight. */
    (void)inTree;
    if (treeEdges != NULL) {
        *treeEdges = 0;
    }
    return 0;
}
