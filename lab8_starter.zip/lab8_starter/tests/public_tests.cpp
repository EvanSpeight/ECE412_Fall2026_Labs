/* ------------------------------------------------------------------ *
 * public_tests.cpp -- ECE 412 Lab 8 provided tests.  Do not edit or
 *                     submit this file.
 *
 *     ./public_tests            every group
 *     ./public_tests heap       one group: graph, traverse, heap,
 *                               dijkstra, mst, game
 *
 * Run it under valgrind as well.  The STL is used here, in the
 * tests, to build expected answers; it is not allowed in your files.
 * ------------------------------------------------------------------ */
#include <cstdio>
#include <cstring>
#include <iostream>
#include <sstream>
#include <string>
#include <vector>

#include "graph.h"
#include "minheap.h"
#include "game.h"

/* ---- harness ----------------------------------------------------- */

static int g_checks    = 0;
static int g_fails     = 0;
static int g_testFails = 0;

static void check_(bool cond, const char *expr, int line)
{
    g_checks++;
    if (!cond) {
        g_fails++;
        g_testFails++;
        std::cout << "    FAIL line " << line << ": " << expr << '\n';
    }
}
#define CHECK(cond) check_((cond), #cond, __LINE__)

static const int INF = Graph::INF;

/* The five-room map of maps/map_tiny.txt, as a Graph:
 *
 *        4        5        3
 *   [0]-----[1]------[3]------[4]
 *    |      /         |
 *   1|    2/          |8
 *    |    /           |
 *   [2]--------------+
 */
static void buildTiny(Graph &g)
{
    g.addEdge(0, 1, 4);                   // id 0
    g.addEdge(0, 2, 1);                   // id 1
    g.addEdge(2, 1, 2);                   // id 2
    g.addEdge(1, 3, 5);                   // id 3
    g.addEdge(2, 3, 8);                   // id 4
    g.addEdge(3, 4, 3);                   // id 5
}

static std::vector<int> neighborList(const Graph &g, int v)
{
    int d = g.degree(v);
    std::vector<int> to(d > 0 ? d : 1), w(d > 0 ? d : 1);
    g.neighbors(v, &to[0], &w[0]);
    to.resize(d > 0 ? d : 0);
    return to;
}

/* parent[] is consistent with dist[]: every reached vertex but the
 * source has a parent p with an edge p--v of weight dist[v]-dist[p]
 * (for BFS, weight is 1 hop: any edge). */
static bool parentsOk(const Graph &g, int src, const int *dist,
                      const int *parent, bool weighted)
{
    int n = g.vertexCount();
    for (int v = 0; v < n; v++) {
        if (v == src) {
            if (dist[v] != 0 || parent[v] != -1) return false;
            continue;
        }
        if (dist[v] == INF) {
            if (parent[v] != -1) return false;
            continue;
        }
        int p = parent[v];
        if (p < 0 || p >= n || dist[p] == INF) return false;
        if (weighted) {
            /* some p--v edge has exactly that weight */
            int d = g.degree(p);
            std::vector<int> to(d), w(d);
            g.neighbors(p, &to[0], &w[0]);
            bool found = false;
            for (int k = 0; k < d; k++) {
                if (to[k] == v && dist[p] + w[k] == dist[v]) found = true;
            }
            if (!found) return false;
        } else {
            if (g.edgeWeight(p, v) < 0 || dist[p] + 1 != dist[v]) {
                return false;
            }
        }
    }
    return true;
}

/* ================================================================== *
 * graph
 * ================================================================== */

static void graph_basic(void)
{
    Graph g(5);
    CHECK(g.vertexCount() == 5);
    CHECK(g.edgeCount() == 0);
    CHECK(g.degree(0) == 0);
    CHECK(g.degree(5) == -1 && g.degree(-1) == -1);
    CHECK(g.addEdge(0, 1, 4));
    CHECK(!g.addEdge(0, 0, 1));            // a loop
    CHECK(!g.addEdge(0, 5, 1));            // out of range
    CHECK(!g.addEdge(1, 2, 0));            // weight < 1
    CHECK(g.edgeCount() == 1);
    CHECK(g.degree(0) == 1 && g.degree(1) == 1);
    CHECK(g.edgeWeight(0, 1) == 4 && g.edgeWeight(1, 0) == 4);
    CHECK(g.edgeWeight(0, 2) == -1);
    CHECK(g.addEdge(1, 0, 2));             // a second, lighter passage
    CHECK(g.edgeWeight(0, 1) == 2 && g.degree(0) == 2);
    Graph z(0);
    CHECK(z.vertexCount() == 0 && z.edgeCount() == 0);
}

static void graph_lists(void)
{
    Graph g(5);
    buildTiny(g);
    CHECK(g.edgeCount() == 6);
    /* each new edge goes at the FRONT of both lists */
    int want0[] = { 2, 1 };
    int want1[] = { 3, 2, 0 };
    int want3[] = { 4, 2, 1 };
    CHECK(neighborList(g, 0) == std::vector<int>(want0, want0 + 2));
    CHECK(neighborList(g, 1) == std::vector<int>(want1, want1 + 3));
    CHECK(neighborList(g, 3) == std::vector<int>(want3, want3 + 3));
    CHECK(g.matrixBytes() == 5L * 5 * (long)sizeof(int));
    CHECK(g.listBytes() > 5L * (long)sizeof(void *));
}

static void graph_copy(void)
{
    Graph g(5);
    buildTiny(g);
    Graph c(g);
    CHECK(c.edgeCount() == 6 && neighborList(c, 1) == neighborList(g, 1));
    c.addEdge(0, 4, 7);
    CHECK(g.edgeCount() == 6 && g.edgeWeight(0, 4) == -1);
    Graph a(2);
    a = g;
    CHECK(a.vertexCount() == 5 && neighborList(a, 3) == neighborList(g, 3));
    Graph &alias = a;
    a = alias;
    CHECK(a.edgeCount() == 6 && a.edgeWeight(3, 4) == 3);
}

/* ================================================================== *
 * traverse
 * ================================================================== */

static void traverse_bfs(void)
{
    Graph g(6);                           // room 5 is not connected
    buildTiny(g);
    int dist[6], parent[6];
    g.bfs(0, dist, parent);
    int want[] = { 0, 1, 1, 2, 3, INF };
    CHECK(std::vector<int>(dist, dist + 6) ==
          std::vector<int>(want, want + 6));
    CHECK(parent[5] == -1);
    CHECK(parentsOk(g, 0, dist, parent, false));
}

static void traverse_closed(void)
{
    Graph g(5);
    buildTiny(g);
    bool closed[5] = { false, false, false, true, false };
    int dist[5], parent[5];
    g.bfs(0, dist, parent, closed);
    CHECK(dist[1] == 1 && dist[2] == 1);
    CHECK(dist[3] == INF && dist[4] == INF);   // only way is through 3
    g.bfs(3, dist, parent, closed);            // the source may be closed
    CHECK(dist[3] == 0 && dist[4] == 1 && dist[0] == 2);
}

static void traverse_components(void)
{
    Graph g(7);
    g.addEdge(1, 4, 1);
    g.addEdge(4, 6, 1);
    g.addEdge(2, 5, 1);
    int comp[7];
    CHECK(g.connectedComponents(comp) == 4);
    int want[] = { 0, 1, 2, 3, 1, 2, 1 };       // by smallest vertex
    CHECK(std::vector<int>(comp, comp + 7) ==
          std::vector<int>(want, want + 7));
    bool seen[7] = { false, false, false, false, false, false, false };
    g.dfs(6, seen);
    CHECK(seen[1] && seen[4] && seen[6] && !seen[0] && !seen[2]);
    bool pre[7] = { false, false, false, false, true, false, false };
    g.dfs(1, pre);                              // 4 already visited:
    CHECK(pre[1] && !pre[6]);                   // do not pass through
}

/* ================================================================== *
 * heap
 * ================================================================== */

static void heap_basic(void)
{
    MinHeap h;
    int k = -1, v = -1;
    CHECK(h.empty() && h.size() == 0);
    CHECK(!h.extractMin(&k, &v) && k == -1 && v == -1);
    CHECK(!h.peekMin(&k, &v));
    int keys[] = { 5, 3, 8, 1, 9, 2 };
    for (int i = 0; i < 6; i++) {
        h.insert(keys[i], 100 + keys[i]);
    }
    CHECK(h.size() == 6);
    CHECK(h.peekMin(&k, &v) && k == 1 && v == 101 && h.size() == 6);
    int out[6];
    bool paired = true;
    for (int i = 0; i < 6; i++) {
        h.extractMin(&k, &v);
        out[i] = k;
        paired = paired && v == 100 + k;
    }
    int want[] = { 1, 2, 3, 5, 8, 9 };
    CHECK(std::vector<int>(out, out + 6) ==
          std::vector<int>(want, want + 6));
    CHECK(paired);
    CHECK(h.empty());
}

/* Worked by hand in README section 4.2. */
static void heap_swaps(void)
{
    MinHeap h;
    int keys[] = { 5, 3, 8, 1, 9, 2 };
    for (int i = 0; i < 6; i++) {
        h.insert(keys[i], i);
    }
    CHECK(h.swapsUp() == 4);
    CHECK(h.swapsDown() == 0);
    int k, v;
    h.extractMin(&k, &v);                 // 1
    CHECK(h.swapsDown() == 1);
    h.extractMin(&k, &v);                 // 2
    CHECK(h.swapsDown() == 3);
    while (h.extractMin(&k, &v)) {
    }
    CHECK(h.swapsDown() == 4 && h.swapsUp() == 4);
    MinHeap e;                            // equal keys never swap
    for (int i = 0; i < 5; i++) e.insert(7, i);
    CHECK(e.swapsUp() == 0);
}

static void heap_copy(void)
{
    MinHeap a;
    a.insert(4, 0);
    a.insert(2, 1);
    MinHeap b(a);
    int k, v;
    b.extractMin(&k, &v);
    CHECK(k == 2 && a.size() == 2 && b.size() == 1);
    MinHeap c;
    c = a;
    c.insert(1, 9);
    CHECK(a.peekMin(&k, &v) && k == 2 && c.size() == 3);
}

/* ================================================================== *
 * dijkstra
 * ================================================================== */

static void dijkstra_tiny(void)
{
    Graph g(5);
    buildTiny(g);
    int dist[5], parent[5];
    g.dijkstra(0, dist, parent);
    int want[] = { 0, 3, 1, 8, 11 };
    CHECK(std::vector<int>(dist, dist + 5) ==
          std::vector<int>(want, want + 5));
    CHECK(parent[1] == 2 && parent[3] == 1 && parent[4] == 3);
    CHECK(parentsOk(g, 0, dist, parent, true));
}

/* s--a 1, s--b 5, a--b 1: b is pushed with 5, then improved to 2.
 * The (5, b) entry is stale when it comes out. */
static void dijkstra_stale(void)
{
    Graph g(3);
    g.addEdge(0, 1, 1);
    g.addEdge(0, 2, 5);
    g.addEdge(1, 2, 1);
    int dist[3], parent[3];
    PathStats s;
    g.dijkstra(0, dist, parent, NULL, &s);
    CHECK(dist[2] == 2 && parent[2] == 1);
    CHECK(s.settled == 3);
    CHECK(s.staleSkipped == 1);
    CHECK(s.pushes == s.settled + s.staleSkipped);
}

static void dijkstra_closed(void)
{
    Graph g(5);
    buildTiny(g);
    bool closed[5] = { false, false, true, false, false };
    int dist[5], parent[5];
    g.dijkstra(0, dist, parent, closed);
    CHECK(dist[2] == INF && dist[1] == 4 && dist[3] == 9 && dist[4] == 12);
}

/* ================================================================== *
 * mst
 * ================================================================== */

static void mst_tiny(void)
{
    Graph g(5);
    buildTiny(g);
    bool inTree[6];
    int count = -1;
    CHECK(g.minimumSpanningTree(inTree, &count) == 11);
    CHECK(count == 4);
    /* Prim from 0 adds 0-2 (1), 2-1 (2), 1-3 (5), 3-4 (3) */
    CHECK(!inTree[0] && inTree[1] && inTree[2] && inTree[3] &&
          !inTree[4] && inTree[5]);
    Graph f(4);                           // two components
    f.addEdge(0, 1, 3);
    f.addEdge(2, 3, 4);
    bool t2[2];
    CHECK(f.minimumSpanningTree(t2, &count) == 7 && count == 2);
}

static void mst_forest(void)
{
    /* Room 0 alone; a parallel pair 1-2; components {0}, {1,2,4},
     * {3,5}.  Prim must start a new tree at 1 and again at 3. */
    Graph g(6);
    g.addEdge(1, 2, 5);                   // id 0
    g.addEdge(1, 2, 2);                   // id 1: the cheaper twin
    g.addEdge(2, 4, 7);                   // id 2
    g.addEdge(3, 5, 1);                   // id 3
    bool inTree[4];
    int count = -1;
    CHECK(g.minimumSpanningTree(inTree, &count) == 10);
    CHECK(count == 3);                    // V - C = 6 - 3
    CHECK(!inTree[0] && inTree[1] && inTree[2] && inTree[3]);
    Graph lone(3);                        // no passages at all
    bool none[1];
    CHECK(lone.minimumSpanningTree(none, &count) == 0 && count == 0);
}

/* ================================================================== *
 * game
 * ================================================================== */

static const char *TINY =
    "rooms 5\n"
    "room 0 Gate\nroom 1 Hall\nroom 2 Pit\nroom 3 Cellar\nroom 4 Stairs\n"
    "passage 0 1 4\npassage 0 2 1\npassage 2 1 2\n"
    "passage 1 3 5\npassage 2 3 8\npassage 3 4 3\n"
    "entrance 0\nexit 4\n"
    "door 3\nkey 1 3 rusty-key\nitem 2 copper-coin 5\n";

static void game_doors(void)
{
    Dungeon d;
    std::string err;
    CHECK(d.loadText(TINY, &err));
    int rounds = 0;
    CHECK(d.validateDoors(&rounds) && rounds == 2);
    CHECK(d.doorCount() == 1 && d.isLocked(3) && !d.isLocked(1));
    const char *bad =
        "rooms 4\npassage 0 1 1\npassage 1 2 1\npassage 2 3 1\n"
        "entrance 0\nexit 3\ndoor 2\nkey 2 2 lost-key\n";
    Dungeon b;
    CHECK(!b.loadText(bad, &err));        // key behind its own door
}

static void game_play(void)
{
    Dungeon d;
    std::string err;
    CHECK(d.loadText(TINY, &err));
    CHECK(d.playerRoom() == 0 && d.state() == PLAYING);
    CHECK(!d.movePlayer(3));              // no passage 0--3
    CHECK(d.movePlayer(1));
    CHECK(!d.movePlayer(3));              // locked, no key yet
    CHECK(!d.pickUp("copper-coin"));      // it is in room 2
    CHECK(d.pickUp("rusty-key") && d.carrying("rusty-key"));
    CHECK(!d.pickUp("rusty-key"));        // already carried
    CHECK(d.movePlayer(3) && !d.isLocked(3));
    CHECK(d.movePlayer(4) && d.state() == WON);
    CHECK(d.score() == 100);
    CHECK(!d.movePlayer(3));              // game over
}

/* Two routes from the monster (0) to the player (3): 0-1-3 costs 20,
 * 0-2-4-3 costs 3.  BFS would take the first; Dijkstra the second. */
static void game_monster(void)
{
    const char *m =
        "rooms 6\n"
        "passage 0 1 10\npassage 1 3 10\n"
        "passage 0 2 1\npassage 2 4 1\npassage 4 3 1\npassage 3 5 1\n"
        "entrance 3\nexit 5\nmonster 0\n";
    Dungeon d;
    std::string err;
    CHECK(d.loadText(m, &err));
    CHECK(d.monsterCount() == 1 && d.monsterRoom(0) == 0);
    CHECK(d.monsterStep(0) == 2);
    CHECK(d.monsterStep(0) == 4);
    CHECK(d.monsterStep(0) == 3 && d.state() == LOST);
}

static void game_scores(void)
{
    Dungeon d;
    CHECK(d.scoreCount() == 0 && d.scoreHeight() == -1);
    CHECK(d.addScore("cy", 40));
    CHECK(d.addScore("ana", 90));
    CHECK(d.addScore("bo", 90));          // a tie, a different name
    CHECK(!d.addScore("bo", 90));         // the same entry twice
    CHECK(d.scoreCount() == 3);
    std::ostringstream out;
    d.printScores(out);
    std::string s = out.str();
    std::size_t a = s.find("ana"), b = s.find("bo"), c = s.find("cy");
    CHECK(a != std::string::npos && a < b && b < c);
    CHECK(ScoreEntry(90, "zed") < ScoreEntry(40, "abe"));
    CHECK(ScoreEntry(90, "abe") < ScoreEntry(90, "zed"));
}

static void game_stats(void)
{
    Dungeon d;
    std::string err;
    CHECK(d.loadText(TINY, &err));
    std::ostringstream out;
    d.printStats(out);
    std::string s = out.str();
    CHECK(s.find("rooms (V):") != std::string::npos);
    CHECK(s.find("MST total weight:") != std::string::npos);
    CHECK(s.find("Dijkstra distance entrance to exit:") !=
          std::string::npos);
}

/* ================================================================== *
 * runner
 * ================================================================== */

struct Test {
    const char *group;
    const char *name;
    void (*fn)(void);
};

static const Test TESTS[] = {
    { "graph",    "graph_basic",         graph_basic         },
    { "graph",    "graph_lists",         graph_lists         },
    { "graph",    "graph_copy",          graph_copy          },
    { "traverse", "traverse_bfs",        traverse_bfs        },
    { "traverse", "traverse_closed",     traverse_closed     },
    { "traverse", "traverse_components", traverse_components },
    { "heap",     "heap_basic",          heap_basic          },
    { "heap",     "heap_swaps",          heap_swaps          },
    { "heap",     "heap_copy",           heap_copy           },
    { "dijkstra", "dijkstra_tiny",       dijkstra_tiny       },
    { "dijkstra", "dijkstra_stale",      dijkstra_stale      },
    { "dijkstra", "dijkstra_closed",     dijkstra_closed     },
    { "mst",      "mst_tiny",            mst_tiny            },
    { "mst",      "mst_forest",          mst_forest          },
    { "game",     "game_doors",          game_doors          },
    { "game",     "game_play",           game_play           },
    { "game",     "game_monster",        game_monster        },
    { "game",     "game_scores",         game_scores         },
    { "game",     "game_stats",          game_stats          },
};
static const int NTESTS = (int)(sizeof TESTS / sizeof TESTS[0]);

int main(int argc, char *argv[])
{
    const char *only = (argc > 1) ? argv[1] : NULL;
    int ran = 0, passed = 0;

    std::cout.setf(std::ios::unitbuf);   /* output survives a crash */

    for (int i = 0; i < NTESTS; i++) {
        if (only != NULL && std::strcmp(only, TESTS[i].group) != 0) {
            continue;
        }
        g_testFails = 0;
        std::cout << TESTS[i].name << '\n';
        TESTS[i].fn();
        ran++;
        if (g_testFails == 0) {
            passed++;
        }
    }

    if (ran == 0) {
        std::cout << "no tests in group \"" << only << "\"; groups are "
                  << "graph, traverse, heap, dijkstra, mst, game\n";
        return 2;
    }
    std::cout << '\n' << passed << " of " << ran << " tests passed ("
              << g_checks << " checks, " << g_fails << " failed)\n";
    return (passed == ran) ? 0 : 1;
}
