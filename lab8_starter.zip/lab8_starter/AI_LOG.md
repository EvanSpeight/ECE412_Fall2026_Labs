# AI log -- <your name>, <your EID>

Delete the bracketed instructions as you go.

[Required, even if the answer is "none". For each substantive use of an assistant: what you asked, what you got, what you changed and why. Say which parts of the game an assistant wrote (scaffolding, map files, moves files), and whether you used one on `graph.cpp`, `minheap.cpp` or the `TODO` functions in `game.cpp`. If an assistant reported a bug or reviewed your `--stats` numbers, say whether its report was right and how you checked.]
