/* ------------------------------------------------------------------ *
 * game.cpp -- ECE 412 Lab 8.  Your implementation of game.h.
 *
 * The functions marked PROVIDED are written for you: the map loader,
 * the simple accessors, render(), and the score file.  Read them --
 * they show how the Dungeon's members fit together -- but you should
 * not need to change them.  Everything marked TODO is yours.
 *
 * README section 4.5 has the rules of the game.
 * ------------------------------------------------------------------ */
#include "game.h"

#include <cstdio>
#include <fstream>
#include <iostream>
#include <sstream>

/* ================================================================== *
 *  ScoreEntry
 * ================================================================== */

ScoreEntry::ScoreEntry() : points(0), name()
{
}

ScoreEntry::ScoreEntry(int p, const std::string &n) : points(p), name(n)
{
}

bool ScoreEntry::operator<(const ScoreEntry &other) const
{
    /* TODO: more points sorts FIRST; equal points sort by name.  Two
     * entries are equal (to the BST) only if both fields match. */
    (void)other;
    return false;
}

/* ================================================================== *
 *  Lifetime (PROVIDED)
 * ================================================================== */

Dungeon::Dungeon()
    : graph_(NULL), names_(), locked_(NULL), doors_(0), items_(),
      catalog_(), monsters_(), turnQueue_(), scores_(), entrance_(-1),
      exit_(-1), player_(-1), points_(0), turns_(0), state_(PLAYING)
{
}

Dungeon::~Dungeon()
{
    delete graph_;
    delete[] locked_;
}

/* Back to an unloaded dungeon.  The high-score table is kept: it
 * belongs to the player, not to the map. */
void Dungeon::reset()
{
    delete graph_;
    graph_ = NULL;
    delete[] locked_;
    locked_ = NULL;
    doors_ = 0;
    names_.clear();
    items_.clear();
    catalog_ = HashMap();
    monsters_.clear();
    turnQueue_.clear();
    entrance_ = exit_ = player_ = -1;
    points_ = turns_ = 0;
    state_ = PLAYING;
}

/* ================================================================== *
 *  Loading (PROVIDED)
 * ================================================================== */

bool Dungeon::loadFile(const char *path, std::string *error)
{
    std::ifstream in(path);
    if (!in) {
        reset();
        if (error != NULL) {
            *error = std::string("cannot open ") + path;
        }
        return false;
    }
    return parse(in, error);
}

bool Dungeon::loadText(const std::string &text, std::string *error)
{
    std::istringstream in(text);
    return parse(in, error);
}

static std::string restOfLine(std::istringstream &ss)
{
    std::string rest;
    std::getline(ss, rest);
    std::size_t a = rest.find_first_not_of(" \t\r");
    if (a == std::string::npos) {
        return "";
    }
    std::size_t b = rest.find_last_not_of(" \t\r");
    return rest.substr(a, b - a + 1);
}

/* The map format is in README section 4.5. */
bool Dungeon::parse(std::istream &in, std::string *error)
{
    reset();
    std::string line, word, msg;
    int lineno = 0;
    int n = -1;
    while (msg.empty() && std::getline(in, line)) {
        lineno++;
        std::istringstream ss(line);
        if (!(ss >> word) || word[0] == '#') {
            continue;                     // blank line or comment
        }
        std::ostringstream where;
        where << "line " << lineno << ": ";
        if (word == "rooms") {
            if (n >= 0) {
                msg = where.str() + "a second 'rooms' line";
            } else if (!(ss >> n) || n < 1) {
                msg = where.str() + "rooms needs a count >= 1";
            } else {
                graph_ = new Graph(n);
                locked_ = new bool[n];
                for (int r = 0; r < n; r++) {
                    locked_[r] = false;
                    std::ostringstream nm;
                    nm << "Room " << r;
                    names_.pushBack(nm.str());
                }
            }
            continue;
        }
        if (n < 0) {
            msg = where.str() + "the first line must be 'rooms N'";
            continue;
        }
        int a = -1, b = -1, c = -1;
        if (word == "room") {
            if (!(ss >> a) || a < 0 || a >= n) {
                msg = where.str() + "room: bad room number";
            } else {
                names_[a] = restOfLine(ss);
            }
        } else if (word == "passage") {
            if (!(ss >> a >> b >> c) || !graph_->addEdge(a, b, c)) {
                msg = where.str() + "passage: needs two different rooms "
                      "and a weight >= 1";
            }
        } else if (word == "entrance" || word == "exit") {
            if (!(ss >> a) || a < 0 || a >= n) {
                msg = where.str() + word + ": bad room number";
            } else if (word == "entrance") {
                entrance_ = a;
            } else {
                exit_ = a;
            }
        } else if (word == "door") {
            if (!(ss >> a) || a < 0 || a >= n) {
                msg = where.str() + "door: bad room number";
            } else if (locked_[a]) {
                msg = where.str() + "door: room already has a door";
            } else {
                locked_[a] = true;
                doors_++;
            }
        } else if (word == "key" || word == "item") {
            Item it;
            bool ok = (ss >> a) && a >= 0 && a < n;
            if (word == "key") {
                ok = ok && (ss >> b >> it.name) && b >= 0 && b < n;
                it.opens = b;
            } else {
                ok = ok && (ss >> it.name >> c) && c >= 0;
                it.points = c;
            }
            it.room = a;
            if (!ok) {
                msg = where.str() + word + ": bad line";
            } else if (!catalog_.insert(it.name, (int)items_.size())) {
                msg = where.str() + "two items named " + it.name;
            } else {
                items_.pushBack(it);
            }
        } else if (word == "monster") {
            if (!(ss >> a) || a < 0 || a >= n) {
                msg = where.str() + "monster: bad room number";
            } else {
                monsters_.pushBack(a);
            }
        } else {
            msg = where.str() + "unknown keyword '" + word + "'";
        }
    }

    /* Whole-map checks. */
    if (msg.empty() && n < 0) {
        msg = "empty map";
    }
    if (msg.empty() && (entrance_ < 0 || exit_ < 0 || entrance_ == exit_)) {
        msg = "the map needs an entrance and a different exit";
    }
    if (msg.empty() && locked_[entrance_]) {
        msg = "the entrance cannot be locked";
    }
    for (int r = 0; msg.empty() && r < n; r++) {
        int keys = 0;
        for (std::size_t i = 0; i < items_.size(); i++) {
            if (items_[i].opens == r) {
                keys++;
            }
        }
        if (locked_[r] && keys != 1) {
            msg = "door " + names_[r] + " needs exactly one key";
        } else if (!locked_[r] && keys > 0) {
            msg = "a key opens " + names_[r] + ", which has no door";
        }
    }
    for (std::size_t i = 0; msg.empty() && i < monsters_.size(); i++) {
        int m = monsters_[i];
        if (m == entrance_ || locked_[m]) {
            msg = "a monster cannot start at the entrance or behind a door";
        }
    }
    if (msg.empty()) {
        player_ = entrance_;
        for (std::size_t i = 0; i < monsters_.size(); i++) {
            turnQueue_.pushBack((int)i);
        }
        int rounds = 0;
        if (!validateDoors(&rounds)) {
            msg = "the doors cannot all be opened and the exit reached "
                  "(is a key behind its own door?)";
        }
    }
    if (!msg.empty()) {
        reset();
        if (error != NULL) {
            *error = msg;
        }
        return false;
    }
    return true;
}

/* ================================================================== *
 *  The map (PROVIDED)
 * ================================================================== */

int Dungeon::roomCount() const
{
    return graph_ == NULL ? 0 : graph_->vertexCount();
}

/* PROVIDED */
const std::string &Dungeon::roomName(int room) const
{
    static const std::string none = "?";
    if (room < 0 || room >= (int)names_.size()) {
        return none;
    }
    return names_[room];
}

int Dungeon::entrance() const
{
    return entrance_;
}

int Dungeon::exitRoom() const
{
    return exit_;
}

const Graph &Dungeon::graph() const
{
    return *graph_;
}

/* ================================================================== *
 *  Locked doors
 * ================================================================== */

/* Called by parse(): a map it returns false for is rejected. */
bool Dungeon::validateDoors(int *rounds) const
{
    /* TODO (README 4.5): repeated BFS from the entrance with the
     * locked rooms closed.  After each BFS, open every closed door
     * whose key it reached (or that the player carries).  Stop after
     * a round that opens nothing.  *rounds = the number of BFS runs.
     * True if every door opened and the exit was reached.
     *
     * The stub returns true so that maps load before you write it. */
    if (rounds != NULL) {
        *rounds = 0;
    }
    return true;
}

int Dungeon::doorCount() const
{
    return 0;                             /* TODO */
}

bool Dungeon::isLocked(int room) const
{
    /* TODO: locked right now; false if room is out of range */
    (void)room;
    return false;
}

/* ================================================================== *
 *  The player
 * ================================================================== */

/* PROVIDED */
int Dungeon::playerRoom() const
{
    return player_;
}

bool Dungeon::movePlayer(int room)
{
    /* TODO (README 4.5): false if the game is over or no passage
     * joins playerRoom() and room.  A locked room needs its key
     * carried; it then unlocks for good.  Entering a monster's room
     * loses; entering the exit wins. */
    (void)room;
    return false;
}

bool Dungeon::pickUp(const std::string &item)
{
    /* TODO: look the name up in catalog_ (your HashMap).  The item
     * must lie in the player's room and not be carried yet.  Add its
     * points. */
    (void)item;
    return false;
}

bool Dungeon::carrying(const std::string &item) const
{
    /* TODO */
    (void)item;
    return false;
}

int Dungeon::score() const
{
    return 0;                             /* TODO */
}

int Dungeon::turns() const
{
    return 0;                             /* TODO */
}

GameState Dungeon::state() const
{
    return PLAYING;                       /* TODO */
}

/* ================================================================== *
 *  Monsters
 * ================================================================== */

int Dungeon::monsterCount() const
{
    return 0;                             /* TODO */
}

int Dungeon::monsterRoom(int i) const
{
    /* TODO: -1 if i is out of range */
    (void)i;
    return -1;
}

int Dungeon::monsterStep(int i)
{
    /* TODO (README 4.5): Dijkstra from the monster's room with the
     * locked rooms closed.  Follow parent[] BACKWARDS from the player
     * to the room whose parent is the monster's room: that is the
     * step.  Stay put if the player cannot be reached.  Catching the
     * player loses the game.  Return the monster's room. */
    (void)i;
    return -1;
}

void Dungeon::endTurn()
{
    /* TODO: nothing once the game is over.  On an even turns(),
     * every monster acts once: popFront an index from turnQueue_,
     * monsterStep it, pushBack it.  Then turns() goes up by one. */
}

/* ================================================================== *
 *  High scores
 * ================================================================== */

bool Dungeon::addScore(const std::string &name, int points)
{
    /* TODO: insert into scores_ (your BST<ScoreEntry>) */
    (void)name; (void)points;
    return false;
}

int Dungeon::scoreCount() const
{
    return 0;                             /* TODO */
}

int Dungeon::scoreHeight() const
{
    return -1;                            /* TODO */
}

void Dungeon::printScores(std::ostream &out) const
{
    /* TODO: one line per entry, highest first, in this format:
     *
     *       1.   140  ana
     *       2.    95  bo
     *
     * scores_.inorder() takes a plain function pointer; saveScores()
     * below shows how its visitor reaches a stream. */
    (void)out;
}

/* PROVIDED: one entry per line, "points name". */
bool Dungeon::loadScores(const char *path)
{
    std::ifstream in(path);
    if (!in) {
        return false;
    }
    std::string line;
    while (std::getline(in, line)) {
        std::istringstream ss(line);
        int p;
        if (ss >> p) {
            std::string name = restOfLine(ss);
            if (!name.empty()) {
                addScore(name, p);
            }
        }
    }
    return true;
}

static std::ostream *g_saveOut = NULL;

static void saveOne(const ScoreEntry &e)
{
    *g_saveOut << e.points << ' ' << e.name << '\n';
}

/* PROVIDED */
bool Dungeon::saveScores(const char *path) const
{
    std::ofstream out(path);
    if (!out) {
        return false;
    }
    g_saveOut = &out;
    scores_.inorder(saveOne);
    return true;
}

/* ================================================================== *
 *  Output
 * ================================================================== */

/* PROVIDED: the current room, its items, its exits, how far the exit
 * is (BFS through unlocked rooms), and where the monsters are. */
void Dungeon::render(std::ostream &out) const
{
    if (graph_ == NULL) {
        out << "(no dungeon loaded)\n";
        return;
    }
    int n = roomCount();
    out << "\n== [" << player_ << "] " << roomName(player_) << " ";
    for (int k = (int)roomName(player_).size(); k < 50; k++) {
        out << '=';
    }
    out << '\n';

    out << "Items:    ";
    bool any = false;
    for (std::size_t i = 0; i < items_.size(); i++) {
        const Item &it = items_[i];
        if (!it.carried && it.room == player_) {
            out << (any ? ", " : "") << it.name;
            if (it.opens >= 0) {
                out << " (key)";
            } else {
                out << " (" << it.points << ")";
            }
            any = true;
        }
    }
    out << (any ? "\n" : "none\n");

    int d = graph_->degree(player_);
    int *to = new int[d > 0 ? d : 1];
    int *w = new int[d > 0 ? d : 1];
    graph_->neighbors(player_, to, w);
    out << "Exits:    ";
    for (int k = 0; k < d; k++) {
        out << (k ? "   " : "") << "[" << to[k] << "] "
            << roomName(to[k]) << " (" << w[k]
            << (locked_[to[k]] ? ", locked" : "") << ")";
    }
    out << (d ? "\n" : "none\n");
    delete[] to;
    delete[] w;

    int *dist = new int[n];
    int *parent = new int[n];
    graph_->bfs(player_, dist, parent, locked_);
    if (dist[exit_] == Graph::INF) {
        out << "The exit is behind a locked door.\n";
    } else {
        out << "The exit is " << dist[exit_] << " passage"
            << (dist[exit_] == 1 ? "" : "s") << " away.\n";
    }
    for (std::size_t i = 0; i < monsters_.size(); i++) {
        int m = monsters_[i];
        out << "Monster " << i << " is in [" << m << "] " << roomName(m);
        if (dist[m] != Graph::INF) {
            out << ", " << dist[m] << " passage"
                << (dist[m] == 1 ? "" : "s") << " away";
        }
        out << ".\n";
    }
    delete[] dist;
    delete[] parent;

    out << "Score " << points_ << "   Turn " << turns_ << "   Carrying: ";
    any = false;
    for (std::size_t i = 0; i < items_.size(); i++) {
        if (items_[i].carried) {
            out << (any ? ", " : "") << items_[i].name;
            any = true;
        }
    }
    out << (any ? "\n" : "nothing\n");
}

/* ---- --stats ----------------------------------------------------- */

void Dungeon::printStats(std::ostream &out) const
{
    /* TODO (README 4.6): one "label: value" line per measurement, in
     * the order and with the labels the README gives. */
    out << "(printStats is not written yet)\n";
}
