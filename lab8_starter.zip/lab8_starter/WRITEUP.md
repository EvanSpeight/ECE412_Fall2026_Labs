# Lab 8 writeup -- <your name>, <your EID>

Delete the bracketed instructions as you go. Keep each answer short and about your own code and your own numbers.

## How to build and play

[A few lines: how to build, how to start a game on your map, the commands, and what is on your map (where the doors and keys are, where the monsters start). A TA should be able to play your map from this section alone.]

## Measurements

[Paste the output of `./dungeon --stats maps/map_main.txt`.]

```
```

[Paste the output of `./dungeon --stats maps/map_mine.txt`.]

```
```

**Memory.** [For your map: the adjacency-list size and the adjacency-matrix size from V and E, with the arithmetic, checked against `--stats`. Why the list wins for a dungeon, and roughly how many passages your map would need before the matrix used less memory.]

**Stale entries.** [`Dijkstra stale skipped` for both maps, and where those entries came from.]

**MST.** [The MST edge count for both maps, shown to equal V − C.]

**Score table.** [After at least five games (or entries added to `scores.txt` by hand): the table's size and height next to ⌊log₂ n⌋, and what the order of arrival did to the height.]

## Questions

1. **BFS and Dijkstra choose different paths.** [Two rooms on your own map; both paths with their hop counts and total weights; what each algorithm optimizes.]

2. **The monster.** [Why Dijkstra runs again every turn; what goes wrong if it runs once at startup; the cost of one turn with k monsters, with your heap and with a linear scan; how one Dijkstra from the player could serve every monster.]

3. **The door check.** [Why one BFS cannot decide; the largest number of rounds for D doors and the cost of the whole check; the rounds for `map_main.txt`, explained from the map.]

4. **A structure, against an alternative.** [One structure, one specific alternative, the deciding operation. The recursion depth of your `dfs` on a corridor of V rooms, and what it would mean for a corridor of a million rooms.]

5. **Your containers under load.** [Which Lab 6 or Lab 7 container needed fixing, the bug, and how you found it. If none did: which tests and runs exercised each one, and your evidence.]

## valgrind

[Paste the HEAP SUMMARY and ERROR SUMMARY lines from `make valgrind` (both runs).]

```
```
