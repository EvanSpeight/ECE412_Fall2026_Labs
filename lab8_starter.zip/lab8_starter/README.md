# ECE 412 -- Lab 8: Graph Dungeon (Capstone)

| | |
|---|---|
| **Assigned** | Fri Nov 20 |
| **Due** | **Mon Dec 7, 11:59 pm** -- upload to **Gradescope and Canvas** |
| **Weight** | 4.5% of Total Grade |
| **Builds on** | L13 (deque, templates) · L18 (hash tables) · L19 (BSTs) · L20 (heaps) · L21--L22 (graphs) · Lab 6 (`Deque<T>`, `DynamicArray<T>`) · Lab 7 (`HashMap`, `BST<T>`) |
| **Language** | C++11 -- `g++ -std=c++11 -Wall -Wextra -Werror -g` |
| **Work** | Individual |

Thanksgiving break (Nov 23--28) falls inside this window: two and a half calendar weeks, about eight working days. Everything the lab uses is taught by Thu Nov 19. The milestones in Section 3 are not graded; they are the schedule that finishes on time.

## 1. What you will build

A playable text dungeon in which **the dungeon is a graph**. Rooms are vertices, passages are weighted edges, and each feature of the game is an algorithm or a container you wrote:

| Game feature | Structure / algorithm | Where |
|---|---|---|
| The dungeon map | adjacency lists | `Graph` |
| "How far is the exit?", the `map` command | **BFS**, its frontier a `Deque<int>` | `Graph::bfs` |
| A monster chases the player along the cheapest route | **Dijkstra** with **your binary heap** | `Graph::dijkstra`, `MinHeap` |
| Which rooms can be reached at all | **connected components** (depth-first) | `Graph::connectedComponents` |
| Locked doors whose keys lie elsewhere | **repeated BFS** with the locked rooms closed | `Dungeon::validateDoors` |
| Lit corridors and dark shortcuts | **minimum spanning tree**: **Prim** with your binary heap | `Graph::minimumSpanningTree`, `MinHeap` |
| Item catalog by name | **hash table** | your Lab 7 `HashMap` |
| High-score table, always in order | **binary search tree** | your Lab 7 `BST<T>` |
| The order the monsters act in | **deque** | your Lab 6 `Deque<T>` |
| Room names, items, monsters, heap storage | **growable array** | your Lab 6 `DynamicArray<T>` |

**You reuse your own containers.** `HashMap` and `BST<T>` from Lab 7, `Deque<T>` and `DynamicArray<T>` from Lab 6. If one of them has a bug, fix it here: the writeup asks what you had to fix.

**No STL containers** in any file you submit. `std::string` is allowed; `std::vector`, `std::priority_queue` and the rest are not (Section 7).

```text
  Part of maps/map_tiny.txt as a Graph:

         4        5        3                adj_
    [0]-----[1]------[3]------[4]            [0] -> (2,w1) -> (1,w4)
     |      /         |                      [1] -> (3,w5) -> (2,w2) -> (0,w4)
    1|    2/          |8                     [2] -> (3,w8) -> (1,w2) -> (0,w1)
     |    /           |                      [3] -> (4,w3) -> (2,w8) -> (1,w5)
    [2]--------------+                       [4] -> (3,w3)
```

The lab has five parts and a writeup:

- **`Graph`** (Section 4.1): adjacency lists, the Rule of Three, BFS, DFS, connected components.
- **`MinHeap`** (4.2): an array-backed binary heap of (key, value) pairs that counts its swaps.
- **Dijkstra** (4.3), using your `MinHeap` with lazy deletion.
- **Prim** (4.4): the minimum spanning tree, with your `MinHeap` again.
- **The game** (4.5) and **`--stats`** (4.6): locked doors, items, the monster, turns, high scores, and the measurements.
- **`WRITEUP.md`** (Section 5): your measurements and five questions.

## 2. What you start with

| File | Status | What you do with it |
|---|---|---|
| `graph.h` | declaration | **Do not change** the public section or the data members. You may add private member functions. |
| `graph.cpp` | stubs | Write every function. |
| `minheap.h` | declaration | **Do not change** the public section or the data members. You may add private member functions. |
| `minheap.cpp` | stubs | Write every function. |
| `game.h` | declaration | **Do not change** the public section. You may add private member functions **and** private data members. |
| `game.cpp` | partial | The loader, `render`, the accessors and the score file are written (marked `PROVIDED`). Write every function marked `TODO`. |
| `main.cpp` | complete | The command loop. You may extend it; keep its options working. |
| `Makefile` | complete | Builds `./dungeon`, `./public_tests`, and runs valgrind. |
| `maps/` | complete | `map_tiny.txt` (5 rooms), `map_main.txt` (32 rooms), `map_bad_door.txt` (must be rejected), `moves_main.txt` (a scripted game). |
| `tests/public_tests.cpp` | complete | A provided test suite. Do not edit or submit it. |
| `WRITEUP.md`, `AI_LOG.md` | templates | Fill in. |

**From your own Labs 6 and 7**, copy these five files into this folder before anything else: `deque.h`, `dynamic_array.h`, `hashmap.h`, `hashmap.cpp`, `bst.h`. Until they are here, nothing builds.

The class declarations are the specification: the autograder compiles its own tests against them. With your Lab 6 and 7 files in place, the stubs compile clean with the course flags (with g++ and with clang) and do nothing useful, so every test fails until you write the code. No map loads until `Graph::addEdge` works.

## 3. How to proceed

Work in this order. Each step ends with a test you can run before you move on. `./public_tests` runs the provided tests; give it a group name (`graph`, `traverse`, `heap`, `dijkstra`, `mst`, `game`) to run only that group.

### Step 0 -- Your containers

1. Copy `deque.h`, `dynamic_array.h`, `hashmap.h`, `hashmap.cpp` and `bst.h` from your Lab 6 and Lab 7 folders.
2. Run `make` and `make check`. Everything should compile with no warnings, and the tests should fail.
3. If Lab 6's or Lab 7's autograder or valgrind found a problem in one of them, fix it now. Note what you fixed: question 5 of the writeup asks.

**Done when:** `make` builds `./dungeon` and `./public_tests` with no warnings.

### Step 1 -- `Graph`: lists and BFS

Write the constructor, the destructor, `addEdge`, the observers, `neighbors`, `listBytes`, `matrixBytes`, `bfs`, `dfs` and `connectedComponents` (Section 4.1). Then the copy constructor and `operator=`.

**Done when:** `./public_tests graph` and `./public_tests traverse` pass under valgrind, and `./dungeon maps/map_tiny.txt` loads and shows the first room.

### Step 2 -- `MinHeap`

Write `minheap.cpp` (Section 4.2). Work the example in Section 4.2 by hand before you run the test.

**Done when:** `./public_tests heap` passes.

### Step 3 -- Dijkstra, Prim and the monster

Write `Graph::dijkstra` (Section 4.3), then `Graph::minimumSpanningTree` (Section 4.4), which is the same loop with one change. Then write `monsterStep`, `endTurn`, `movePlayer` and the small accessors in `game.cpp` (Section 4.5).

**Done when:** `./public_tests dijkstra` and `./public_tests mst` pass, and in `./dungeon maps/map_main.txt` a monster walks toward you along the cheap passages.

### Step 4 -- Doors, items, scores, `--stats`

Write `validateDoors`, `pickUp`, `carrying`, `ScoreEntry::operator<`, the score functions and `printStats`.

**Done when:** `make check` passes in full, `./dungeon maps/map_bad_door.txt` is rejected, and `make valgrind` reports no errors.

### Step 5 -- Your own map and the writeup

Write `maps/map_mine.txt` (Section 4.5) and fill in `WRITEUP.md` (Section 5).

### Step 6 -- Submit

Work through the checklist in Section 9, then submit to Gradescope and Canvas.

### Milestones

| By | Have working |
|---|---|
| **Sun Nov 22** | Step 0; `Graph` with BFS and components; `map_tiny.txt` loads |
| **Wed Nov 25** | `MinHeap` passing `./public_tests heap` |
| **Tue Dec 1** | Dijkstra, Prim and the monster chase; the game runs from start to finish |
| **Thu Dec 3** | Doors, items, the score table, `--stats`; `make check` passes |
| **Sat Dec 5** | `map_mine.txt`, the writeup, valgrind clean |
| **Mon Dec 7** | Submit to Gradescope and Canvas by 11:59 pm |

## 4. Specification

### 4.1 `Graph`

```cpp
struct PathStats {
    int  settled;        // vertices taken from the heap and finalized
    int  staleSkipped;   // heap entries taken out and skipped as stale
    int  pushes;         // insert() calls on the heap
    long swapsUp;        // the heap's swapsUp() when Dijkstra finished
    long swapsDown;      // the heap's swapsDown() when Dijkstra finished
};

class Graph {
public:
    static const int INF = INT_MAX / 2;   // "unreachable" distance

    Graph(int numVertices);               // negative is treated as 0
    ~Graph();
    Graph(const Graph &other);            // deep copy: same lists,
                                          // same order, same ids
    Graph &operator=(const Graph &other);

    bool addEdge(int u, int v, int weight);
    int  vertexCount() const;
    int  edgeCount()   const;             // undirected edges
    int  degree(int v) const;             // -1 if out of range
    int  edgeWeight(int u, int v) const;  // smallest; -1 if none
    int  neighbors(int v, int *to, int *weight) const;

    long listBytes()   const;
    long matrixBytes() const;

    void bfs(int src, int *dist, int *parent,
             const bool *closed = NULL) const;
    void dfs(int src, bool *visited) const;
    int  connectedComponents(int *componentOf) const;

    void dijkstra(int src, int *dist, int *parent,
                  const bool *closed = NULL,
                  PathStats *stats = NULL) const;
    int  minimumSpanningTree(bool *inTree, int *treeEdges) const;

private:
    struct Edge {
        int   to;
        int   weight;
        int   id;
        Edge *next;
    };
    Edge **adj_;                          // new Edge*[n_]; NULL if 0
    int    n_;
    int    m_;
};
```

Vertices are numbered 0 to n − 1. `adj_` is an array of `n_` list heads, one per vertex, each the head of a singly linked list of `Edge` nodes (`NULL` for a vertex with no passages).

**Undirected edges go in both lists.** `addEdge(u, v, w)` creates **two** `Edge` nodes: one in u's list with `to = v`, and one in v's list with `to = u`. Both carry the same weight and the same **id**: the number of edges accepted before this one (0, 1, 2, ...). Each new node goes at the **front** of its list, so a vertex's neighbors come out in reverse order of insertion. `addEdge` returns `false` and changes nothing if u or v is out of range, if u == v, or if the weight is less than 1. Two passages between the same pair of rooms are allowed; each gets its own id.

**`edgeWeight(u, v)`** returns the smallest weight of the u--v passages, or −1 if there is none. `main.cpp` and the game use it to ask "is there a passage from here to there?".

**`neighbors(v, to, weight)`** copies v's list into the two arrays, front first, and returns `degree(v)`. The caller provides arrays with room for `degree(v)` entries.

**Memory.** `listBytes()` is what the adjacency lists occupy: the array of heads plus two `Edge` nodes per passage, `n × sizeof(Edge *) + 2m × sizeof(Edge)`. `matrixBytes()` is what an n × n matrix of `int` would occupy, `n² × sizeof(int)`. On the ECE machines `sizeof(Edge)` is 24 (three `int`s, 4 bytes of padding, a pointer).

**The Rule of Three.** The destructor deletes every `Edge` (each was created with `new`) and then the array. The copy constructor copies each list **in order**, so that a copy's `neighbors()` and traversals give the same results as the original's. `operator=` guards against self-assignment.

**`bfs(src, dist, parent, closed)`** fills `dist[v]` with the number of passages on a shortest path (fewest hops) from `src` to v, and `parent[v]` with the vertex before v on that path. Every vertex starts at `dist = INF` and `parent = −1`; `src` gets `dist = 0`. Use your `Deque<int>` as the FIFO frontier: `pushBack` to add, `popFront` to take. A vertex is discovered the first time it is seen, and never again.

When `closed` is not `NULL`, a vertex v with `closed[v]` true is never entered, as if its door were locked. `src` itself is always allowed, closed or not. The game passes its array of locked rooms here.

**`dfs(src, visited)`** sets `visited[v]` to true for every v reachable from `src` without passing through a vertex that is already visited. It does **not** clear `visited` first. If `visited[src]` is already true, it does nothing. A recursive version is the natural one; Section 5, question 4 asks about its recursion depth.

**`connectedComponents(componentOf)`** labels every vertex with its component number and returns the number of components. Number the components 0, 1, 2, ... **in order of each component's smallest vertex**: scan the vertices 0, 1, 2, ..., and start a new component at the first vertex not yet labeled.

```text
  edges 1-4, 4-6, 2-5, and vertices 0 and 3 alone:

  vertex        0  1  2  3  4  5  6
  componentOf   0  1  2  3  1  2  1         4 components
```

**`dist` and `INF`.** `INF` is `INT_MAX / 2`, not `INT_MAX` and not −1. Dijkstra computes `dist[u] + weight`; with `INF = INT_MAX` that sum overflows to a negative number, which then looks like the best distance of all. With `INT_MAX / 2` the sum stays positive for any weight a dungeon uses. The game compares distances against `Graph::INF` to mean "unreachable".

### 4.2 `MinHeap`

```cpp
class MinHeap {
public:
    MinHeap();                            // empty; counters 0

    void insert(int key, int value);      // add, then siftUp
    bool extractMin(int *key, int *value);// false if empty
    bool peekMin(int *key, int *value) const;

    int  size()  const;
    bool empty() const;

    long swapsUp()   const;               // swaps made by siftUp
    long swapsDown() const;               // swaps made by siftDown

private:
    struct Entry { int key; int value; };

    DynamicArray<Entry> a_;               // the heap, a_[0] the root
    long upSwaps_;
    long downSwaps_;

    void siftUp(int i);
    void siftDown(int i);
};
```

A binary min-heap stored in your `DynamicArray`: `a_[0]` is the root, the children of `a_[i]` are `a_[2i+1]` and `a_[2i+2]`, and its parent is `a_[(i−1)/2]`. Every entry's key is at least its parent's key. The heap orders entries **by key only**; the value travels with its key. Dijkstra stores (distance, vertex) and Prim stores (edge weight, vertex).

`MinHeap` declares no destructor, copy constructor or `operator=`. Its only owned resource is `a_`, a `DynamicArray`, which already follows the Rule of Three, so the compiler-generated versions copy and destroy a `MinHeap` correctly: the Rule of Zero. (If your `DynamicArray` copy is broken, so is `MinHeap`'s.)

**`insert(key, value)`** appends the entry at the end of `a_` and calls `siftUp` on it.

**`extractMin`** reports the root's key and value, moves the **last** entry into `a_[0]` (removing it from the end with `popBack`), and calls `siftDown(0)`. On an empty heap it returns `false` and leaves `*key` and `*value` unchanged.

**The sifting rules.** Both functions move an entry by **swapping** it with a neighbor, one level at a time, and count each swap. The autograder checks both counters, so follow these rules exactly:

- `siftUp(i)`: while `a_[i]` has a parent whose key is **strictly greater**, swap the two, add one to `upSwaps_`, and continue from the parent's position. An equal key stops the climb.
- `siftDown(i)`: take the child with the smaller key; if the two children have **equal** keys, take the **left** one. If that child's key is **strictly less** than `a_[i]`'s, swap the two, add one to `downSwaps_`, and continue from the child's position. Otherwise stop.

Worked example. Insert the keys 5, 3, 8, 1, 9, 2, then extract all six:

```text
  insert   a_ (keys) afterwards     swaps   swapsUp
  5        5                         0       0
  3        3 5                       1       1
  8        3 5 8                     0       1
  1        1 3 8 5                   2       3     (1 passes 5, then 3)
  9        1 3 8 5 9                 0       3
  2        1 3 2 5 9 8               1       4     (2 passes 8)

  extract  a_ (keys) afterwards     swaps   swapsDown
  1        2 3 8 5 9                 1       1     (8 to the root, then
                                                    swapped with 2)
  2        3 5 8 9                   2       3     (9 down past 3, then 5)
  3        5 9 8                     1       4
  5        8 9                       0       4
  8        9                         0       4
  9        (empty)                   0       4
```

### 4.3 Dijkstra

`dijkstra(src, dist, parent, closed, stats)` fills `dist[v]` with the smallest total weight of a path from `src` to v, and `parent[v]` with the vertex before v on such a path. Unreachable vertices keep `INF` and −1. `closed` works exactly as in `bfs`.

It must use **your `MinHeap`**. A Dijkstra that finds the next vertex by scanning every vertex for the smallest distance makes V scans of V entries, about V² steps, and is graded as incomplete: the heap makes each step about log V, for about (V + E) log V in total. The autograder runs your Dijkstra on a graph of 200,000 vertices, where the difference is a fraction of a second against minutes.

Handle a distance that improves with **lazy deletion**: push the improved (distance, vertex) as a **new** heap entry and leave the old one in the heap. When an entry comes out for a vertex that is already finished, it is stale; skip it.

```cpp
pq.insert(0, src);
while (pq.extractMin(&d, &u)) {
    if (done[u]) continue;        // stale entry -- skip it
    done[u] = true;
    // ... relax u's edges: for each neighbor v that is not done and
    //     not closed, if d + weight < dist[v], set dist[v] and
    //     parent[v] and insert (dist[v], v)
}
```

When `stats` is not `NULL`, fill it in: `settled` counts the vertices finalized (the non-stale entries taken out), `staleSkipped` the stale ones, `pushes` the `insert` calls, and `swapsUp` and `swapsDown` are the heap's counters when the loop ends. Every entry inserted is eventually taken out, so `pushes == settled + staleSkipped`.

`staleSkipped` is small but not zero on a dungeon with cycles. For example, with passages s--a (1), s--b (5) and a--b (1), b is first pushed with distance 5, then improved to 2 through a; the (5, b) entry comes out after b is finished and is skipped. A count of exactly zero on a dungeon with cycles usually means the relaxation is not pushing improved distances.

### 4.4 Prim's minimum spanning tree

**`minimumSpanningTree(inTree, treeEdges)`** runs **Prim's algorithm** with your `MinHeap` and lazy deletion. Prim grows a tree one vertex at a time: each step adds the cheapest passage that joins a vertex in the tree to a vertex outside it. The loop is your Dijkstra loop with one change. A vertex's key is the weight of the cheapest **single passage** joining it to the tree, not the length of a whole path from the source:

```text
                    Dijkstra                   Prim
  key of v          dist[v]: a whole path      key[v]: one passage
  relax u--v (w)    d + w < dist[v]            w < key[v]
  heap entries      (dist[v], v)               (key[v], v)
  records           parent[v]: a vertex        via[v]: an edge id
```

1. Every vertex starts with `key = INF`, `via = -1`, and not done. Every `inTree[id]` starts `false`.
2. Scan the vertices 0, 1, 2, .... At each vertex s that is not yet done, start a new tree: set `key[s] = 0` and insert (0, s).
3. Run the lazy-deletion loop. Extract (k, u); if u is already done, the entry is stale: skip it. Otherwise mark u done, and if `via[u]` is not −1, passage `via[u]` joins the tree: set `inTree[via[u]]`, add k to the total, and count it. Then, for each passage u--v of weight w with v not done: if w < `key[v]`, set `key[v]` to w and `via[v]` to that passage's id, and insert (w, v).
4. When the scan ends, set `*treeEdges` to the number of tree passages and return their total weight.

Step 2 matters on a dungeon with more than one component. One run from vertex 0 spans only vertex 0's component; starting a new tree at every vertex not yet reached gives a minimum spanning **forest**, one tree per component.

**The forest has exactly V − C edges**, where C is the number of connected components: V − 1 for a connected dungeon. A tree of k rooms has k − 1 edges, since every room but the tree's first joins through one passage. More means a room joined twice (the stale check is missing); fewer means a component was never started.

As with Dijkstra, a Prim that finds the next vertex by scanning every vertex for the smallest key is graded as incomplete; the autograder runs Prim on 200,000 vertices. When two passages have the same weight, either may join first; the total weight of a minimum spanning tree does not depend on that choice. Parallel passages need no special case: the lighter one wins the `w < key[v]` test.

In the game the tree is the **corridor skeleton**: tree passages are lit, every other passage is a dark shortcut. `--stats` reports the tree's weight and edge count.

### 4.5 The game

**The map file.** One command per line; `#` starts a comment line; blank lines are ignored. `rooms` must come first.

```text
rooms 5                     5 rooms, numbered 0..4
room 2 Pit                  a name for room 2 (default "Room 2")
passage 0 2 1               a passage between 0 and 2, weight 1
entrance 0
exit 4
door 3                      room 3 has a locked door
key 1 3 rusty-key           a key named rusty-key lies in room 1;
                            it opens the door of room 3
item 2 copper-coin 5        an item in room 2, worth 5 points
monster 4                   a monster starts in room 4
```

The provided loader (`loadFile`, `loadText`) checks each line and rejects a map in which a door has no key or two keys, a key opens a room with no door, two items share a name, the entrance is locked, the entrance and exit are the same room, or a monster starts at the entrance or behind a door. Its last check calls your **`validateDoors`**, and rejects the map if it returns `false`.

**`validateDoors(rounds)`.** A door can be opened once its key can be reached, and reaching one key may open the door in front of another. One BFS cannot decide whether every door can be opened; repeat it until nothing changes:

1. Copy the locked rooms into a `closed` array.
2. Run `bfs` from the entrance with `closed`.
3. For every key whose door is still closed: if the BFS reached the room the key lies in (or the player already carries it), open that door in `closed`.
4. If step 3 opened at least one door, go back to step 2.

Return `true` if, at the end, every door is open and the exit was reached; set `*rounds` to the number of BFS runs. A key that lies behind its own door, or two doors whose keys lie behind each other, is never reached: the map is rejected. `maps/map_bad_door.txt` is such a map.

```text
  maps/map_main.txt:   iron-key (room 12) opens the Vault (23);
                       gate-key (in the Vault) opens the Exit Gate (31)

  round 1   BFS reaches room 12 but not 23   -> open 23
  round 2   BFS reaches 23                    -> open 31
  round 3   nothing new to open               -> stop:  3 rounds
```

**The player.**

- `movePlayer(room)` moves through one passage. It returns `false`, and nothing changes, if the game is over or no passage joins the player's room and `room`. A locked room can be entered only by a player carrying its key; entering it unlocks it for good. Entering a room with a monster loses the game (`state()` becomes `LOST`); otherwise entering the exit wins it (`WON`).
- `pickUp(name)` looks the name up in the item catalog, your `HashMap`, which maps each item name to its index in `items_`. The item must lie in the player's room and not be carried already. Its points are added to the score. Keys are items worth 0 points.
- `carrying(name)` is true if the player has picked the item up.
- `score()` is the points of the items picked up, plus 100 if the game was won.

**The monsters.** `monsterStep(i)` moves monster i one passage toward the player along a **cheapest** path:

1. Run your `dijkstra` from the monster's room, with the locked rooms closed. Monsters cannot open doors.
2. If the player's room is unreachable, the monster stays where it is.
3. Otherwise, `parent[]` is a tree of cheapest paths rooted at the monster. Follow it **backwards from the player's room** until you reach the room whose parent is the monster's room. That room is the step. (Taking the first step from the wrong end of the path makes the monster walk away from the player.)
4. If the step lands on the player, the game is lost.

`monsterStep` returns the monster's room. A monster that follows the cheapest path is visibly different from one that follows the fewest passages: on `map_main.txt` the cheapest route often takes more steps.

`endTurn()` ends the player's turn. Monsters move at half the player's speed: when `turns()` is **even**, every monster acts once, in the order of `turnQueue_`, your `Deque<int>` of monster indices: `popFront` an index, `monsterStep` it, `pushBack` it. Then `turns()` goes up by one. After the game is over, `endTurn` does nothing. `main.cpp` calls `endTurn` after every move, `take` and `wait`.

**High scores.** The table is your `BST<ScoreEntry>`:

```cpp
struct ScoreEntry {
    int         points;
    std::string name;
    ScoreEntry();
    ScoreEntry(int p, const std::string &n);
    bool operator<(const ScoreEntry &other) const;
};
```

Your `BST` stores distinct keys and compares with `<` only, so `<` must order **every pair of different entries**. Order by points, **more points first**, and break a tie by name in alphabetical order. Then an in-order traversal lists the table from the top down, and two players with the same score are both kept. The same name with the same points is the same entry, and `addScore` returns `false` for it.

`printScores` prints one line per entry, in order, in the format `"%3d. %5d  %s"` (rank, points, name):

```text
  1.   140  ana
  2.    95  bo
  3.    95  cy
```

`inorder()` takes a plain function pointer, so the visitor reaches the output stream and the rank through file-scope variables. The provided `saveScores` shows the pattern.

**Copying a `Dungeon` is disabled.** Its copy constructor and `operator=` are declared in the private section and never defined, so `Dungeon b = a;` does not compile. A `Dungeon` owns a `Graph` and an array through pointers; disabling the copy is the simplest correct choice when no copy is ever needed.

**Your own map.** Write `maps/map_mine.txt`: at least 30 rooms, at least two locked doors with their keys, at least one monster, and at least one pair of rooms between which BFS and Dijkstra choose different paths. Writeup question 1 is about that pair. A map you write by hand is fine; a program that writes one earns no extra credit.

### 4.6 `--stats`

`./dungeon --stats map.txt` loads the map, loads `scores.txt` if it exists, and calls `printStats`, which prints these lines in this order. Each line is the label, a colon, spaces, and the value. The autograder reads the values by label, so spell the labels exactly.

```text
rooms (V):                            32
passages (E):                         39
average degree:                       2.44
connected components:                 2
adjacency list bytes:                 2128
adjacency matrix bytes:               4096
MST total weight:                     61
MST edges:                            30
BFS hops entrance to exit:            2
Dijkstra distance entrance to exit:   17
Dijkstra settled:                     31
Dijkstra stale skipped:               3
heap swaps up:                        13
heap swaps down:                      20
door check BFS rounds:                3
item table size:                      10
item table load factor:               0.62
item table longest chain:             2
item table rehashes:                  1
score table size:                     0
score table height:                   -1
floor(log2 score table size):         -
```

That is the output for `maps/map_main.txt` with no `scores.txt`. Notes:

- BFS, Dijkstra and the MST run on the whole map **with every door open**, from the entrance. A distance to an unreachable exit prints as `unreachable`.
- `average degree` is 2E / V. It and `item table load factor` print with two decimals.
- The `Dijkstra` and `heap swaps` lines come from the `PathStats` of that one run. The stale count and the swap counts can differ from the example if your relaxation visits neighbors in another order; `Dijkstra settled` and the distance cannot.
- `door check BFS rounds` comes from `validateDoors`.
- The item-table lines come from your `HashMap`'s `size()`, `loadFactor()`, `longestChain()` and `rehashCount()`.
- The last line prints `-` when the score table is empty.

## 5. The writeup

Fill in `WRITEUP.md`. Keep each answer short and about your own code and your own numbers.

**How to build and play.** A few lines: how to build, how to start a game, the commands, and what is on your map.

**Measurements.**

- Paste the `--stats` output for `maps/map_main.txt` and for `maps/map_mine.txt`.
- **Memory.** For your map, compute the adjacency-list and adjacency-matrix sizes from V and E (show the arithmetic, and check it against `--stats`). Why does the list win for a dungeon? Roughly how many passages would your map need before the matrix used less memory?
- **Stale entries.** Report `Dijkstra stale skipped` for both maps and explain where those entries came from.
- **MST.** Report the MST edge count for both maps and show that it equals V − C.
- **Score table.** Play at least five games on your map (or add lines to `scores.txt` by hand: `points name`). Report the score table's size and height next to ⌊log₂ n⌋, and say what the order of arrival did to the height.

**Questions.**

1. **BFS and Dijkstra choose different paths.** On your own map, give two rooms for which the fewest-passages path and the cheapest path differ. List both paths with their hop counts and total weights, and say what each algorithm optimizes.
2. **The monster.** Why must the monster's Dijkstra be run again every turn? What would go wrong if it were computed once at startup? What does one turn cost, in terms of V and E, for a dungeon with k monsters, with your heap, and with a linear scan instead of the heap? The passages are undirected: how could a single Dijkstra per turn, run from the player, serve every monster?
3. **The door check.** Why can a single BFS not decide whether every door can be opened? For a map with D doors, what is the largest number of BFS rounds `validateDoors` can need, and so what does the whole check cost in terms of D, V and E? Explain the number of rounds `--stats` reports for `map_main.txt` from the map itself.
4. **A structure, against an alternative.** Pick one structure in the game and justify it against a specific alternative: for example, the item catalog as a hash table rather than your BST, the score table as a BST rather than a hash table, or BFS's frontier as a deque rather than your heap. Name the operation that decides it. Include the recursion depth of your `dfs` on a dungeon that is one long corridor of V rooms, and what that depth would mean for a corridor of a million rooms.
5. **Your containers under load.** Which of your Lab 6 and Lab 7 containers needed fixing in this lab, what was the bug, and how did you find it? If none did, say which tests and runs exercised each one and what evidence makes you confident.

## 6. Building and testing

The `Makefile` is provided:

```
make                 # ./dungeon
make check           # ./public_tests: every provided test
./public_tests heap  # one group: graph, traverse, heap, dijkstra,
                     # mst, game
make stats           # ./dungeon --stats maps/map_main.txt
make valgrind        # a scripted game and the provided tests,
                     # under valgrind
make clean
```

If you add a `.cpp` file, add it to `OBJS` and give it a rule. The Makefile must still build `./dungeon` with no warnings.

**Run valgrind on a scripted game, not an interactive one.** `maps/moves_main.txt` is a list of commands, one per line; piping it into `./dungeon` plays a whole game:

```
valgrind --leak-check=full ./dungeon --scores /dev/null \
    maps/map_main.txt < maps/moves_main.txt
```

(`--scores /dev/null` keeps the run from changing your `scores.txt`.) Write a moves file for your own map too.

The provided suite runs the same kinds of checks the autograder runs. Passing it is necessary, not sufficient: the autograder runs larger and random graphs against model answers, checks the heap's swap counts on random sequences, times Dijkstra on 200,000 vertices, and plays games through the `Dungeon` functions.

A test that passes without valgrind and fails under it has still failed.

**Debug on `map_tiny.txt`.** Its five rooms are small enough to run every algorithm by hand: the comment at its top draws it. Debugging Dijkstra on 32 rooms is slow; on 5 you can check each line of `dist`.

## 7. Allowed and not allowed

Allowed: everything from earlier labs, templates, `std::string`, `<iostream>`, `<fstream>`, `<sstream>`, `<cstdio>`, `<cstdlib>`, `<cstring>`, `<climits>`, function pointers.

In **every file you submit** (`graph.*`, `minheap.*`, `game.*`, `main.cpp`, and your Lab 6 and 7 files):

| Not allowed | Why |
|---|---|
| `std::vector`, `std::list`, `std::map`, `std::set`, `std::unordered_map`, `std::deque`, `std::queue`, `std::stack`, **`std::priority_queue`**, or any other standard container | you built these; the lab is about using your own |
| `std::sort` and the other `<algorithm>` sorts and heap functions (`std::make_heap`, `std::push_heap`, ...), `qsort` | the ordering in Dijkstra and Prim comes from your heap |
| `std::unique_ptr`, `std::shared_ptr` | the ownership is yours to manage by hand |
| `malloc` / `free` / `realloc` | memory from `new` is released with `delete`, from `new[]` with `delete[]` |
| `virtual` | runtime polymorphism is not part of this course |
| changing the public sections of `Graph`, `MinHeap` or `Dungeon`, or the data members of the first two | the autograder compiles against them |

The autograder scans every submitted `.h` and `.cpp` for everything in this table, with comments and string literals blanked out first, so the words in a comment are fine. A finding **halves your autograded score**.

## 8. Submission and grading

Submit these files to **Gradescope**, and upload the same files in one zip to **Canvas**, by **Mon Dec 7, 11:59 pm**:

`graph.h` · `graph.cpp` · `minheap.h` · `minheap.cpp` · `game.h` · `game.cpp` · `main.cpp` · `deque.h` · `dynamic_array.h` · `hashmap.h` · `hashmap.cpp` · `bst.h` · `Makefile` · `maps/map_mine.txt` · `WRITEUP.md` · `AI_LOG.md`

| | |
|---|---|
| `Graph`: lists, the Rule of Three, `addEdge`, observers | 5 |
| `Graph`: BFS (with closed rooms), DFS, connected components | 10 |
| `MinHeap`: ordering, the swap rules and counters, copying | 10 |
| Dijkstra: correct distances, your heap, lazy deletion, 200,000 vertices | 10 |
| Prim: your heap, a full forest, 200,000 vertices | 5 |
| The game: doors, movement, items, monster steps, turns, scores | 15 |
| `--stats` on maps the autograder supplies | 5 |
| `WRITEUP.md`: measurements and the five answers | 25 |
| Your map, and the structures driving the game (Section 4.5) | 15 |
| **Valgrind: any leak or invalid access** | **−20** |

The first seven lines (60 points) are awarded by the autograder, which you may run as often as you like before the deadline. The writeup and your map (40 points) are graded by hand on Gradescope. Valgrind runs on the grader's own memory tests against your classes, and on a scripted game with your `./dungeon`; a leak or invalid access in either costs the 20 points once.

The 25 writeup points: the measurements (5) and each of the five questions (4 each). The writeup is graded on your own code and your own numbers, so an answer that does not match what your code does earns little.

The 15 points for your map and the structures: `map_mine.txt` loads and meets Section 4.5 (6); the game's behavior comes from your structures as Section 1 lists, with no structure bypassed (6); the build-and-play notes and `AI_LOG.md` (3).

## 9. Checklist before you submit

- [ ] `make` produces zero warnings with `-Wall -Wextra -Werror` and builds `./dungeon`
- [ ] `make check` passes, and `make valgrind` reports 0 errors and 0 bytes lost
- [ ] the public sections (and, for `Graph` and `MinHeap`, the data members) are as given
- [ ] the `PLACEHOLDER` casts in the constructors are gone
- [ ] `addEdge` puts each new edge at the **front** of **both** lists
- [ ] the heap's sifting follows Section 4.2 exactly, and `./public_tests heap` passes
- [ ] Dijkstra uses your `MinHeap` with lazy deletion, and `pushes == settled + staleSkipped`
- [ ] Prim uses your `MinHeap`, starts a new tree at every vertex not yet reached, and gives V − C edges
- [ ] `./dungeon maps/map_bad_door.txt` is rejected
- [ ] `--stats` prints every line of Section 4.6 with the labels as given
- [ ] `maps/map_mine.txt` has ≥ 30 rooms, ≥ 2 doors with keys, ≥ 1 monster, and loads
- [ ] nothing from the "Not allowed" table appears in any submitted file
- [ ] `WRITEUP.md` and `AI_LOG.md` are filled in
- [ ] the same files are uploaded to both Gradescope and Canvas

## 10. AI policy for this lab

Log substantive use in `AI_LOG.md`: what you asked, what you got, what you changed and why. This lab **assumes** you are using Codex or Claude; it is sized for it, and using it well is a skill this course wants you to have.

**The writeup grades your understanding of the code you submitted.** Its questions ask about your own code and your own measurements, and the final exam asks you to run these algorithms by hand. Code you cannot explain costs more there than it saved you writing.

**Where it helps, and you should use it:** the scaffolding around the structures. Extending `main.cpp`, writing your map file or a script that writes one, a moves file for valgrind, a nicer `render`. None of that is what the autograder grades.

**Where to be careful: the algorithms.** Assistants reliably write a Dijkstra that uses `std::priority_queue`, which is not allowed here and which replaces the heap you were asked to build and instrument; the scan halves the autograded score, and writeup question 2 asks what your heap costs against a linear scan. They also write heaps whose sifting does not follow Section 4.2's tie rules, which changes the swap counts. Asked for a minimum spanning tree, they often write Kruskal with `std::sort`, which is not the algorithm this lab asks for, or a Prim that scans every vertex for the smallest key.

**A good use once things work:** give an assistant your `--stats` output and ask whether the numbers are consistent. Is the score table's height plausible for that many scores in that order of arrival? Does the stale count make sense for that graph? Is the MST edge count right for that many components? Deciding whether a measurement is believable is the engineering judgment this capstone is testing. If the assistant reports a problem, confirm it with a trace or a test before you change anything, and record in `AI_LOG.md` which reports were real.
