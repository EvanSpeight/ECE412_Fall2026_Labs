/* ------------------------------------------------------------------ *
 * main.cpp -- ECE 412 Lab 8.  The game: command line, turn loop and
 *             end-of-game score table.  Builds to ./dungeon.
 *
 * PROVIDED.  Every game rule lives in Dungeon (game.h); this file
 * only reads commands and calls it.  You may change it -- add
 * commands, colors, a fancier map -- but keep the options below
 * working: the autograder runs them.
 *
 *     ./dungeon maps/map_main.txt              play
 *     ./dungeon --stats maps/map_main.txt      print --stats and exit
 *     ./dungeon --name ana maps/map_main.txt   your name in the table
 *     ./dungeon --scores FILE map.txt          high-score file
 *                                              (default scores.txt)
 *
 * Commands are read from standard input, one per line, so a game can
 * be scripted for valgrind:
 *
 *     ./dungeon maps/map_main.txt < maps/moves_main.txt
 * ------------------------------------------------------------------ */
#include <cstdlib>
#include <cstring>
#include <iostream>
#include <sstream>
#include <string>

#include "game.h"

static void usage(void)
{
    std::cout << "usage: ./dungeon [--stats] [--name NAME] "
                 "[--scores FILE] mapfile\n";
}

static void help(void)
{
    std::cout <<
        "Commands:\n"
        "  go N, or just N   move through the passage to room N\n"
        "  take NAME         pick up an item or key in this room\n"
        "  wait              stay where you are for a turn\n"
        "  look              describe the room again (not a turn)\n"
        "  map               hops from here to every room (BFS)\n"
        "  scores            the high-score table\n"
        "  help, quit\n"
        "Moving, taking and waiting each end your turn; then every\n"
        "monster takes one step toward you.\n";
}

/* "map": BFS from the player through unlocked rooms. */
static void autoMap(const Dungeon &d)
{
    int n = d.roomCount();
    int *dist = new int[n];
    int *parent = new int[n];
    bool *closed = new bool[n];
    for (int r = 0; r < n; r++) {
        closed[r] = d.isLocked(r);
    }
    d.graph().bfs(d.playerRoom(), dist, parent, closed);
    for (int r = 0; r < n; r++) {
        std::cout << "  [" << r << "] " << d.roomName(r) << ": ";
        if (dist[r] == Graph::INF) {
            std::cout << (d.isLocked(r) ? "locked" : "not reachable");
        } else {
            std::cout << dist[r] << " hop" << (dist[r] == 1 ? "" : "s");
        }
        if (r == d.exitRoom()) {
            std::cout << "   <-- exit";
        }
        std::cout << '\n';
    }
    delete[] dist;
    delete[] parent;
    delete[] closed;
}

int main(int argc, char *argv[])
{
    bool stats = false;
    std::string name = "player";
    const char *scoreFile = "scores.txt";
    const char *mapFile = NULL;
    for (int i = 1; i < argc; i++) {
        if (std::strcmp(argv[i], "--stats") == 0) {
            stats = true;
        } else if (std::strcmp(argv[i], "--name") == 0 && i + 1 < argc) {
            name = argv[++i];
        } else if (std::strcmp(argv[i], "--scores") == 0 && i + 1 < argc) {
            scoreFile = argv[++i];
        } else if (argv[i][0] == '-' || mapFile != NULL) {
            usage();
            return 2;
        } else {
            mapFile = argv[i];
        }
    }
    if (mapFile == NULL) {
        usage();
        return 2;
    }

    Dungeon d;
    std::string error;
    if (!d.loadFile(mapFile, &error)) {
        std::cout << mapFile << ": " << error << '\n';
        return 1;
    }
    if (stats) {
        d.loadScores(scoreFile);
        d.printStats(std::cout);
        return 0;
    }

    std::cout << "Find the exit, [" << d.exitRoom() << "] "
              << d.roomName(d.exitRoom()) << ".  Type help for "
              << "commands.\n";
    d.render(std::cout);

    std::string line;
    bool quit = false;
    while (!quit && d.state() == PLAYING) {
        std::cout << "> " << std::flush;
        if (!std::getline(std::cin, line)) {
            break;                        // end of input
        }
        std::istringstream ss(line);
        std::string cmd, arg;
        ss >> cmd;
        ss >> arg;
        bool turn = false;
        if (cmd.empty()) {
            continue;
        } else if (cmd == "quit" || cmd == "q") {
            quit = true;
        } else if (cmd == "help" || cmd == "?") {
            help();
        } else if (cmd == "look" || cmd == "l") {
            d.render(std::cout);
        } else if (cmd == "map") {
            autoMap(d);
        } else if (cmd == "scores") {
            d.printScores(std::cout);
        } else if (cmd == "wait" || cmd == "w") {
            turn = true;
        } else if (cmd == "take" || cmd == "t") {
            if (d.pickUp(arg)) {
                std::cout << "You take the " << arg << ".\n";
                turn = true;
            } else {
                std::cout << "There is no " << arg << " here.\n";
            }
        } else {
            std::string target = (cmd == "go" || cmd == "g") ? arg : cmd;
            char *end = NULL;
            long room = std::strtol(target.c_str(), &end, 10);
            if (target.empty() || *end != '\0') {
                std::cout << "Unknown command.  Type help.\n";
            } else if (d.movePlayer((int)room)) {
                turn = true;
            } else if (d.isLocked((int)room) &&
                       d.graph().edgeWeight(d.playerRoom(),
                                            (int)room) > 0) {
                std::cout << "The door is locked.  You need its key.\n";
            } else {
                std::cout << "No passage leads there from here.\n";
            }
        }
        if (turn) {
            if (d.state() == PLAYING) {
                d.endTurn();
            }
            if (d.state() == PLAYING) {
                d.render(std::cout);
            }
        }
    }

    if (d.state() == PLAYING) {
        std::cout << "\nYou leave the dungeon.  Score " << d.score()
                  << ", not recorded.\n";
        return 0;
    }
    std::cout << (d.state() == WON ? "\nYou escaped!" :
                  "\nA monster caught you.")
              << "  Score " << d.score() << " after " << d.turns()
              << " turns.\n\nHigh scores:\n";
    d.loadScores(scoreFile);
    d.addScore(name, d.score());
    d.printScores(std::cout);
    d.saveScores(scoreFile);
    return 0;
}
