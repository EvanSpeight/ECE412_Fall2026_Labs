/* ------------------------------------------------------------------ *
 * graph.h -- ECE 412 Lab 8.  Graph: an undirected, weighted graph
 *            stored as adjacency lists.
 *
 * The public section and the data members are the specification.
 * Do not change them: the autograder compiles its own test programs
 * against them.  You MAY add private member functions (helpers).
 *
 * Vertices are 0 .. n-1.  Every passage u--v of weight w is stored
 * TWICE: once in u's list (to = v) and once in v's list (to = u).
 * Both copies carry the same edge id, the order in which addEdge
 * accepted the edge: 0, 1, 2, ...
 *
 *   adj_ --> [0] --> (to 2, w 4, id 1) --> (to 1, w 7, id 0) --> NULL
 *            [1] --> (to 0, w 7, id 0) --> NULL
 *            [2] --> (to 0, w 4, id 1) --> NULL
 *
 *   after addEdge(0, 1, 7) and then addEdge(0, 2, 4): each new edge
 *   goes at the FRONT of both lists.
 *
 * Invariants to keep true before and after every public function:
 *   I1. adj_ points at an array of n_ list heads from new[] (NULL
 *       when n_ == 0)
 *   I2. an edge with id k appears exactly twice: in the lists of its
 *       two endpoints, and nowhere else
 *   I3. m_ is the number of edges accepted; ids are 0 .. m_-1
 *
 * Allowed here: your Deque<T> (Lab 6) and your MinHeap.
 * Not allowed: any standard container (std::priority_queue included)
 * and std::sort (README section 7).
 * ------------------------------------------------------------------ */
#ifndef GRAPH_H
#define GRAPH_H

#include <climits>
#include <cstddef>

/* Counters filled in by dijkstra() when its stats argument is not
 * NULL (README section 4.3). */
struct PathStats {
    int  settled;        // vertices taken from the heap and finalized
    int  staleSkipped;   // heap entries taken out and skipped as stale
    int  pushes;         // insert() calls on the heap
    long swapsUp;        // the heap's swapsUp() when Dijkstra finished
    long swapsDown;      // the heap's swapsDown() when Dijkstra finished
};

class Graph {
public:
    static const int INF = INT_MAX / 2;   // "unreachable" distance

    Graph(int numVertices);               // n vertices, no edges;
                                          // a negative n is treated
                                          // as 0
    ~Graph();
    Graph(const Graph &other);            // deep copy: same lists,
                                          // same order, same ids
    Graph &operator=(const Graph &other);

    bool addEdge(int u, int v, int weight);
                                          // undirected; false (and no
                                          // change) if u or v is out
                                          // of range, u == v, or
                                          // weight < 1

    int  vertexCount() const;
    int  edgeCount()   const;             // undirected edges
    int  degree(int v) const;             // -1 if v is out of range
    int  edgeWeight(int u, int v) const;  // smallest weight of a u--v
                                          // edge; -1 if there is none
    int  neighbors(int v, int *to, int *weight) const;
                                          // fills to[] and weight[]
                                          // (each with room for
                                          // degree(v) entries) in list
                                          // order; returns degree(v)

    // Memory, for --stats (README section 4.1).
    long listBytes()   const;             // adjacency list, as stored
    long matrixBytes() const;             // an n x n int matrix

    // Traversals.  Arrays have n entries, allocated by the caller.
    // A vertex v with closed != NULL && closed[v] is never entered
    // (src itself is always allowed).
    void bfs(int src, int *dist, int *parent,
             const bool *closed = NULL) const;
                                          // hop counts; INF and -1
                                          // for unreachable vertices
    void dfs(int src, bool *visited) const;
                                          // sets visited[v] for every
                                          // v reachable from src
                                          // without passing through a
                                          // vertex already visited
    int  connectedComponents(int *componentOf) const;
                                          // returns the count; labels
                                          // 0, 1, 2, ... in order of
                                          // each component's smallest
                                          // vertex

    // Shortest paths: YOUR MinHeap, lazy deletion (README 4.3).
    void dijkstra(int src, int *dist, int *parent,
                  const bool *closed = NULL,
                  PathStats *stats = NULL) const;

    // Minimum spanning tree: Prim with YOUR MinHeap and lazy
    // deletion (README 4.4).  inTree has edgeCount() entries.
    // Returns the total weight; *treeEdges gets the edge count.
    int  minimumSpanningTree(bool *inTree, int *treeEdges) const;

private:
    struct Edge {
        int   to;
        int   weight;
        int   id;
        Edge *next;
    };

    Edge **adj_;                          // new Edge*[n_]; NULL if 0
    int    n_;
    int    m_;

    // Add private helper functions here if you want them: one that
    // frees every list (the destructor and operator= both need it),
    // one that copies another graph's lists, a recursive DFS step.
    // Add no data members.
};

#endif /* GRAPH_H */
