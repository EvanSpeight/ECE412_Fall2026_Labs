/* ------------------------------------------------------------------ *
 * game.h -- ECE 412 Lab 8.  Dungeon: the game state, built from your
 *           Graph, MinHeap (through Graph), HashMap (Lab 7),
 *           BST<T> (Lab 7), Deque<T> and DynamicArray<T> (Lab 6).
 *
 * The public section is the specification.  Do not change it: the
 * autograder compiles its own test programs against it.  You MAY add
 * private member functions AND private data members.
 *
 * Which structure does what:
 *
 *   graph_       rooms and passages                   Graph
 *   locked_      which rooms have a locked door        bool array
 *   items_       every item and key in the dungeon     DynamicArray
 *   catalog_     item name -> index in items_          HashMap
 *   monsters_    the room each monster is in           DynamicArray
 *   turnQueue_   the order the monsters act in         Deque
 *   scores_      the high-score table                  BST<ScoreEntry>
 *
 * Copying a Dungeon is disabled: the copy constructor and operator=
 * are declared private and never defined, so a copy does not
 * compile (README section 4.5).
 * ------------------------------------------------------------------ */
#ifndef GAME_H
#define GAME_H

#include <iosfwd>
#include <string>

#include "bst.h"
#include "deque.h"
#include "dynamic_array.h"
#include "graph.h"
#include "hashmap.h"

/* One line of the high-score table.  BST<T> stores distinct keys and
 * compares with < only, so < must order every pair of different
 * entries: more points first, then names in alphabetical order.  An
 * in-order traversal then prints the table from the top down. */
struct ScoreEntry {
    int         points;
    std::string name;

    ScoreEntry();                         // 0 points, empty name
    ScoreEntry(int p, const std::string &n);
    bool operator<(const ScoreEntry &other) const;
};

enum GameState { PLAYING, WON, LOST };

class Dungeon {
public:
    Dungeon();
    ~Dungeon();

    /* ---- loading (PROVIDED) -------------------------------------- */
    bool loadFile(const char *path, std::string *error);
    bool loadText(const std::string &text, std::string *error);
                                          // false, with a message in
                                          // *error, for a bad map.
                                          // Calls validateDoors().

    /* ---- the map ------------------------------------------------- */
    int  roomCount() const;
    const std::string &roomName(int room) const;   // PROVIDED
    int  entrance() const;
    int  exitRoom() const;
    const Graph &graph() const;           // only after a load

    /* ---- locked doors (README 4.5) ------------------------------- */
    bool validateDoors(int *rounds) const;
                                          // true if every door can be
                                          // opened and the exit then
                                          // reached; *rounds = BFS
                                          // runs used
    int  doorCount() const;
    bool isLocked(int room) const;        // locked right now

    /* ---- the player ---------------------------------------------- */
    int  playerRoom() const;
    bool movePlayer(int room);            // one passage; false if not
                                          // adjacent, locked without
                                          // its key, or game over
    bool pickUp(const std::string &item); // false if not in this room
                                          // (or already carried)
    bool carrying(const std::string &item) const;
    int  score() const;                   // item points, +100 on a win
    int  turns() const;                   // completed endTurn() calls
    GameState state() const;

    /* ---- monsters ------------------------------------------------ */
    int  monsterCount() const;
    int  monsterRoom(int i) const;        // -1 if i is out of range
    int  monsterStep(int i);              // one passage toward the
                                          // player along a cheapest
                                          // path; returns the new room
    void endTurn();                       // on even turns(), every
                                          // monster acts once, in
                                          // turn-queue order; then
                                          // turns() goes up by one

    /* ---- high scores --------------------------------------------- */
    bool addScore(const std::string &name, int points);
                                          // false if that exact entry
                                          // is already in the table
    int  scoreCount()  const;
    int  scoreHeight() const;             // BST height; -1 when empty
    void printScores(std::ostream &out) const;
                                          // "  1.   140  ana" per line,
                                          // highest first
    bool loadScores(const char *path);    // PROVIDED
    bool saveScores(const char *path) const;       // PROVIDED

    /* ---- output -------------------------------------------------- */
    void render(std::ostream &out) const; // PROVIDED: the current room
    void printStats(std::ostream &out) const;
                                          // --stats (README 4.6)

private:
    struct Item {
        std::string name;
        int  room;                        // the room it lies in
        int  points;                      // score when picked up
        int  opens;                       // the locked room it opens;
                                          // -1 for an ordinary item
        bool carried;
        Item() : room(-1), points(0), opens(-1), carried(false) {}
    };

    Graph                    *graph_;     // NULL until loaded
    DynamicArray<std::string> names_;     // room names
    bool                     *locked_;    // new bool[roomCount()]
    int                       doors_;     // doors in the map
    DynamicArray<Item>        items_;
    HashMap                   catalog_;   // name -> index in items_
    DynamicArray<int>         monsters_;  // room of each monster
    Deque<int>                turnQueue_; // monster indices
    BST<ScoreEntry>           scores_;
    int                       entrance_;
    int                       exit_;
    int                       player_;
    int                       points_;    // item points collected
    int                       turns_;
    GameState                 state_;

    Dungeon(const Dungeon &);             // not defined: no copies
    Dungeon &operator=(const Dungeon &);

    void reset();                         // PROVIDED: back to empty
    bool parse(std::istream &in, std::string *error);   // PROVIDED
};

#endif /* GAME_H */
