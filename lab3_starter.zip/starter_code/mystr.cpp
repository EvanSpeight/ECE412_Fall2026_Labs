/* ------------------------------------------------------------------ *
 * mystr.cpp -- my_strdup, from Lab 2.
 * ------------------------------------------------------------------ */
#include <cstdlib>
#include <cstring>

#include "mystr.h"

char *my_strdup(const char *s)
{
    /* TODO: bring your Lab 2 implementation over.
     *
     *   1. if s is NULL, return NULL
     *   2. measure it (strlen)
     *   3. malloc strlen + 1 -- the +1 is the bug everyone writes once
     *   4. NULL-check the malloc
     *   5. copy, including the terminator
     */
    (void)s; /* avoid unused parameter warning */
    return NULL;
}
