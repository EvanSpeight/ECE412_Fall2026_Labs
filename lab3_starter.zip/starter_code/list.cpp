/* ------------------------------------------------------------------ *
 * list.cpp -- ECE 412 Lab 3.  The implementation, and the ONLY place
 *             `struct Node` and `struct List` are allowed to exist.
 *
 * C subset of C++11 only.  malloc/free, char *, no classes, no STL.
 * Every function below has a box-and-arrow diagram you should draw
 * before you write it.  The diagram is the work; the code is the
 * transcription.
 * ------------------------------------------------------------------ */
#include <cstdio>
#include <cstdlib>
#include <cstring>

#include "list.h"
#include "mystr.h"

/* ------------------------------------------------------------------ *
 * The private shape.  These two definitions never leave this file.
 * ------------------------------------------------------------------ */

struct Node {
    Item  item;
    Node *next;
};

struct List {
    Node   *head;
    Node   *tail;   /* required: List_insert_back must be constant time */
    size_t  count;  /* required: List_size must be constant time       */
};

/* ------------------------------------------------------------------ *
 * Recommended private helpers.  Uncomment and fill these in.
 *
 * node_new is a single place that builds one fully formed node --
 * name deep-copied, next set to NULL -- and returns NULL if either
 * malloc fails, having freed whatever it already took.  Writing it
 * first makes both inserts about three lines long, and satisfies
 * "a failed allocation must not corrupt the list" in one place
 * instead of two.
 *
 *   static Node *node_new(int sku, const char *name, int qty)
 *   {
 *       ...
 *   }
 *
 *   static void node_free(Node *n)    // frees the name AND the node
 *   {
 *       ...
 *   }
 * ------------------------------------------------------------------ */

/* ------------------------------------------------------------------ *
 * lifetime
 * ------------------------------------------------------------------ */

List *List_create(void)
{
    /* TODO: create and initialize a List */
    return NULL;
}

void List_destroy(List *l)
{
    /* TODO: List_destroy(NULL) is a no-op.  Otherwise free everything in the 
     * correct order.*/
    (void)l; /* avoid unused parameter warning */
}

/* ------------------------------------------------------------------ *
 * insertion
 * ------------------------------------------------------------------ */

int List_insert_front(List *l, int sku, const char *name, int qty)
{
    /* TODO: allocate, deep-copy the name, link at the head. */
    (void)l; (void)sku; (void)name; (void)qty; /* avoid unused parameter warning */
    return 0;
}

int List_insert_back(List *l, int sku, const char *name, int qty)
{
    /* TODO: constant time via l->tail.  Do NOT walk the list.
     * On an empty list, head and tail both become the new node. */
    (void)l; (void)sku; (void)name; (void)qty;
    return 0;
}

/* ------------------------------------------------------------------ *
 * lookup
 * ------------------------------------------------------------------ */

const Item *List_find(const List *l, int sku)
{
    /* TODO: return  requested item or NULL.
     * Note the const: this function may not modify anything. */
    (void)l; (void)sku;
    return NULL;
}

/* ------------------------------------------------------------------ *
 * removal
 * ------------------------------------------------------------------ */

int List_remove(List *l, int sku)
{
    /* TODO: four cases, and you must test all four:
     *   1. empty list                  
     *   2. match is the head           
     *   3. match is in the middle      
     *   4. match is the tail          
     */
    (void)l; (void)sku; /* avoid unused parameter warning */
    return 0;
}

int List_remove_front(List *l, Item *out)
{
    /* TODO: implement, not forgetting to check if it is already empty */
    (void)l; (void)out; /* avoid unused parameter warning */
    return 0;
}

/* ------------------------------------------------------------------ *
 * observers
 * ------------------------------------------------------------------ */

size_t List_size(const List *l)
{
    /* TODO: return the maintained count.*/
    (void)l; /* avoid unused parameter warning */
    return 0;
}

int List_empty(const List *l)
{
    /* TODO */
    (void)l;
    return 1;
}

void List_clear(List *l)
{
    /* TODO: same freeing loop as List_destroy, but the List survives
     * and must be left genuinely reusable. */ 
    (void)l; /* avoid unused parameter warning */
}

void List_print(const List *l)
{
    /* TODO: exactly one line, exactly this shape:
     *     [ ]
     *     [ (101,"bolt",4) -> (102,"nut",9) ]
     * printf only.  No std::cout -- it is banned this week. */
    (void)l; /* avoid unused parameter warning */
}

void List_for_each(const List *l, void (*fn)(const Item *it, void *ctx),
                   void *ctx)
{
    /* TODO: call fn once per item, front to back, passing ctx
     * through untouched.  NULL fn is a no-op.  No Node * escapes --
     * this is how you get iteration out of an opaque type in C. */
    (void)l; (void)fn; (void)ctx; /* avoid unused parameter warning */
}
