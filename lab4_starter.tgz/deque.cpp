/* ------------------------------------------------------------------ *
 * deque.cpp -- ECE 412 Lab 4.  Your implementation of deque.h.
 *
 * Every function is stubbed.  Draw the box-and-arrow diagrams in
 * DIAGRAMS.md first -- empty, one element, many elements -- and write
 * each function from its diagram.  The diagram is the work; the code
 * is the transcription.
 *
 * Invariants to keep true before and after every public function:
 *   I1. head_ == NULL  <=>  tail_ == NULL  <=>  size_ == 0
 *   I2. head_->prev == NULL  and  tail_->next == NULL
 *   I3. for every node n with a next:  n->next->prev == n
 *   I4. size_ is the number of nodes reachable from head_
 *
 * Allowed: new/delete, std::cout.  Not allowed: malloc/free,
 * references, operators you define yourself, standard-library
 * containers.  See the table in README.md.
 * ------------------------------------------------------------------ */
#include <iostream>

#include "deque.h"

/* ---- lifetime ---------------------------------------------------- */

Deque::Deque()
{
    /* TODO: set head_, tail_ and size_ in a member-initializer list */
}

Deque::~Deque()
{
    /* TODO: delete every node */
}

void Deque::clear()
{
    /* TODO: walk the list deleting each node */ 
}

/* ---- the two ends ------------------------------------------------ */

void Deque::pushFront(int v)
{
    /* TODO: new Node(v) gives a node whose prev and next are NULL. */
    (void)v; /* avoid unused parameter warning */
}

void Deque::pushBack(int v)
{
    /* TODO: the mirror image of pushFront, through tail_ */ 
    (void)v; /* avoid unused parameter warning */
}

bool Deque::popFront(int *out)
{
    /* TODO: false (and *out untouched) if empty.  Otherwise write the
     * value to *out and return true */ 
    (void)out; /* avoid unused parameter warning */
    return false;
}

bool Deque::popBack(int *out)
{
    /* TODO: the mirror image of popFront, through tail_ and prev. */
    (void)out; /* avoid unused parameter warning */
    return false;
}

bool Deque::front(int *out) const
{
    /* TODO: peek.  false if empty; nothing is removed. */
    (void)out; /* avoid unused parameter warning */
    return false;
}

bool Deque::back(int *out) const
{
    /* TODO */
    (void)out; /* avoid unused parameter warning */
    return false;
}

/* ---- search and removal ------------------------------------------ */

bool Deque::contains(int v) const
{
    /* TODO */ 
    (void)v; /* avoid unused parameter warning */
    return false;
}

bool Deque::remove(int v)
{
    /* TODO: walk to the FIRST node holding v; false if there is none.
     * Then unlink it */ 
    (void)v; /* avoid unused parameter warning */
    return false;
}

/* ---- observers --------------------------------------------------- */

std::size_t Deque::size() const
{
    /* TODO: return the maintained counter.  */
    return 0;
}

bool Deque::empty() const
{
    /* TODO */
    return true;
}

void Deque::printForward() const
{
    /* TODO: one line, then '\n':
     *     [ ]                    empty
     *     [ 1 <-> 2 <-> 3 ]      head to tail  */
}

void Deque::printBackward() const
{
    /* TODO: the same format, tail to head, following prev */ 
}
