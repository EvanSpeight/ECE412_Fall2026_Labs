/* ------------------------------------------------------------------ *
 * queue.h -- ECE 412 Lab 4.  A queue built by composition.
 *
 * First in, first out: push at the back, pop from the front.  Write
 * it the way stack.h is written -- read that file first.
 *
 * Rules (the autograder checks every one):
 *   - Queue contains a Deque BY VALUE, as its only, private, data
 *     member.
 *   - No Node, no new/delete, no "->", no pointer other than passing
 *     `out` straight through to the Deque.
 *   - No constructor and no destructor.  WRITEUP.md asks you why
 *     none is needed.
 *
 * The declarations below are the required interface; keep them.
 * ------------------------------------------------------------------ */
#ifndef QUEUE_H
#define QUEUE_H

#include <cstddef>
#include "deque.h"

class Queue {
public:
    /* TODO: each body is one line that forwards to the Deque. */
    void push (int v)          { (void)v; }
    bool pop  (int *out)       { (void)out; return false; }
    bool front(int *out) const { (void)out; return false; }
    std::size_t size()  const  { return 0; }
    bool        empty() const  { return true; }
private:
    /* TODO: the one data member. */
};

#endif /* QUEUE_H */
