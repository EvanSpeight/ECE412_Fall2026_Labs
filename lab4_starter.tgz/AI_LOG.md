# AI log -- <your name>, <your EID>

Delete the bracketed instructions as you go.

[Required, even if the answer is "none". For each substantive use of an assistant: what you asked, what you got, what you changed and why. If you used one only to review code you had already written, say that. That's one of the best uses for AI!]
