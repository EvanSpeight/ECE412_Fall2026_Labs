# Lab 4 diagrams -- <your name>, <your EID>

Delete the bracketed instructions as you go. ASCII is fine; a photo of neat paper is fine too (commit the image and link it here).

For each operation, draw the three cases **before** you write the code. For each drawing, write down which pointer fields change, in the order your code changes them. Use `/` or `NULL` for a null pointer.

## pushFront(v)

```text
[EMPTY]

[ONE ELEMENT]

[MANY ELEMENTS]
```

## pushBack(v)

```text
[EMPTY]

[ONE ELEMENT]

[MANY ELEMENTS]
```

## popFront(&out)

```text
[EMPTY]

[ONE ELEMENT -- which pointers must end up NULL?]

[MANY ELEMENTS]
```

## popBack(&out)

```text
[EMPTY]

[ONE ELEMENT -- which pointers must end up NULL?]

[MANY ELEMENTS]
```

## remove(v)

```text
[HEAD node]

[MIDDLE node -- show both neighbours' arrows before and after]

[TAIL node]
```
