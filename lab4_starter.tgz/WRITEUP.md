# Lab 4 writeup -- <your name>, <your EID>

Delete the bracketed instructions as you go. Keep each part short and about your own code.

## Part B -- Stack and Queue

**Why neither class needs a constructor or a destructor.**

[Two sentences. Use L10's rule for when a member object's constructor and destructor run relative to the object that contains it.]

**What a Stack client cannot call.**

[Name three Deque operations that a Stack client cannot call. Pick one and describe what a client could do with it, if it were reachable, that would break "the last value pushed is the first value popped."]

## Part C -- cost table

**fixed** = the same number of steps for any list length; **a walk** = one step per node.

| Operation | Singly linked + tail (Lab 3) | Doubly linked + tail (Lab 4) |
|---|---|---|
| `pushFront` | fixed | |
| `pushBack` | | |
| `popFront` | fixed | |
| `popBack` | | |
| unlink a node, once you have found it | | |
| find by value | a walk | |
| bytes per node, `int` payload, our 64-bit machine | | |

[Justify every entry that changed from Lab 3 by counting the arrows your diagrams follow. Then state the memory trade: bytes per node, how many of them are the int, and which operations got cheaper in exchange.]

## Part D -- the destructor

[Quote your early-return test function from main.cpp. Say which line of it deletes the nodes, and why valgrind still reports no leak on the early-return path.]

## valgrind

[Paste the HEAP SUMMARY and ERROR SUMMARY lines from `valgrind --leak-check=full --show-leak-kinds=all ./dequetest`.]

```
```
