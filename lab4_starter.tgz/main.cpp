/* ------------------------------------------------------------------ *
 * main.cpp -- your test program for Lab 4.  Builds to ./dequetest.
 *
 * This file is a CLIENT of Deque, Stack and Queue.  It uses only
 * their public member functions.  Two rules this week:
 *   - never copy a Deque, Stack or Queue (no "Deque b = a;", no
 *     assigning one to another); pass one to a helper by pointer
 *   - every local is released by its destructor at its closing
 *     brace, so there is no destroy call to write -- and no reason
 *     to call a destructor or delete on a local yourself
 *
 * Three examples are written for you.  The list at the bottom is
 * yours; WRITEUP.md Part D quotes one of them.
 * ------------------------------------------------------------------ */
#include <cstdio>
#include <iostream>

#include "deque.h"
#include "stack.h"
#include "queue.h"

/* ---- a small test harness ---------------------------------------- */

static int g_checks = 0;
static int g_fails  = 0;

static void check(bool cond, const char *what)
{
    g_checks++;
    if (!cond) {
        g_fails++;
        std::cout << "  FAIL: " << what << '\n';
    }
}

/* Print both directions.  A deque can have a perfect next chain and
 * a broken prev chain; only the backward print shows it. */
static void show(const char *label, const Deque *d)
{
    std::cout << "  " << label << "  fwd: ";
    d->printForward();
    std::cout << "  " << label << "  bwd: ";
    d->printBackward();
}

/* ---- example 1: an empty deque answers every question ------------ */

static void test_empty(void)
{
    std::cout << "test_empty\n";

    Deque d;
    int   v = -1;

    check(d.size() == 0,   "fresh deque has size 0");
    check(d.empty(),       "fresh deque is empty");
    check(!d.popFront(&v), "popFront on empty returns false");
    check(!d.popBack(&v),  "popBack on empty returns false");
    check(!d.front(&v),    "front on empty returns false");
    check(v == -1,         "a failed call does not write *out");

    show("expecting [ ]", &d);
}                          /* ~Deque() runs here */

/* ---- example 2: the one-element popBack -------------------------- */

static void test_pop_back_only_node(void)
{
    std::cout << "test_pop_back_only_node\n";

    Deque d;
    int   v = 0;

    d.pushBack(7);
    check(d.popBack(&v) && v == 7, "popBack returns the only value");
    check(d.empty(),               "empty after popping the only node");

    /* If popBack left head_ pointing at the deleted node, this
     * pushFront writes through it.  It will often appear to work;
     * valgrind will not agree. */
    d.pushFront(9);
    check(d.size() == 1,           "size 1 after pushFront");
    check(d.front(&v) && v == 9,   "front is 9");
    check(d.back(&v)  && v == 9,   "back is 9");

    show("expecting [ 9 ]", &d);
}

/* ---- example 3: a Stack, which is given to you complete ---------- */

static void test_stack(void)
{
    std::cout << "test_stack\n";

    Stack s;
    int   v = 0;

    s.push(1);
    s.push(2);
    s.push(3);
    check(s.size() == 3,        "size 3");
    check(s.pop(&v) && v == 3,  "last pushed is first popped");
    check(s.pop(&v) && v == 2,  "then 2");
    check(s.pop(&v) && v == 1,  "then 1");
    check(s.empty(),            "empty");
}

/* ------------------------------------------------------------------ *
 * TODO -- write these.  The writeup and the valgrind check depend on
 * them.
 *
 *   test_push_front_cases   empty, one element, many; check front,
 *                           back, size, and show() both directions
 *   test_push_back_cases    the same three cases
 *   test_pop_front_cases    empty, one element (then pushBack
 *                           again), many
 *   test_pop_back_cases     the rest of the cases example 2 did not
 *                           cover
 *   test_remove_absent      returns false and changes nothing
 *   test_remove_only        the one-node deque; then push both ends
 *   test_remove_head
 *   test_remove_middle      check the backward print
 *   test_remove_tail        and then pushBack again
 *   test_clear_and_reuse    clear 5 elements, check empty, then
 *                           pushBack and pushFront again
 *   test_queue              first in, first out, including the empty
 *                           queue
 *   test_adapters_die_full  a Stack and a Queue that go out of scope
 *                           still holding values
 *   test_early_return       a helper that builds a Deque and returns
 *                           early on one path (WRITEUP.md Part D)
 *   test_many               >= 1000 values; spot-check, remove some,
 *                           drain
 *   test_heap_deque         a Deque made with new, released with
 *                           delete
 * ------------------------------------------------------------------ */

int main(void)
{
    test_empty();
    test_pop_back_only_node();
    test_stack();

    /* TODO: call your tests here. */

    std::cout << '\n' << g_checks << " checks, " << g_fails
              << " failures\n";
    return (g_fails == 0) ? 0 : 1;
}
