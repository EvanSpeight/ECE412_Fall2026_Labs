/* ------------------------------------------------------------------ *
 * public_tests.cpp -- ECE 412 Lab 6 provided tests.  Do not edit or
 *                     submit this file.
 *
 *     ./public_tests            every group
 *     ./public_tests deque      one group: deque, stack, queue, array
 *
 * Run it under valgrind as well.  Several of these tests pass every
 * check and still fail under valgrind if a copy shares memory.
 *
 * Two element types are defined here besides int and double:
 *
 *   Label      owns a heap string (like Lab 5's Named) and counts the
 *              Labels alive.  A container holding Labels must copy
 *              them with their own copy operations and destroy every
 *              one it made.
 *   NoDefault  has no default constructor.  Deque<T>, Stack<T> and
 *              Queue<T> never need T(), so they must work with it.
 * ------------------------------------------------------------------ */
#include <cstdio>
#include <cstring>
#include <iostream>

#include "deque.h"
#include "stack.h"
#include "queue.h"
#include "dynamic_array.h"

/* ---- harness ----------------------------------------------------- */

static int g_checks    = 0;
static int g_fails     = 0;
static int g_testFails = 0;

static void check_(bool cond, const char *expr, int line)
{
    g_checks++;
    if (!cond) {
        g_fails++;
        g_testFails++;
        std::cout << "    FAIL line " << line << ": " << expr << '\n';
    }
}
#define CHECK(cond) check_((cond), #cond, __LINE__)

/* ---- element types ----------------------------------------------- */

class Label {
public:
    Label()                : s_(dup(""))   { live++; }
    Label(const char *s)   : s_(dup(s))    { live++; }
    Label(const Label &o)  : s_(dup(o.s_)) { live++; }
    ~Label()                               { delete[] s_; live--; }
    Label &operator=(const Label &o)
    {
        if (this != &o) {
            char *fresh = dup(o.s_);
            delete[] s_;
            s_ = fresh;
        }
        return *this;
    }
    const char *str() const { return s_; }
    bool is(const char *s) const { return std::strcmp(s_, s) == 0; }

    static int live;                      // Labels currently alive
private:
    static char *dup(const char *s)
    {
        char *p = new char[std::strlen(s) + 1];
        std::strcpy(p, s);
        return p;
    }
    char *s_;
};
int Label::live = 0;

struct NoDefault {
    int v;
    NoDefault(int x) : v(x) {}
};

/* Explicit instantiation compiles EVERY member function of each class
 * for these types, used or not.  If your code only compiles for int
 * (a `T x = 0;`, a `std::cout << value`, a `T tmp;` in Deque<T>),
 * the build stops here. */
template class Deque<Label>;
template class Stack<Label>;
template class Queue<Label>;
template class DynamicArray<Label>;
template class Deque<NoDefault>;
template class Stack<NoDefault>;
template class Queue<NoDefault>;

static const char *WORDS[] = {
    "anvil", "brass", "cedar", "delta", "ember", "flint", "garnet",
    "harbor", "indigo", "jasper", "kettle", "lumen"
};
static const int NWORDS = (int)(sizeof WORDS / sizeof WORDS[0]);

/* ================================================================== *
 * deque
 * ================================================================== */

static void deque_empty(void)
{
    Deque<int> d;
    int x = -7;
    CHECK(d.size() == 0);
    CHECK(d.empty());
    CHECK(!d.popFront(&x));
    CHECK(!d.popBack(&x));
    CHECK(!d.front(&x));
    CHECK(!d.back(&x));
    CHECK(x == -7);
}

static void deque_both_ends(void)
{
    Deque<int> d;
    for (int i = 1; i <= 5; i++) d.pushBack(i);    /* 1 2 3 4 5     */
    d.pushFront(0);                                /* 0 1 2 3 4 5   */
    int x = -1;
    CHECK(d.size() == 6);
    CHECK(!d.empty());
    CHECK(d.front(&x) && x == 0);
    CHECK(d.back(&x) && x == 5);
    CHECK(d.popFront(&x) && x == 0);
    CHECK(d.popBack(&x) && x == 5);
    CHECK(d.popBack(&x) && x == 4);
    CHECK(d.popFront(&x) && x == 1);
    CHECK(d.size() == 2);
    CHECK(d.popFront(&x) && x == 2);
    CHECK(d.popFront(&x) && x == 3);
    CHECK(d.empty());
    CHECK(!d.popBack(&x) && x == 3);
    d.pushBack(9);                                 /* usable again  */
    CHECK(d.front(&x) && x == 9);
    CHECK(d.back(&x) && x == 9);
}

static void deque_double(void)
{
    Deque<double> d;
    d.pushBack(2.25);
    d.pushFront(1.125);
    d.pushBack(3.5);
    double x = 0.0;
    CHECK(d.popFront(&x) && x == 1.125);
    CHECK(d.popFront(&x) && x == 2.25);
    CHECK(d.popFront(&x) && x == 3.5);
}

static void deque_labels(void)
{
    int before = Label::live;
    {
        Deque<Label> d;
        for (int i = 0; i < NWORDS; i++) d.pushBack(Label(WORDS[i]));
        CHECK(d.size() == (std::size_t)NWORDS);
        Label x;
        CHECK(d.popFront(&x) && x.is("anvil"));
        CHECK(d.popBack(&x) && x.is("lumen"));
        CHECK(d.front(&x) && x.is("brass"));
        /* 10 Labels left in d, plus x */
    }
    CHECK(Label::live == before);                  /* all destroyed */
}

static void deque_clear(void)
{
    int before = Label::live;
    {
        Deque<Label> d;
        for (int i = 0; i < 5; i++) d.pushFront(Label(WORDS[i]));
        d.clear();
        CHECK(d.size() == 0);
        CHECK(d.empty());
        CHECK(Label::live == before);              /* nodes deleted */
        Label x("unchanged");
        CHECK(!d.popFront(&x) && x.is("unchanged"));
        d.pushBack(Label("again"));
        CHECK(d.size() == 1);
        CHECK(d.back(&x) && x.is("again"));
        d.clear();
        d.clear();                                 /* twice is fine */
        CHECK(d.empty());
    }
    CHECK(Label::live == before);
}

static void deque_copy(void)
{
    int before = Label::live;
    {
        Deque<Label> *orig = new Deque<Label>;
        for (int i = 0; i < NWORDS; i++) orig->pushBack(Label(WORDS[i]));
        Deque<Label> copy(*orig);
        CHECK(copy.size() == (std::size_t)NWORDS);
        delete orig;               /* the copy must not need it */
        Label x;
        for (int i = 0; i < NWORDS; i++) {
            CHECK(copy.popFront(&x) && x.is(WORDS[i]));
        }
        CHECK(copy.empty());

        Deque<int> a;
        a.pushBack(1);
        a.pushBack(2);
        Deque<int> b(a);
        b.pushBack(3);
        b.pushFront(0);
        CHECK(a.size() == 2);
        CHECK(b.size() == 4);
        int v = 0;
        CHECK(a.back(&v) && v == 2);

        Deque<int> e;
        Deque<int> e2(e);                          /* copy of empty */
        CHECK(e2.empty());
        e2.pushBack(5);
        CHECK(e.empty());
    }
    CHECK(Label::live == before);
}

static void deque_assign(void)
{
    int before = Label::live;
    {
        Deque<Label> longer, shorter, empty;
        for (int i = 0; i < 8; i++) longer.pushBack(Label(WORDS[i]));
        for (int i = 8; i < 10; i++) shorter.pushBack(Label(WORDS[i]));

        Deque<Label> a(longer);
        a = shorter;                         /* longer <- shorter */
        CHECK(a.size() == 2);
        Label x;
        CHECK(a.front(&x) && x.is("indigo"));
        CHECK(a.back(&x) && x.is("jasper"));

        Deque<Label> b(shorter);
        b = longer;                          /* shorter <- longer */
        CHECK(b.size() == 8);
        CHECK(b.front(&x) && x.is("anvil"));
        CHECK(b.back(&x) && x.is("harbor"));

        b.popFront(&x);                      /* b is independent */
        CHECK(longer.size() == 8);
        CHECK(longer.front(&x) && x.is("anvil"));

        Deque<Label> c(longer);
        c = empty;                           /* from empty */
        CHECK(c.empty());
        c.pushBack(Label("ok"));
        CHECK(c.size() == 1);

        Deque<Label> &alias = longer;
        longer = alias;                      /* self-assignment */
        CHECK(longer.size() == 8);
        CHECK(longer.front(&x) && x.is("anvil"));
        CHECK(longer.back(&x) && x.is("harbor"));

        Deque<Label> d;
        Deque<Label> &r = (d = shorter);     /* returns *this */
        CHECK(&r == &d);
    }
    CHECK(Label::live == before);
}

static void deque_no_default(void)
{
    Deque<NoDefault> d;
    d.pushBack(NoDefault(2));
    d.pushFront(NoDefault(1));
    NoDefault x(0);
    CHECK(d.size() == 2);
    CHECK(d.popBack(&x) && x.v == 2);
    CHECK(d.popBack(&x) && x.v == 1);
    CHECK(!d.popBack(&x) && x.v == 1);
}

/* ================================================================== *
 * stack
 * ================================================================== */

static void stack_lifo(void)
{
    Stack<int> s;
    int x = -1;
    CHECK(s.empty());
    CHECK(!s.pop(&x) && x == -1);
    CHECK(!s.top(&x) && x == -1);
    for (int i = 1; i <= 4; i++) s.push(i);
    CHECK(s.size() == 4);
    CHECK(s.top(&x) && x == 4);
    CHECK(s.size() == 4);
    for (int i = 4; i >= 1; i--) CHECK(s.pop(&x) && x == i);
    CHECK(s.empty());
}

static void stack_labels(void)
{
    int before = Label::live;
    {
        Stack<Label> s;
        for (int i = 0; i < 5; i++) s.push(Label(WORDS[i]));
        Stack<Label> copy(s);
        Label x;
        CHECK(copy.pop(&x) && x.is("ember"));
        CHECK(copy.size() == 4);
        CHECK(s.size() == 5);
        CHECK(s.top(&x) && x.is("ember"));

        Stack<Label> &alias = s;
        s = alias;                                 /* self-assign */
        CHECK(s.size() == 5);
        CHECK(s.top(&x) && x.is("ember"));

        s = copy;
        CHECK(s.size() == 4);
        CHECK(s.pop(&x) && x.is("delta"));
        CHECK(copy.size() == 4);
    }
    CHECK(Label::live == before);
}

static void stack_no_default(void)
{
    Stack<NoDefault> s;
    s.push(NoDefault(1));
    s.push(NoDefault(2));
    NoDefault x(0);
    CHECK(s.pop(&x) && x.v == 2);
    CHECK(s.top(&x) && x.v == 1);
}

/* ================================================================== *
 * queue
 * ================================================================== */

static void queue_fifo(void)
{
    Queue<int> q;
    int x = -1;
    CHECK(q.empty());
    CHECK(!q.pop(&x) && x == -1);
    CHECK(!q.front(&x) && x == -1);
    for (int i = 1; i <= 4; i++) q.push(i);
    CHECK(q.size() == 4);
    CHECK(q.front(&x) && x == 1);
    CHECK(q.size() == 4);
    for (int i = 1; i <= 4; i++) CHECK(q.pop(&x) && x == i);
    CHECK(q.empty());
}

static void queue_labels(void)
{
    int before = Label::live;
    {
        Queue<Label> q;
        for (int i = 0; i < 5; i++) q.push(Label(WORDS[i]));
        Queue<Label> copy(q);
        Label x;
        CHECK(copy.pop(&x) && x.is("anvil"));
        CHECK(copy.size() == 4);
        CHECK(q.size() == 5);
        CHECK(q.front(&x) && x.is("anvil"));

        Queue<Label> &alias = q;
        q = alias;                                 /* self-assign */
        CHECK(q.size() == 5);

        q = copy;
        CHECK(q.size() == 4);
        CHECK(q.pop(&x) && x.is("brass"));
        CHECK(copy.front(&x) && x.is("brass"));
    }
    CHECK(Label::live == before);
}

static void queue_no_default(void)
{
    Queue<NoDefault> q;
    q.push(NoDefault(1));
    q.push(NoDefault(2));
    NoDefault x(0);
    CHECK(q.pop(&x) && x.v == 1);
    CHECK(q.front(&x) && x.v == 2);
}

/* ================================================================== *
 * array
 * ================================================================== */

static void array_default(void)
{
    DynamicArray<int> a;
    int x = -3;
    CHECK(a.size() == 0);
    CHECK(a.capacity() == 0);
    CHECK(a.empty());
    CHECK(a.reallocCount() == 0);
    CHECK(a.copyCount() == 0);
    CHECK(!a.popBack(&x) && x == -3);
    CHECK(!a.at(0, &x) && x == -3);
}

static void array_initial_cap(void)
{
    DynamicArray<int> a(5);
    CHECK(a.size() == 0);
    CHECK(a.capacity() == 5);
    CHECK(a.reallocCount() == 0);
    for (int i = 0; i < 5; i++) a.pushBack(i * 10);
    CHECK(a.capacity() == 5);                  /* no growth yet */
    CHECK(a.reallocCount() == 0);
    a.pushBack(50);                            /* 5 -> 10        */
    CHECK(a.capacity() == 10);
    CHECK(a.reallocCount() == 1);
    CHECK(a.copyCount() == 5);
    for (int i = 0; i < 6; i++) CHECK(a[i] == i * 10);

    DynamicArray<int> z(0);
    CHECK(z.capacity() == 0);
    z.pushBack(7);
    CHECK(z.capacity() == 1);
    CHECK(z[0] == 7);
}

static void array_growth(void)
{
    /* after push k:      1  2  3  4  5  6  7  8  9 ... 16 17 */
    DynamicArray<int> a;
    const std::size_t at[]   = { 1, 2, 3,  5,  9, 17 };
    const std::size_t cap[]  = { 1, 2, 4,  8, 16, 32 };
    const std::size_t copy[] = { 0, 1, 3,  7, 15, 31 };
    int step = 0;
    for (std::size_t k = 1; k <= 17; k++) {
        a.pushBack((int)(k * k));
        if (step < 6 && k == at[step]) {
            CHECK(a.capacity() == cap[step]);
            CHECK(a.reallocCount() == (std::size_t)(step + 1));
            CHECK(a.copyCount() == copy[step]);
            step++;
        }
    }
    CHECK(a.size() == 17);
    for (std::size_t k = 1; k <= 17; k++) {
        CHECK(a[k - 1] == (int)(k * k));
    }
}

static void array_index_and_at(void)
{
    DynamicArray<int> a;
    for (int i = 0; i < 6; i++) a.pushBack(i);
    a[2] = 200;                                /* non-const []   */
    a[5] += 1;
    const DynamicArray<int> &c = a;
    CHECK(c[2] == 200);                        /* const []       */
    CHECK(c[5] == 6);
    CHECK(&c[3] == &a[3]);                     /* same element   */
    int x = -1;
    CHECK(a.at(0, &x) && x == 0);
    CHECK(a.at(5, &x) && x == 6);
    x = -1;
    CHECK(!a.at(6, &x) && x == -1);            /* i == size()    */
    CHECK(!a.at(1000, &x) && x == -1);
    CHECK(c.at(2, &x) && x == 200);            /* at is const    */
}

static void array_pop(void)
{
    DynamicArray<int> a;
    for (int i = 0; i < 5; i++) a.pushBack(i);
    std::size_t cap = a.capacity();
    int x = -1;
    for (int i = 4; i >= 0; i--) CHECK(a.popBack(&x) && x == i);
    CHECK(a.empty());
    CHECK(a.capacity() == cap);
    x = -1;
    CHECK(!a.popBack(&x) && x == -1);
    a.pushBack(42);
    CHECK(a.size() == 1);
    CHECK(a[0] == 42);
}

static void array_clear(void)
{
    DynamicArray<int> a;
    for (int i = 0; i < 9; i++) a.pushBack(i);
    std::size_t cap = a.capacity();
    std::size_t r   = a.reallocCount();
    std::size_t c   = a.copyCount();
    a.clear();
    CHECK(a.size() == 0);
    CHECK(a.empty());
    CHECK(a.capacity() == cap);
    CHECK(a.reallocCount() == r);
    CHECK(a.copyCount() == c);
    for (int i = 0; i < (int)cap; i++) a.pushBack(-i);
    CHECK(a.reallocCount() == r);              /* no growth      */
    CHECK(a[3] == -3);
}

static void array_reserve(void)
{
    DynamicArray<int> a;
    a.reserve(10);
    CHECK(a.capacity() == 10);
    CHECK(a.size() == 0);
    CHECK(a.reallocCount() == 1);
    CHECK(a.copyCount() == 0);
    a.reserve(5);                              /* smaller: nothing */
    a.reserve(10);                             /* equal: nothing   */
    CHECK(a.capacity() == 10);
    CHECK(a.reallocCount() == 1);
    for (int i = 0; i < 3; i++) a.pushBack(i + 1);
    a.reserve(20);                             /* copies 3         */
    CHECK(a.capacity() == 20);
    CHECK(a.reallocCount() == 2);
    CHECK(a.copyCount() == 3);
    CHECK(a[0] == 1 && a[1] == 2 && a[2] == 3);
    for (int i = 3; i < 21; i++) a.pushBack(i + 1);  /* 20 -> 40 */
    CHECK(a.capacity() == 40);
    CHECK(a.reallocCount() == 3);
    CHECK(a.copyCount() == 23);
}

static void array_copy(void)
{
    int before = Label::live;
    {
        DynamicArray<Label> *orig = new DynamicArray<Label>;
        for (int i = 0; i < NWORDS; i++) orig->pushBack(Label(WORDS[i]));
        DynamicArray<Label> copy(*orig);
        CHECK(copy.size() == (std::size_t)NWORDS);
        CHECK(copy.capacity() == orig->capacity());
        CHECK(copy.reallocCount() == 0);       /* it never grew */
        CHECK(copy.copyCount() == 0);
        copy[0] = Label("changed");
        CHECK((*orig)[0].is("anvil"));
        delete orig;               /* the copy must not need it */
        CHECK(copy[0].is("changed"));
        for (int i = 1; i < NWORDS; i++) CHECK(copy[i].is(WORDS[i]));

        DynamicArray<Label> e;
        DynamicArray<Label> e2(e);                 /* copy of empty */
        CHECK(e2.capacity() == 0);
        e2.pushBack(Label("x"));
        CHECK(e.size() == 0);
    }
    CHECK(Label::live == before);
}

static void array_assign(void)
{
    int before = Label::live;
    {
        DynamicArray<Label> longer, shorter, empty;
        for (int i = 0; i < 9; i++) longer.pushBack(Label(WORDS[i]));
        for (int i = 9; i < 11; i++) shorter.pushBack(Label(WORDS[i]));

        DynamicArray<Label> a(longer);
        std::size_t r = a.reallocCount();
        a = shorter;                         /* longer <- shorter */
        CHECK(a.size() == 2);
        CHECK(a.capacity() == shorter.capacity());
        CHECK(a[0].is("jasper") && a[1].is("kettle"));
        CHECK(a.reallocCount() == r);        /* counters unchanged */

        DynamicArray<Label> b(shorter);
        b = longer;                          /* shorter <- longer */
        CHECK(b.size() == 9);
        CHECK(b[8].is("indigo"));
        b[0] = Label("mine");
        CHECK(longer[0].is("anvil"));

        DynamicArray<Label> c(longer);
        c = empty;                           /* from empty */
        CHECK(c.size() == 0);
        CHECK(c.capacity() == 0);
        c.pushBack(Label("ok"));
        CHECK(c[0].is("ok"));

        DynamicArray<Label> &alias = longer;
        longer = alias;                      /* self-assignment */
        CHECK(longer.size() == 9);
        for (int i = 0; i < 9; i++) CHECK(longer[i].is(WORDS[i]));

        DynamicArray<Label> d;
        DynamicArray<Label> &rr = (d = shorter);   /* returns *this */
        CHECK(&rr == &d);
    }
    CHECK(Label::live == before);
}

static void array_labels_released(void)
{
    /* new Label[n] constructs n Labels; delete[] must destroy all n,
     * through every growth, clear and pop. */
    int before = Label::live;
    {
        DynamicArray<Label> a;
        for (int i = 0; i < 100; i++) {
            a.pushBack(Label(WORDS[i % NWORDS]));
        }
        Label x;
        a.popBack(&x);
        CHECK(x.is(WORDS[99 % NWORDS]));
        a.clear();
        a.pushBack(Label("after"));
        CHECK(a[0].is("after"));
    }
    CHECK(Label::live == before);
}

/* ================================================================== *
 * runner
 * ================================================================== */

struct Test {
    const char *group;
    const char *name;
    void (*fn)(void);
};

static const Test TESTS[] = {
    { "deque", "deque_empty",           deque_empty           },
    { "deque", "deque_both_ends",       deque_both_ends       },
    { "deque", "deque_double",          deque_double          },
    { "deque", "deque_labels",          deque_labels          },
    { "deque", "deque_clear",           deque_clear           },
    { "deque", "deque_copy",            deque_copy            },
    { "deque", "deque_assign",          deque_assign          },
    { "deque", "deque_no_default",      deque_no_default      },
    { "stack", "stack_lifo",            stack_lifo            },
    { "stack", "stack_labels",          stack_labels          },
    { "stack", "stack_no_default",      stack_no_default      },
    { "queue", "queue_fifo",            queue_fifo            },
    { "queue", "queue_labels",          queue_labels          },
    { "queue", "queue_no_default",      queue_no_default      },
    { "array", "array_default",         array_default         },
    { "array", "array_initial_cap",     array_initial_cap     },
    { "array", "array_growth",          array_growth          },
    { "array", "array_index_and_at",    array_index_and_at    },
    { "array", "array_pop",             array_pop             },
    { "array", "array_clear",           array_clear           },
    { "array", "array_reserve",         array_reserve         },
    { "array", "array_copy",            array_copy            },
    { "array", "array_assign",          array_assign          },
    { "array", "array_labels_released", array_labels_released },
};
static const int NTESTS = (int)(sizeof TESTS / sizeof TESTS[0]);

int main(int argc, char *argv[])
{
    const char *only = (argc > 1) ? argv[1] : NULL;
    int ran = 0, passed = 0;

    for (int i = 0; i < NTESTS; i++) {
        if (only != NULL && std::strcmp(only, TESTS[i].group) != 0) {
            continue;
        }
        g_testFails = 0;
        std::cout << TESTS[i].name << '\n';
        TESTS[i].fn();
        ran++;
        if (g_testFails == 0) {
            passed++;
        }
    }

    if (ran == 0) {
        std::cout << "no tests in group \"" << only << "\"; groups are "
                  << "deque, stack, queue, array\n";
        return 2;
    }
    std::cout << '\n' << passed << " of " << ran << " tests passed ("
              << g_checks << " checks, " << g_fails << " failed)\n";
    return (passed == ran) ? 0 : 1;
}
