/* ------------------------------------------------------------------ *
 * dynamic_array.h -- ECE 412 Lab 6, Part B.  DynamicArray<T>: a
 *                    growable array of T in one contiguous block.
 *
 * Header-only, like deque.h: the class declaration, then every
 * member definition.
 *
 * The class declaration is the specification.  Do not change it: the
 * autograder compiles its own test programs against it, including
 * the private section.  Write only the member definitions below it.
 *
 * Invariants to keep true before and after every public function:
 *   I1. capacity_ == 0  <=>  data_ == NULL
 *   I2. otherwise data_ points at an array of capacity_ T's from new[]
 *   I3. size_ <= capacity_
 *   I4. the elements are data_[0] .. data_[size_-1], in push order
 *   I5. reallocs_ and copies_ change only inside reallocate()
 *
 * new T[n] runs T() on all n slots, so T needs a default constructor.
 * Copy elements with =, one at a time.  Not allowed: malloc, free,
 * realloc, memcpy, memmove (README section 7).
 * ------------------------------------------------------------------ */
#ifndef DYNAMIC_ARRAY_H
#define DYNAMIC_ARRAY_H

#include <cstddef>

template <typename T>
class DynamicArray {
public:
    DynamicArray();                       // capacity 0, no allocation
    DynamicArray(std::size_t initialCap); // capacity initialCap; 0
                                          // allocates nothing
    ~DynamicArray();
    DynamicArray(const DynamicArray &other);
    DynamicArray &operator=(const DynamicArray &other);

    void pushBack(const T &v);            // grows first when full
    bool popBack(T *out);                 // false if empty

    T       &operator[](std::size_t i);       // NO bounds check:
    const T &operator[](std::size_t i) const; // i must be < size()

    bool at(std::size_t i, T *out) const; // bounds-checked: false (and
                                          // *out untouched) if
                                          // i >= size()

    std::size_t size()     const;
    std::size_t capacity() const;
    bool        empty()    const;
    void        clear();                  // size 0; capacity unchanged
    void        reserve(std::size_t n);   // capacity >= n afterwards

    // Instrumentation for Part C.  Both count work done by
    // reallocate() only, over this object's lifetime.
    std::size_t reallocCount() const;     // arrays replaced
    std::size_t copyCount()    const;     // elements copied doing it

private:
    void reallocate(std::size_t newCap);  // the only place the array
                                          // is replaced to grow
    static std::size_t nextCapacity(std::size_t cap);   // PROVIDED

    T          *data_;
    std::size_t size_;
    std::size_t capacity_;
    std::size_t reallocs_;
    std::size_t copies_;
};

/* ================================================================== *
 * Member definitions.  Same form as deque.h:
 *
 *     template <typename T>
 *     void DynamicArray<T>::pushBack(const T &v)
 * ================================================================== */

/* ---- PROVIDED: the growth rule ----------------------------------- */

/* Do not change.  Part C compares two rules.  An ordinary build
 * doubles; `make growth_fixed` defines FIXED_GROWTH, and every growth
 * adds 100 slots instead. */
template <typename T>
std::size_t DynamicArray<T>::nextCapacity(std::size_t cap)
{
#ifdef FIXED_GROWTH
    return cap + 100;
#else
    return (cap == 0) ? 1 : cap * 2;
#endif
}

/* ---- lifetime ---------------------------------------------------- */

template <typename T>
DynamicArray<T>::DynamicArray()
{
    /* TODO: member-initializer list.  No allocation: data_ is NULL. */
}

template <typename T>
DynamicArray<T>::DynamicArray(std::size_t initialCap)
{
    /* TODO: allocate initialCap slots, or nothing if initialCap is 0. */
    (void)initialCap; /* avoid unused parameter warning */
}

template <typename T>
DynamicArray<T>::~DynamicArray()
{
    /* TODO: Implement */ 
}

template <typename T>
DynamicArray<T>::DynamicArray(const DynamicArray &other)
{
    /* TODO: a new array of other.capacity_ slots (none if 0). */
    (void)other; /* avoid unused parameter warning */
}

template <typename T>
DynamicArray<T> &DynamicArray<T>::operator=(const DynamicArray &other)
{
    /* TODO: self-assignment guard.  Build the new array before
     * releasing the old one.  Afterwards size and capacity match
     * other's; this object's counters are unchanged. */
    (void)other; /* avoid unused parameter warning */
    return *this;
}

/* ---- growth ------------------------------------------------------ */

template <typename T>
void DynamicArray<T>::reallocate(std::size_t newCap)
{
    /* TODO:  Implement */
    (void)newCap; /* avoid unused parameter warning */
}

template <typename T>
void DynamicArray<T>::pushBack(const T &v)
{
    /* TODO: Implement */
    (void)v; /* avoid unused parameter warning */
}

template <typename T>
void DynamicArray<T>::reserve(std::size_t n)
{
    /* TODO: Implement */
    (void)n; /* avoid unused parameter warning */
}

/* ---- contents ---------------------------------------------------- */

template <typename T>
bool DynamicArray<T>::popBack(T *out)
{
    /* TODO: Implement */
    (void)out; /* avoid unused parameter warning */
    return false;
}

template <typename T>
T &DynamicArray<T>::operator[](std::size_t i)
{
    /* TODO: Implement in one line, no bounds check. Delete the placeholder; it is
     * here only so that the starter compiles. */
    (void)i; /* avoid unused parameter warning */
    static T placeholder;
    return placeholder;
}

template <typename T>
const T &DynamicArray<T>::operator[](std::size_t i) const
{
    /* TODO: the same line.  Delete the placeholder. */
    (void)i; /* avoid unused parameter warning */
    static T placeholder;
    return placeholder;
}

template <typename T>
bool DynamicArray<T>::at(std::size_t i, T *out) const
{
    /* TODO: false (and *out untouched) if i >= size_ */
    (void)i; (void)out; /* avoid unused parameter warnings */
    return false;
}

template <typename T>
void DynamicArray<T>::clear()
{
    /* TODO: size 0, capacity is unchanged. */
}

/* ---- observers --------------------------------------------------- */

template <typename T>
std::size_t DynamicArray<T>::size() const
{
    /* TODO */
    return 0;
}

template <typename T>
std::size_t DynamicArray<T>::capacity() const
{
    /* TODO */
    return 0;
}

template <typename T>
bool DynamicArray<T>::empty() const
{
    /* TODO */
    return true;
}

template <typename T>
std::size_t DynamicArray<T>::reallocCount() const
{
    /* TODO */
    return 0;
}

template <typename T>
std::size_t DynamicArray<T>::copyCount() const
{
    /* TODO */
    return 0;
}

#endif /* DYNAMIC_ARRAY_H */
