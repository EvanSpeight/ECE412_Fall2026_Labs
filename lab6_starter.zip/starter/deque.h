/* ------------------------------------------------------------------ *
 * deque.h -- ECE 412 Lab 6, Part A.  Lab 5's Deque as a class
 *            template: Deque<T> holds values of any type T.
 *
 * A template is compiled where it is used, so the whole class lives
 * in this header: the class declaration first, then every member
 * definition.  There is no deque.cpp.
 *
 * START HERE: move the bodies of your Lab 5 deque.cpp into the
 * definitions below and change int to T.  Fix anything Lab 5's
 * grader or valgrind found first: Stack<T> and Queue<T> are built on
 * this class.
 *
 * The class declaration is the specification.  Do not change it: the
 * autograder compiles its own test programs against it.  Write only
 * the member definitions below it.
 *
 * Invariants to keep true before and after every public function:
 *   I1. head_ == NULL  <=>  tail_ == NULL  <=>  size_ == 0
 *   I2. head_->prev == NULL  and  tail_->next == NULL
 *   I3. for every node n with a next:  n->next->prev == n
 *   I4. size_ is the number of nodes reachable from head_
 * ------------------------------------------------------------------ */
#ifndef DEQUE_H
#define DEQUE_H

#include <cstddef>

template <typename T>
class Deque {
public:
    Deque();                              // empty deque
    ~Deque();                             // deletes every node
    Deque(const Deque &other);            // deep copy, same order
    Deque &operator=(const Deque &other); // deep copy, same order

    void   pushFront(const T &v);         // stores a copy of v
    void   pushBack (const T &v);
    bool   popFront(T *out);              // false if empty
    bool   popBack (T *out);              // false if empty

    bool   front(T *out) const;           // peek, no removal
    bool   back (T *out) const;

    std::size_t size()  const;            // keep a counter; never walk
    bool        empty() const;
    void        clear();                  // delete every node; the deque
                                          // stays usable afterwards
private:
    struct Node {
        T     value;
        Node *prev;
        Node *next;
        Node(const T &v) : value(v), prev(NULL), next(NULL) {}
    };
    Node       *head_;
    Node       *tail_;
    std::size_t size_;
};

/* ================================================================== *
 * Member definitions.
 *
 * Each definition starts with its own template line, and the class
 * is named Deque<T> in front of the :: --
 *
 *     template <typename T>
 *     void Deque<T>::pushBack(const T &v)
 *
 * After Deque<T>:: the class name may be written plain Deque, as in
 * the parameter lists below.  A return type comes before the ::, so
 * it needs the <T>: see operator=.
 * ================================================================== */

/* ---- lifetime ---------------------------------------------------- */

template <typename T>
Deque<T>::Deque()
{
    /* TODO: member-initializer list */
}

template <typename T>
Deque<T>::~Deque()
{
    /* TODO: delete every node */
}

template <typename T>
Deque<T>::Deque(const Deque &other)
{
    /* TODO: The copy has the same order and its own nodes. */
    (void)other; /* avoid unused parameter warning */
}

template <typename T>
Deque<T> &Deque<T>::operator=(const Deque &other)
{
    /* TODO: a = a must leave a unchanged. */
    (void)other; /* avoid unused parameter warning */
    return *this;
}

template <typename T>
void Deque<T>::clear()
{
    /* TODO: delete every node; the deque stays usable */
}

/* ---- the two ends ------------------------------------------------ */

template <typename T>
void Deque<T>::pushFront(const T &v)
{
    /* TODO: new Node(v) copies v once, into the node. */
    (void)v; /* avoid unused parameter warning */
}

template <typename T>
void Deque<T>::pushBack(const T &v)
{
    /* TODO: the mirror image of pushFront, through tail_ */
    (void)v; /* avoid unused parameter warning */
}

template <typename T>
bool Deque<T>::popFront(T *out)
{
    /* TODO: false (and *out untouched) if empty.  Otherwise write the
     * value to *out and return true. */
    (void)out; /* avoid unused parameter warning */
    return false;
}

template <typename T>
bool Deque<T>::popBack(T *out)
{
    /* TODO: the mirror image of popFront, through tail_ and prev */
    (void)out; /* avoid unused parameter warning */
    return false;
}

template <typename T>
bool Deque<T>::front(T *out) const
{
    /* TODO: peek.  false if empty; nothing is removed. */
    (void)out; /* avoid unused parameter warning */
    return false;
}

template <typename T>
bool Deque<T>::back(T *out) const
{
    /* TODO */
    (void)out; /* avoid unused parameter warning */
    return false;
}

/* ---- observers --------------------------------------------------- */

template <typename T>
std::size_t Deque<T>::size() const
{
    /* TODO: return the maintained counter */
    return 0;
}

template <typename T>
bool Deque<T>::empty() const
{
    /* TODO */
    return true;
}

#endif /* DEQUE_H */
