/* ------------------------------------------------------------------ *
 * main.cpp -- your test program for Lab 6.  Builds to ./lab6test.
 *
 * This file is a CLIENT of Deque<T>, Stack<T>, Queue<T> and
 * DynamicArray<T>.  It uses only their public member functions.
 *
 * Every container must be used with at least two element types, one
 * of them not built in.  Point, below, is the user-defined one; it
 * has a default constructor because DynamicArray<Point> needs one.
 *
 * Three examples are written for you.  The list at the bottom is
 * yours; WRITEUP.md quotes some of them.
 * ------------------------------------------------------------------ */
#include <cstdio>
#include <iostream>

#include "deque.h"
#include "stack.h"
#include "queue.h"
#include "dynamic_array.h"

/* ---- a small test harness ---------------------------------------- */

static int g_checks = 0;
static int g_fails  = 0;

static void check(bool cond, const char *what)
{
    g_checks++;
    if (!cond) {
        g_fails++;
        std::cout << "  FAIL: " << what << '\n';
    }
}

/* ---- a user-defined element type --------------------------------- */

struct Point {
    int x;
    int y;
    Point() : x(0), y(0) {}
    Point(int px, int py) : x(px), y(py) {}
};

static bool samePoint(const Point &a, const Point &b)
{
    return a.x == b.x && a.y == b.y;
}

/* ---- example 1: one Deque class, two element types --------------- */

static void test_deque_two_types(void)
{
    std::cout << "test_deque_two_types\n";

    Deque<double> dd;
    dd.pushBack(1.5);
    dd.pushFront(0.5);
    double d = 0.0;
    check(dd.size() == 2,                    "two doubles");
    check(dd.popFront(&d) && d == 0.5,       "front is 0.5");
    check(dd.popBack(&d) && d == 1.5,        "back is 1.5");

    Deque<Point> dp;
    dp.pushBack(Point(1, 2));
    dp.pushBack(Point(3, 4));
    Point p;
    check(dp.front(&p) && samePoint(p, Point(1, 2)), "front (1,2)");
    check(dp.back(&p)  && samePoint(p, Point(3, 4)), "back (3,4)");
    check(dp.size() == 2,                    "peeking removes nothing");
}

/* ---- example 2: copying a Stack ---------------------------------- */

/* stack.h declares no copy constructor.  The compiler writes one,
 * and it copies d_ by calling Deque<T>'s copy constructor.  If that
 * function is still the stub, the copy is empty; if it shares nodes,
 * valgrind reports the second delete of each one. */
static void test_stack_copy(void)
{
    std::cout << "test_stack_copy\n";

    Stack<Point> s;
    for (int i = 0; i < 4; i++) {
        s.push(Point(i, i * i));
    }
    Stack<Point> copy(s);              /* the compiler-written copy */

    Point p;
    check(copy.pop(&p) && samePoint(p, Point(3, 9)), "copy pops (3,9)");
    check(copy.size() == 3,            "copy shrank");
    check(s.size() == 4,               "original did not");
    check(s.top(&p) && samePoint(p, Point(3, 9)),    "original top");
}

/* ---- example 3: reading through a const reference ---------------- */

/* a is const, so a[i] must call the const operator[].  WRITEUP.md
 * asks what happens to this function without that overload. */
static int sumAll(const DynamicArray<int> &a)
{
    int total = 0;
    for (std::size_t i = 0; i < a.size(); i++) {
        total += a[i];
    }
    return total;
}

static void test_array_const_access(void)
{
    std::cout << "test_array_const_access\n";

    DynamicArray<int> a;
    for (int i = 1; i <= 10; i++) {
        a.pushBack(i);
    }
    check(a.size() == 10,              "size 10");
    check(sumAll(a) == 55,             "1 + 2 + ... + 10 == 55");
    a[0] = 100;                        /* the non-const operator[] */
    check(sumAll(a) == 154,            "write through a[0]");
}

/* ------------------------------------------------------------------ *
 * TODO -- write these.  The writeup and the valgrind check depend on
 * them.  Each container needs two element types between them.
 *
 *   test_deque_copy           copy a Deque<Point>; change the copy;
 *                             check the original did not change
 *   test_deque_assign         into a longer deque, a shorter one, an
 *                             empty one; self-assignment
 *   test_stack                last in, first out with int and Point;
 *                             pop and top on empty; self-assignment
 *   test_queue                first in, first out with int and Point;
 *                             copy; self-assignment
 *   test_array_push_pop       pushBack, popBack to empty; popBack on
 *                             empty leaves *out untouched
 *   test_array_at             in range, i == size(), far past it
 *   test_array_growth         from empty through at least four
 *                             growths; check capacity(),
 *                             reallocCount() and copyCount() after
 *                             each, and every element at the end
 *   test_array_copy           DynamicArray<Point> of >= 10; make the
 *                             original with new, copy it, delete the
 *                             original, read every element of the copy
 *   test_array_assign         longer <- shorter, shorter <- longer,
 *                             from an empty one; self-assignment
 *   test_array_clear_reserve  clear keeps capacity; pushes after clear
 *                             cause no growth; reserve larger and
 *                             smaller than capacity()
 * ------------------------------------------------------------------ */

int main(void)
{
    test_deque_two_types();
    test_stack_copy();
    test_array_const_access();

    /* TODO: call your tests here. */

    std::cout << '\n' << g_checks << " checks, " << g_fails
              << " failures\n";
    return (g_fails == 0) ? 0 : 1;
}
