# Lab 6 writeup -- <your name>, <your EID>

Delete the bracketed instructions as you go. Keep each part short and about your own code.

## Part A -- Deque, Stack, Queue

**What changed.**

[Compare your Lab 5 `deque.cpp` with your new `deque.h` (`diff` helps). List the kinds of change you made. Did any line that reads or writes `head_`, `tail_`, `prev` or `next` change? What does that say about which part of `Deque` depends on the element type?]

**`const T &`.**

[Suppose `T` is a type whose copy constructor allocates, and a client calls `d.pushBack(x)`. How many times is `x` copied with the declared parameter `const T &v`? How many times if the parameter were `T v`? Say where each copy happens.]

**Copying a `Stack<T>`.**

[`stack.h` declares no copy constructor and no `operator=`, yet the provided tests copy and assign `Stack<Label>` and valgrind reports no errors. What does the compiler-written copy constructor of `Stack<T>` do with `d_`, and which of your functions does that call?]

## Part B -- DynamicArray

**The two `operator[]`s.**

[1. With both versions present, which one does `a[i]` in `sumAll` call, and which does `a[0] = 100` in `test_array_const_access` call? How does the compiler choose?]

[2. Without the `const` version: quote the first error. Which line does it name, and what is it objecting to?]

**Default constructors.**

[The provided tests' `NoDefault` has no default constructor. `Deque<NoDefault>` stores and returns values; a `DynamicArray<NoDefault>` cannot even `pushBack` one without a compile error. Quote the line in each of your headers that decides this, and say what each line asks of `T`.]

**`clear` keeps the array.**

[`clear()` sets the size to 0 and leaves the capacity alone. Give one reason this is the better choice for a program that empties an array and fills it again. What does the kept array cost a program that never fills it again?]

## Part C -- Growth

[Paste the output of `./growth_test` for n = 1,000, 10,000, 100,000 and 1,000,000, and of `time ./growth_test` and `time ./growth_fixed` for n = 1,000,000.]

```
```

1. [How does `reallocCount()` grow with n, and why?]
2. [Copies per push varies from run to run. What bound does it never exceed, and why that bound? Work it out from your own numbers.]
3. [One `pushBack` can copy every element in the array, yet the average over all n pushes is a small number of copies. Explain how both are true.]
4. [Under the fixed rule (add 100 slots), how does `copyCount()` grow with n? Compare its numbers and its time with the doubling version's.]

## valgrind

[Paste the HEAP SUMMARY and ERROR SUMMARY lines from `valgrind --leak-check=full --show-leak-kinds=all ./lab6test`.]

```
```
