/* ------------------------------------------------------------------ *
 * growth_test.cpp -- ECE 412 Lab 6, Part C.  Measures the cost of
 *                    growing a DynamicArray<int> one push at a time.
 *
 *     make growth_test       the doubling rule
 *     make growth_fixed      the same program, adding 100 slots per
 *                            growth (built with -DFIXED_GROWTH)
 *
 *     ./growth_test          n = 1,000,000 pushes
 *     ./growth_test 5000     any other n
 *
 * The report is printed for you.  Write the pushes.
 * ------------------------------------------------------------------ */
#include <cstdlib>
#include <iostream>

#include "dynamic_array.h"

int main(int argc, char *argv[])
{
    std::size_t n = 1000000;
    if (argc > 1) {
        n = std::strtoul(argv[1], NULL, 10);
    }

    DynamicArray<int> a;

    /* TODO: n calls to a.pushBack.  The values do not matter. */

#ifdef FIXED_GROWTH
    std::cout << "growth rule      add 100 slots\n";
#else
    std::cout << "growth rule      double\n";
#endif
    std::cout << "pushes           " << n                << '\n'
              << "size()           " << a.size()         << '\n'
              << "capacity()       " << a.capacity()     << '\n'
              << "reallocCount()   " << a.reallocCount() << '\n'
              << "copyCount()      " << a.copyCount()    << '\n';
    if (n > 0) {
        std::cout << "copies per push  "
                  << (double)a.copyCount() / (double)n << '\n';
    }
    return 0;
}
