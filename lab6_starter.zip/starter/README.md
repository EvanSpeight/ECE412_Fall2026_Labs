# ECE 412 -- Lab 6: Templates and Generic Containers

| | |
|---|---|
| **Assigned** | Thu Oct 22 |
| **Due** | **Wed Oct 28, 11:59 pm** (Gradescope) |
| **Weight** | 1% |
| **Builds on** | L13 (templates) · L17 (amortized cost) · your Lab 5 `Deque` · Lab 5's Rule of Three on an owned array (`Inventory`) |
| **Language** | C++11 — `g++ -std=c++11 -Wall -Wextra -Werror -g` |
| **Work** | Individual |

## 1. What you will build

Your Lab 5 `Deque` holds `int`. A deque of `double`, or of `Point`, would need a second copy of the class with one word changed, and every later fix made twice. A class template is written once with the element type as a parameter, `T`; the compiler writes the `int` version, the `double` version and the `Point` version from it as the program uses them.

This lab has four class templates:

- **`Deque<T>`**, your Lab 5 `Deque` with `int` replaced by `T`.
- **`Stack<T>`** and **`Queue<T>`**, Lab 4's `Stack` and `Queue`, built on `Deque<T>` by composition as before.
- **`DynamicArray<T>`**, a growable array: elements side by side in one block from `new[]`, any element reached by its index in one step, and a bigger block allocated whenever the current one fills. It counts its own growth work.

```text
Composition (has-a), now with a type parameter

    Stack<T>                 Queue<T>
      '-- Deque<T>  d_         '-- Deque<T>  d_

Ownership

    DynamicArray<T>
      '-- T  *data_          an array it allocates, grows and frees
```

The lab has three parts:

- **Part A (`Deque<T>`, `Stack<T>`, `Queue<T>`).** Convert your Lab 5 `Deque` into a template, then make `Stack` and `Queue` templates on top of it.
- **Part B (`DynamicArray<T>`).** Write the growable array, including its Rule of Three, two versions of `operator[]` and a bounds-checked `at`.
- **Part C (growth).** Push a million values into a `DynamicArray<int>`, read its counters, and compare growth by doubling with growth by a fixed 100 slots.

## 2. What you start with

| File | Status | What you do with it |
|---|---|---|
| `deque.h` | declaration + stubs | Move your Lab 5 code into the stubs. **Do not change the class declaration.** |
| `stack.h`, `queue.h` | declaration + stubs | Write the one-line bodies. **Do not change the declarations.** |
| `dynamic_array.h` | declaration + stubs | Write every function. **Do not change the class declaration** or the provided `nextCapacity`. |
| `main.cpp` | partial | Your own tests. Three are written; the list of the rest is in the file. |
| `growth_test.cpp` | partial | Part C. The report is written; you write the pushes. |
| `tests/public_tests.cpp` | complete | A provided test suite. Do not edit or submit it. |
| `WRITEUP.md`, `AI_LOG.md` | templates | Fill in. |
| `Makefile` | **missing** | You write it (Step 0). |

There are no `.cpp` files for the containers. A template is compiled where it is used, so each header holds its class declaration and, below it, every member definition (Section 4.1).

The class declarations are the specification: the autograder compiles its own tests against them, so they must stay exactly as given. Each stub has a comment saying what the function must do; Section 4 has the full specification.

The stubs compile clean with the course flags and do nothing useful, so nearly every test fails until you write the code.

## 3. How to proceed

Work in this order. Each step builds on the one before, and each ends with a test you can run before you move on. `./public_tests` runs the provided tests; give it a group name (`deque`, `stack`, `queue`, `array`) to run only that group.

### Step 0 — Get it building

1. Write the `Makefile` (Section 5).
2. Run `make` and `make check`. Everything should compile with no warnings, and most tests should fail.

**Done when:** `make` builds `./lab6test` and `./growth_test` with no warnings.

### Step 1 — `Deque<T>` (Part A)

Move the bodies of your Lab 5 `deque.cpp` into the stubs in `deque.h` and change `int` to `T` (Section 4.1). Fix anything Lab 5's grader or valgrind reported first: `Stack<T>` and `Queue<T>` are built on this class.

**Done when:** `./public_tests deque` passes under valgrind, and `main.cpp`'s example 1 (`test_deque_two_types`) passes.

### Step 2 — `Stack<T>` and `Queue<T>` (Part A)

Write the five one-line bodies in each of `stack.h` and `queue.h` (Section 4.2).

**Done when:** `./public_tests stack` and `./public_tests queue` pass under valgrind, and example 2 (`test_stack_copy`) passes.

### Step 3 — `DynamicArray<T>` without copying (Part B)

Write the two constructors, the destructor, `reallocate`, `pushBack`, `reserve`, `popBack`, both `operator[]`, `at`, `clear` and the observers (Section 4.3). Leave the copy constructor and `operator=` for Step 4.

**Done when:** every test in `./public_tests array` passes except `array_copy` and `array_assign`, and example 3 (`test_array_const_access`) passes.

### Step 4 — `DynamicArray<T>`'s Rule of Three (Part B)

Write the copy constructor and `operator=`. They follow the same pattern as Lab 5's `Inventory`.

**Done when:** `./public_tests array` passes under valgrind.

### Step 5 — The two `operator[]`s (Part B)

On a scratch copy of `dynamic_array.h`, remove the `const` version of `operator[]` and rebuild (Section 4.4). Restore the file afterward. Answer the Part B questions in `WRITEUP.md`.

**Done when:** `WRITEUP.md` Part B is complete and `dynamic_array.h` is back to the version that passes Step 4.

### Step 6 — Measure growth (Part C)

Write the pushes in `growth_test.cpp`, run it for several values of n, then run the fixed-growth version (Section 4.5). Answer the Part C questions in `WRITEUP.md`.

**Done when:** `WRITEUP.md` Part C is complete.

### Step 7 — Finish

1. Write the rest of the tests listed at the bottom of `main.cpp` (Section 6 lists what they must cover).
2. Run both programs under valgrind (Section 6) until both report 0 errors and 0 bytes lost.
3. Complete `WRITEUP.md` (Part A and the valgrind summary) and `AI_LOG.md`.
4. Work through the checklist in Section 9 and submit.

## 4. Specification

### 4.1 `Deque<T>`

```cpp
template <typename T>
class Deque {
public:
    Deque();                              // empty deque
    ~Deque();                             // deletes every node
    Deque(const Deque &other);            // deep copy, same order
    Deque &operator=(const Deque &other); // deep copy, same order

    void   pushFront(const T &v);         // stores a copy of v
    void   pushBack (const T &v);
    bool   popFront(T *out);              // false if empty
    bool   popBack (T *out);              // false if empty

    bool   front(T *out) const;           // peek, no removal
    bool   back (T *out) const;

    std::size_t size()  const;            // keep a counter; never walk
    bool        empty() const;
    void        clear();                  // delete every node; the deque
                                          // stays usable afterwards
private:
    struct Node {
        T     value;
        Node *prev;
        Node *next;
        Node(const T &v) : value(v), prev(NULL), next(NULL) {}
    };
    Node       *head_;
    Node       *tail_;
    std::size_t size_;
};
```

The behavior of every function is Lab 5's. Three kinds of change turn Lab 5's code into this:

- **The template line.** Each member definition below the class starts with `template <typename T>`, and the class is named `Deque<T>` before the `::`. A return type comes before the `::`, so it needs the `<T>` too:

  ```cpp
  template <typename T>
  void Deque<T>::pushBack(const T &v)

  template <typename T>
  Deque<T> &Deque<T>::operator=(const Deque &other)
  ```

- **`int` becomes `T`** wherever it means "a value in the deque". `std::size_t size_` stays as it is: a count is a count whatever the element type.
- **Parameters are `const T &`, not `T`.** For `int` this makes no difference. For a `T` whose copy constructor allocates, passing by value copies the argument once into the parameter and again into the node; passing by `const` reference copies it once, into the node. `WRITEUP.md` asks you to count.

**`contains`, `remove` and the print functions are gone.** `contains` and `remove` compare values with `==`, and the print functions write them with `<<`. A template asks of `T` exactly what its code uses, so with those functions every element type would need `==` and `<<`. The provided tests use a type, `NoDefault`, that has neither, and no default constructor either: `Deque<T>` must compile and work for it. Code such as `T tmp;` or `T x = 0;` compiles for `int` and fails for `NoDefault`.

**Everything is in the header.** The compiler writes `Deque<double>::pushBack` only where it can see the definition of `Deque<T>::pushBack`. A definition in a separate `deque.cpp` is not visible to `main.cpp`, so the build fails at the link step with errors such as `undefined reference to Deque<double>::pushBack(double const&)`. That message names a function that is missing; the cause is a definition the compiler could not see.

### 4.2 `Stack<T>` and `Queue<T>`

```cpp
template <typename T>
class Stack {
public:
    void push(const T &v);                // last in, first out
    bool pop (T *out);                    // false if empty
    bool top (T *out) const;              // peek; false if empty
    std::size_t size()  const;
    bool        empty() const;
private:
    Deque<T> d_;                          // a Stack contains a Deque
};

template <typename T>
class Queue {
public:
    void push (const T &v);               // first in, first out
    bool pop  (T *out);                   // false if empty
    bool front(T *out) const;             // peek; false if empty
    std::size_t size()  const;
    bool        empty() const;
private:
    Deque<T> d_;                          // a Queue contains a Deque
};
```

Each body is one line that forwards to `d_`, as in Lab 4: a `Stack` pushes and pops at the front; a `Queue` pushes at the back and pops at the front. Neither class declares a constructor, a destructor, a copy constructor or `operator=`, and you do not add any. The provided tests copy and assign both.

### 4.3 `DynamicArray<T>`

```cpp
template <typename T>
class DynamicArray {
public:
    DynamicArray();                       // capacity 0, no allocation
    DynamicArray(std::size_t initialCap); // capacity initialCap; 0
                                          // allocates nothing
    ~DynamicArray();
    DynamicArray(const DynamicArray &other);
    DynamicArray &operator=(const DynamicArray &other);

    void pushBack(const T &v);            // grows first when full
    bool popBack(T *out);                 // false if empty

    T       &operator[](std::size_t i);       // NO bounds check:
    const T &operator[](std::size_t i) const; // i must be < size()

    bool at(std::size_t i, T *out) const; // bounds-checked: false (and
                                          // *out untouched) if
                                          // i >= size()

    std::size_t size()     const;
    std::size_t capacity() const;
    bool        empty()    const;
    void        clear();                  // size 0; capacity unchanged
    void        reserve(std::size_t n);   // capacity >= n afterwards

    // Instrumentation for Part C.  Both count work done by
    // reallocate() only, over this object's lifetime.
    std::size_t reallocCount() const;     // arrays replaced
    std::size_t copyCount()    const;     // elements copied doing it

private:
    void reallocate(std::size_t newCap);  // the only place the array
                                          // is replaced to grow
    static std::size_t nextCapacity(std::size_t cap);   // PROVIDED

    T          *data_;
    std::size_t size_;
    std::size_t capacity_;
    std::size_t reallocs_;
    std::size_t copies_;
};
```

The array after five pushes into an array of capacity 8:

```text
    data_ --> +----+----+----+----+----+----+----+----+
              | 10 | 20 | 30 | 40 | 50 |    |    |    |
              +----+----+----+----+----+----+----+----+
               [0]  [1]  [2]  [3]  [4]
              |<-- size_ = 5 --------->|
              |<-- capacity_ = 8 -------------------->|
```

Slots `[5]` to `[7]` hold default-constructed `T`s from `new T[8]`. They are not elements: only `data_[0]` to `data_[size_-1]` are.

Behavior:

- **Default constructor.** Capacity 0, `data_` is `NULL`, nothing allocated. All counters 0.
- **`DynamicArray(initialCap)`.** Allocates `new T[initialCap]`, or nothing if `initialCap` is 0. Constructing is not growth: both counters start at 0.
- **`reallocate(newCap)`** is the only function that replaces the array to make room: `new T[newCap]`, copy the `size_` elements across one at a time with `=`, `delete[]` the old array, update `data_` and `capacity_`. It then adds 1 to `reallocs_` and `size_` to `copies_`. Nothing else changes those two counters.
- **`pushBack`** first calls `reallocate(nextCapacity(capacity_))` if `size_ == capacity_`, then stores `v` in `data_[size_]` and increments `size_`. `nextCapacity` is provided: it doubles, and gives 1 for a capacity of 0.
- **`reserve(n)`** calls `reallocate(n)` if `n > capacity_`, and otherwise does nothing.
- **`popBack`** returns `false` and leaves `*out` untouched if the array is empty. Otherwise it writes the last element to `*out`, decrements `size_` and returns `true`. Capacity is unchanged.
- **`operator[]`** returns `data_[i]` with no check. An index at or past `size()` is the caller's error, and its result is undefined. The non-`const` version returns `T &`, so `a[i] = v` writes into the array; the `const` version returns `const T &`.
- **`at`** is the checked version: `false` (and `*out` untouched) if `i >= size()`.
- **`clear`** sets `size_` to 0 and keeps the array. Capacity and both counters are unchanged.
- **Destructor.** `delete[] data_`. Deleting `NULL` does nothing, so an array that never allocated needs no special case.
- **Copy constructor.** A new array of `other.capacity_` slots (none if 0), with `other`'s `size_` elements copied in, not its `capacity_` slots. Both counters start at 0: they count this object's growth, and a fresh copy has not grown.
- **`operator=`.** Self-assignment check; build the new array before releasing the old one; afterwards size and capacity match `other`'s. This object's counters are unchanged.

`new T[n]` runs `T()` on every one of the `n` slots, so `DynamicArray<T>` needs `T` to have a default constructor. `Deque<T>` does not: a `Node` is built from a value with `T`'s copy constructor. `WRITEUP.md` asks you to find the line in each class that decides this.

**Copy elements with `=`, one at a time.** For an element that owns memory, such as Lab 5's `Named` or the provided tests' `Label`, `=` runs that type's `operator=`, which copies what it owns. `memcpy` copies the bytes, including the pointer, so both arrays share each element's memory and both delete it. Section 7 does not allow it.

### 4.4 The two `operator[]`s

`main.cpp`'s example 3 has a function that reads an array through a `const` reference:

```cpp
static int sumAll(const DynamicArray<int> &a)
{
    int total = 0;
    for (std::size_t i = 0; i < a.size(); i++) {
        total += a[i];
    }
    return total;
}
```

On a scratch copy of `dynamic_array.h`, delete the `const` version of `operator[]`: its declaration and its definition. Rebuild with `make`, then answer in `WRITEUP.md`:

1. With both versions present, which one does `a[i]` in `sumAll` call, and which does `a[0] = 100` in `test_array_const_access` call? How does the compiler choose?
2. Without the `const` version, quote the first error. Which line does it name, and what is it objecting to?

Restore `dynamic_array.h` afterward.

### 4.5 Part C: measuring growth

`growth_test.cpp` is a separate program. It pushes n values into a `DynamicArray<int>` and prints `size()`, `capacity()`, `reallocCount()`, `copyCount()` and copies per push. You write the loop of pushes; the report is written for you.

```
make growth_test               # the doubling rule
./growth_test                  # n = 1,000,000
./growth_test 1000             # any other n

make growth_fixed              # same program, -DFIXED_GROWTH:
./growth_fixed                 # every growth adds 100 slots
```

`make growth_fixed` compiles `dynamic_array.h` with `FIXED_GROWTH` defined, which switches the provided `nextCapacity` from doubling to adding 100. Nothing else changes. With n = 1,000,000 it takes several seconds to tens of seconds; run it with `time` and report that too. Do not run either growth program under valgrind.

Then answer in `WRITEUP.md`:

1. Run `./growth_test` with n = 1,000, 10,000, 100,000 and 1,000,000. How does `reallocCount()` grow with n, and why?
2. Copies per push varies from run to run. What bound does it never exceed, and why that bound? Work it out from your own numbers.
3. One `pushBack` can copy every element in the array. Yet the average over all n pushes is a small number of copies. Explain how both are true. (This is what **amortized** cost means.)
4. Run `./growth_fixed` with n = 1,000,000. Report its numbers and its time next to the doubling version's. How does `copyCount()` grow with n under this rule?

## 5. The Makefile

Write it yourself, modeled on Lab 5's. It must have:

- `all` (the default), which builds `./lab6test` and `./growth_test`;
- a rule for `main.o` that lists every header it depends on, directly or indirectly: `stack.h` and `queue.h` include `deque.h`, so a change to `deque.h` must rebuild `main.o`;
- a rule that builds `./lab6test` from `main.o`;
- `growth_test` and `growth_fixed`, each built straight from `growth_test.cpp` (no `.o`), each depending on `growth_test.cpp` and `dynamic_array.h`; `growth_fixed` adds `-DFIXED_GROWTH` to the compile line;
- `test`, which builds and runs `./lab6test`;
- `clean`, which removes the object files and all four executables;
- `CXXFLAGS = -std=c++11 -Wall -Wextra -Werror -g`.

There are no `deque.o` or `dynamic_array.o`: a header is not compiled on its own. Its code is compiled as part of each `.cpp` that includes it.

Add these two targets as well, for the provided tests (not graded):

```make
HEADERS = deque.h stack.h queue.h dynamic_array.h

public_tests: tests/public_tests.cpp $(HEADERS)
	$(CXX) $(CXXFLAGS) -I. -o public_tests tests/public_tests.cpp

check: public_tests
	./public_tests
```

## 6. Testing

```
make test                      # your tests (main.cpp) -> ./lab6test
make check                     # every provided test
./public_tests deque           # one group: deque, stack, queue,
                               # array
valgrind --leak-check=full --show-leak-kinds=all ./lab6test
valgrind --leak-check=full --show-leak-kinds=all ./public_tests
```

The provided suite runs the same kinds of checks the autograder runs. Passing it is necessary, not sufficient: it does not check your Makefile, your writeup or Part C, and the autograder runs several sequences that are not in it.

`public_tests.cpp` stores `Label`s, a type that owns a heap string and counts how many `Label`s are alive. A container that copies `Label`s without their `operator=`, or that loses or double-deletes one, fails a check or a valgrind run. The file also compiles every member of every container for `Label` and for `NoDefault`, so code that only compiles for `int` stops the build of `./public_tests` with a message naming your header.

A test that passes without valgrind and fails under it has still failed. `delete` in place of `delete[]` usually crashes the program; when it does not, valgrind reports it.

Your `main.cpp` must exercise, at minimum:

- each of `Deque`, `Stack`, `Queue` and `DynamicArray` with **at least two element types**, one of them user-defined (`Point` is provided);
- copying and assigning a `Deque`, a `Queue` and a `DynamicArray`;
- **self-assignment** of a `Deque`, a `Stack`, a `Queue` and a `DynamicArray`;
- copying a `DynamicArray` of at least 10 elements, destroying the original, and reading the copy;
- growth from empty through at least four reallocations, checking `capacity()`, `reallocCount()` and `copyCount()`;
- `at` in range and out of range, and `popBack` on an empty array;
- `clear` followed by pushes, and `reserve` both above and below the current capacity.

## 7. Allowed and not allowed

Allowed: templates, references, copy constructors, `operator=`, `new[]`/`delete[]`, `std::cout`, `<cstring>`, `<cstdlib>`. Copying objects is allowed and expected.

| Not allowed | Why |
|---|---|
| `virtual` (it's ok if you don't know what this is) | runtime polymorphism is not part of this course |
| `std::string` | not needed; the provided tests bring their own string-owning type |
| `std::vector` or any other standard-library container | `DynamicArray<T>` is the growable array you are building |
| `std::unique_ptr`, `std::shared_ptr` (again, ok if you don't know these) | the ownership is yours to manage by hand |
| `malloc` / `free` / `realloc` | they run no constructors and no destructors; memory from `new[]` is released with `delete[]` |
| `memcpy` / `memmove` | they copy bytes, so an element that owns memory ends up shared (Section 4.3) |
| changing a class declaration, or the provided `nextCapacity` | the autograder compiles against them |

The autograder scans every `.h` and `.cpp` you submit for everything in this table, with comments and string literals blanked out first, so the words in a comment are fine. A finding **halves your score on Parts A and B**.

## 8. Submission and grading

Submit: `deque.h` · `stack.h` · `queue.h` · `dynamic_array.h` · `main.cpp` · `growth_test.cpp` · `Makefile` · `WRITEUP.md` · `AI_LOG.md`

| | |
|---|---|
| `Deque<T>` / `Stack<T>` / `Queue<T>` correct and generic | 30 |
| `DynamicArray<T>` correct, including both `operator[]`s and `at` | 30 |
| Rule of Three on `DynamicArray<T>`: deep copy, self-assignment | 15 |
| Part C measurements, and the writeup for Parts A, B and C | 15 |
| `main.cpp` tests every container with two element types, one user-defined | 10 |
| **Valgrind: any leak or invalid access** | **−20** |

The first three lines (75 points) are awarded by the autograder, which you may run as often as you like before the deadline. Part C, the writeup and `main.cpp` (25 points) are read by a human. Valgrind is run twice — on the grader's own memory test against your classes, and on your `./lab6test` — and a leak or invalid access in either costs the 20 points once.

## 9. Checklist before you submit

- [ ] `make` produces zero warnings with `-Wall -Wextra -Werror`, and builds `./lab6test` and `./growth_test`
- [ ] `make check` passes, and both valgrind runs report 0 errors and 0 bytes lost
- [ ] no class declaration has changed, and `nextCapacity` is as provided
- [ ] the `placeholder` lines in `dynamic_array.h`'s `operator[]`s are gone
- [ ] every container is used in `main.cpp` with two element types, one of them `Point` or another type you defined
- [ ] `a = a` works for `Deque`, `Stack`, `Queue` and `DynamicArray`
- [ ] every `new[]` is matched by `delete[]`, and elements are copied with `=`
- [ ] `dynamic_array.h` is restored after the `operator[]` experiment
- [ ] nothing from the "Not allowed" table appears in your code
- [ ] `WRITEUP.md` (Parts A, B, C and the valgrind summary) and `AI_LOG.md` are filled in

## 10. AI policy for this lab

Standard course policy: log substantive assistant use in `AI_LOG.md` (what you asked, what you got, what you changed and why).

**Expect a specific and consistent failure.** Ask an assistant for a growable array template and it will give you `std::vector` underneath, `memcpy` into memory from `realloc`, an `at` that throws `std::out_of_range`, and the keyword `explicit` on the one-argument constructor. The first two are not allowed here, the third uses exceptions, which this course does not, and the fourth changes the class declaration. State the constraints in the prompt (*"C++11, no STL containers, no memcpy or realloc, no exceptions, new[] and delete[] only, keep this exact class declaration"*) and check the output against them.

**A good use: template error messages.** A mistake in a template can produce a page of errors, most of them repeating the first. Paste the first error and the code it names into an assistant and ask what the error means. You still fix the code yourself. Record in `AI_LOG.md` which errors you asked about and whether the explanation was right.

**A bad use:** asking for `DynamicArray<T>` whole. Part C is about the counters in your own `reallocate`, and the writeup asks you to explain numbers your code produced.
