/* ------------------------------------------------------------------ *
 * queue.h -- ECE 412 Lab 6, Part A.  Lab 4's Queue as a class
 *            template, built on Deque<T> by composition.
 *
 * Each function forwards to d_ in one line, as in Lab 4: push at the
 * back, pop at the front.  Write the bodies inside the class.
 *
 * As with Stack<T>, there is no constructor, destructor, copy
 * constructor or operator=, and you do not add any.
 *
 * The declarations are the specification.  Do not change them.
 * ------------------------------------------------------------------ */
#ifndef QUEUE_H
#define QUEUE_H

#include <cstddef>
#include "deque.h"

template <typename T>
class Queue {
public:
    void push(const T &v)                 // first in, first out
    {
        /* TODO */
        (void)v; /* avoid unused parameter warning */
    }
    bool pop(T *out)                      // false if empty
    {
        /* TODO */
        (void)out; /* avoid unused parameter warning */
        return false;
    }
    bool front(T *out) const              // peek; false if empty
    {
        /* TODO */
        (void)out; /* avoid unused parameter warning */
        return false;
    }
    std::size_t size() const
    {
        /* TODO */
        return 0;
    }
    bool empty() const
    {
        /* TODO */
        return true;
    }
private:
    Deque<T> d_;                          // a Queue contains a Deque
};

#endif /* QUEUE_H */
