/* ------------------------------------------------------------------ *
 * stack.h -- ECE 412 Lab 6, Part A.  Lab 4's Stack as a class
 *            template, built on Deque<T> by composition.
 *
 * Each function forwards to d_ in one line, as in Lab 4.  Write the
 * bodies inside the class.
 *
 * There is no constructor, destructor, copy constructor or
 * operator=, and you do not add any.  WRITEUP.md asks why copying a
 * Stack<T> is correct anyway.
 *
 * The declarations are the specification.  Do not change them.
 * ------------------------------------------------------------------ */
#ifndef STACK_H
#define STACK_H

#include <cstddef>
#include "deque.h"

template <typename T>
class Stack {
public:
    void push(const T &v)                 // last in, first out
    {
        /* TODO */
        (void)v; /* avoid unused parameter warning */
    }
    bool pop(T *out)                      // false if empty
    {
        /* TODO */
        (void)out; /* avoid unused parameter warning */
        return false;
    }
    bool top(T *out) const                // peek; false if empty
    {
        /* TODO */
        (void)out; /* avoid unused parameter warning */
        return false;
    }
    std::size_t size() const
    {
        /* TODO */
        return 0;
    }
    bool empty() const
    {
        /* TODO */
        return true;
    }
private:
    Deque<T> d_;                          // a Stack contains a Deque
};

#endif /* STACK_H */
