# ECE 412 -- Lab 7: Hash Tables and Binary Search Trees

| | |
|---|---|
| **Assigned** | Sat Oct 31 |
| **Due** | **Sun Nov 15, 11:59 pm** -- upload to **Gradescope and Canvas** |
| **Oral checkout** | **Required**, during TA office hours the week of Nov 16  |
| **Weight** | 4.5% |
| **Builds on** | L17 (complexity) · L18 (hash tables) · L19 (trees and BSTs) · L13 (templates) · Lab 6 (templates, the Rule of Three on an owned array) |
| **Language** | C++11 — `g++ -std=c++11 -Wall -Wextra -Werror -g` |
| **Work** | Individual |

Midterm 2 (Thu Nov 12) covers hash tables and binary search trees. Parts A and B are good preparation for it, so finish them before the exam and leave Part C and the writeup for the last weekend.

## 1. What you will build

Two ways to answer "where is the record for this key?":

- **`HashMap`**, a hash table from `std::string` to `int`. It computes a key's location from the key itself: on average a lookup examines one or two entries, however many keys the table holds. It keeps the keys in no useful order.
- **`BST<T>`**, a binary search tree. It finds a key by comparisons, one per level of the tree, and it keeps the keys in order. How many levels there are depends on the order the keys arrived in.

Neither is better at everything. You will build both, measure both on the same 100,000 keys, and find the jobs where each one wins and the inputs that make each one slow.

```text
HashMap: an array of chains            BST<T>: linked nodes

  buckets_                                     50
   [0] -> NULL                               /    \
   [1] -> (ant,3) -> (bee,9) -> NULL       30      70
   [2] -> NULL                            /  \       \
   [3] -> (cat,1) -> NULL               20    40      80
   ...
```

The lab has three parts and an oral checkout:

- **Part A (`HashMap`).** Separate chaining, the djb2 hash function and a deliberately bad one, rehashing when the load factor passes 0.75, and four counters that measure how well the table is working.
- **Part B (`BST<T>`).** Insert, lookup, removal in all three cases, traversals, height, and a check that the tree is a valid BST. Then the failure: keys inserted in sorted order.
- **Part C (compare).** Load the same keys into both structures, measure them, and answer six questions.
- **Oral checkout (30% of the lab).** Ten minutes with a TA, about the code you submitted.

## 2. What you start with

| File | Status | What you do with it |
|---|---|---|
| `hashmap.h` | declaration | **Do not change** the public section or the data members. You may add private member functions. |
| `hashmap.cpp` | stubs | Write every function. |
| `bst.h` | declaration + stubs | **Do not change** the public section or the data members. Write every function; you may add private member functions. |
| `main.cpp` | partial | Your own tests. Three are written; the list of the rest is in the file. |
| `bench.cpp` | partial | Part C. The helpers and experiment 1 are written; you write experiments 2 to 5. |
| `tests/public_tests.cpp` | complete | A provided test suite. Do not edit or submit it. |
| `WRITEUP.md`, `AI_LOG.md` | templates | Fill in. |
| `Makefile` | **missing** | You write it (Section 5). |

The class declarations are the specification: the autograder compiles its own tests against them. Each stub has a comment saying what the function must do, and Section 4 has the full specification.

The stubs compile clean with the course flags (with g++ and with clang) and do nothing useful, so every test fails until you write the code.

## 3. How to proceed

Work in this order. Each step ends with a test you can run before you move on. `./public_tests` runs the provided tests; give it a group name (`hash`, `rehash`, `bst`, `remove`, `copy`) to run only that group.

### Step 0 — Get it building

1. Write the `Makefile` (Section 5).
2. Run `make` and `make check`. Everything should compile with no warnings, and the tests should fail.

**Done when:** `make` builds `./lab7test` and `./bench` with no warnings.

### Step 1 — `HashMap` without rehashing (Part A)

Write the constructor, the destructor, `hash`, `insert` (without the rehash), `get`, `contains`, `erase`, `forEach` and the observers (Section 4.1). Use a large initial table, `HashMap m(1000)`, in your own tests until Step 2.

**Done when:** `./public_tests hash` passes, and `main.cpp`'s example 1 (`test_hashmap_basic`) passes.

### Step 2 — Rehashing and the counters (Part A)

Write `rehash`, call it from `insert`, and write `longestChain`, `emptyBuckets`, `rehashCount` and `lastProbeLength`. Check each counter by hand on a table of five keys before you trust it on 100,000.

**Done when:** `./public_tests rehash` passes under valgrind, and example 2 (`test_rehash_by_hand`) passes.

### Step 3 — `BST<T>` without removal (Part B)

Write the constructor, the destructor, `destroy`, `insert`, `contains`, `height`, `size`, `inorder`, `preorder` and `checkBST` (Section 4.2).

**Done when:** `./public_tests bst` passes, and example 3 (`test_bst_sorted_height`) passes.

### Step 4 — `remove` (Part B)

Write `remove`, one case at a time: a leaf, then a node with one child, then a node with two children. Draw the tree before and after each test case.

**Done when:** `./public_tests remove` passes under valgrind.

### Step 5 — The Rule of Three on both

Write the copy constructors and `operator=` for both classes (`copyOf` for the tree).

**Done when:** `./public_tests copy` passes under valgrind, and `make check` passes in full.

### Step 6 — Your tests, and the stress harnesses

Write the tests listed at the bottom of `main.cpp`, including the two randomized stress tests (Section 6). Run `./lab7test` under valgrind.

### Step 7 — Measure (Part C)

Write experiments 2 to 5 in `bench.cpp`, run `./bench`, fill in the table in `WRITEUP.md`, and answer the six questions (Section 4.3).

### Step 8 — Submit, then prepare for the checkout

Work through the checklist in Section 10, submit to Gradescope and Canvas, and then read Section 9. The checkout is about the code you submitted, so review it.

## 4. Specification

### 4.1 `HashMap`

```cpp
class HashMap {
public:
    HashMap(std::size_t initialBuckets = 8, bool badHash = false);
                                          // 0 buckets is treated as 1;
                                          // badHash selects the
                                          // first-character hash
    ~HashMap();
    HashMap(const HashMap &other);
    HashMap &operator=(const HashMap &other);

    bool insert(const std::string &key, int value);
                                          // true if the key was NEW;
                                          // an existing key gets the
                                          // new value, returns false
    bool get(const std::string &key, int *out) const;
                                          // false (and *out untouched)
                                          // if absent
    bool erase(const std::string &key);   // false if absent
    bool contains(const std::string &key) const;

    std::size_t size()        const;      // number of keys
    std::size_t bucketCount() const;
    double      loadFactor()  const;      // size() / bucketCount()

    void forEach(void (*visit)(const std::string &key, int value)) const;
                                          // every entry once, bucket 0
                                          // first, each chain in order

    // Instrumentation, for Part C.
    std::size_t longestChain()    const;  // most entries in one bucket
    std::size_t emptyBuckets()    const;  // buckets with no entries
    std::size_t rehashCount()     const;  // rehashes by this object
    std::size_t lastProbeLength() const;  // entries compared by the
                                          // last get() or contains()

private:
    struct Entry {
        std::string key;
        int         value;
        Entry      *next;
        Entry(const std::string &k, int v)
            : key(k), value(v), next(NULL) {}
    };

    Entry     **buckets_;                 // new Entry*[bucketCount_]
    std::size_t bucketCount_;
    std::size_t size_;
    std::size_t rehashes_;
    bool        badHash_;
    mutable std::size_t lastProbe_;       // mutable: set by const get()

    std::size_t hash(const std::string &key) const;  // 0..bucketCount_-1
    void        rehash(std::size_t newBucketCount);
};
```

`buckets_` is an array of `bucketCount_` pointers, each the head of a singly linked chain of `Entry` nodes (`NULL` for an empty bucket). An entry with key `k` is always in chain `hash(k)`.

**The hash function.** Write exactly this. The autograder checks which bucket every key lands in, so a different function, even a good one, fails those tests.

```cpp
std::size_t h = 5381;                                  // djb2
for (std::size_t i = 0; i < key.size(); i++)
    h = h * 33 + static_cast<unsigned char>(key[i]);
return h % bucketCount_;
```

- **`static_cast<unsigned char>`.** `char` is signed on most machines, so a byte of 128 or more, such as the bytes of `é` in UTF-8, is a negative `char`. Added to a `std::size_t` it becomes a value near 2⁶⁴. Converting to `unsigned char` first gives 128..255.
- **`% bucketCount_` once, at the end.** `h` wraps around 2⁶⁴ on long keys. Taking the remainder inside the loop gives a different bucket whenever the bucket count is not a power of two.

When `badHash_` is set, `hash` uses only the first character:

```cpp
return key.empty()
    ? 0 : static_cast<unsigned char>(key[0]) % bucketCount_;
```

**`insert`.** If the key is present, replace its value and return `false`; `size_` does not change. Otherwise add a new entry to chain `hash(key)` (at the front or the back: either is correct), increment `size_`, and then, if the load factor is now greater than 0.75, call `rehash(bucketCount_ * 2)`. Compare in integers, `size_ * 4 > bucketCount_ * 3`, not with a `double`.

With 8 buckets the 7th key triggers the first rehash (7/8 > 0.75; 6/8 is not), the 13th key the second (13/16), and so on. `erase` never shrinks the table.

**`rehash(newBucketCount)`.** Allocate a new array of `newBucketCount` heads, all `NULL`. Then move every entry of the old table into the new one, and `delete[]` the old array. Two rules:

1. **Recompute every entry's bucket.** `hash()` depends on `bucketCount_`, so set `bucketCount_` to the new count before you hash. An entry from old chain 3 can belong in new chain 3 or new chain 3 + (old count). Copying chain *i* to new chain *i* produces a table in which most lookups miss.
2. **Move the entries; do not copy them.** Unlink each `Entry` from its old chain and link it into its new chain. No `new Entry` and no `delete` of an entry happens during a rehash: the strings stay where they are and only `next` pointers change. The autograder counts the allocations made by an insert that rehashes.

Then add one to `rehashes_`.

**The counters.**

| Function | Meaning |
|---|---|
| `longestChain()` | the number of entries in the longest chain; 0 for an empty table |
| `emptyBuckets()` | the number of buckets whose chain is empty |
| `rehashCount()` | the number of times this object has rehashed |
| `lastProbeLength()` | the number of entries the most recent `get()` or `contains()` compared with its key. On a hit: the found entry's position in its chain, counting from 1. On a miss: the length of the chain searched (0 for an empty bucket). 0 before any lookup. |

`lastProbe_` is `mutable` because `get` is a `const` member function: looking a key up does not change the map, but it does record how much work the lookup took. Only `get` and `contains` set it.

**`forEach(visit)`** calls `visit(key, value)` once for every entry: the chain of bucket 0 first, each chain from its head. `bench.cpp` uses it to copy the keys out of the table.

**Copying.** The copy constructor builds a table with the same bucket count and the same `badHash` setting, with a new `Entry` for each of `other`'s entries, in the same bucket. Its `rehashCount()` starts at 0: it counts this object's rehashes. `operator=` guards against self-assignment, builds the new chains before it releases the old ones, and leaves this object's `rehashCount()` unchanged; afterwards the bucket count, the size and the `badHash` setting match `other`'s.

### 4.2 `BST<T>`

```cpp
template <typename T>
class BST {
public:
    BST();                                // empty tree
    ~BST();                               // deletes every node
    BST(const BST &other);                // deep copy, SAME SHAPE
    BST &operator=(const BST &other);     // deep copy, same shape

    bool insert(const T &key);            // false if already present
    bool remove(const T &key);            // false if absent
    bool contains(const T &key) const;

    int         height() const;           // -1 when empty
    std::size_t size()   const;

    void inorder (void (*visit)(const T &)) const;  // left, node, right
    void preorder(void (*visit)(const T &)) const;  // node, left, right

    bool checkBST() const;                // I1 and I2 hold

private:
    struct Node {
        T     key;
        Node *left;
        Node *right;
        Node(const T &k) : key(k), left(NULL), right(NULL) {}
    };
    Node       *root_;
    std::size_t size_;

    // Recursive helpers on a subtree.  PROVIDED as declarations.
    static void  destroy(Node *n);                // delete n's subtree
    static Node *copyOf(const Node *n);           // same shape
    static int   heightOf(const Node *n);         // -1 for NULL
};
```

**Compare keys only with `<`.** "`a` equals `b`" is `!(a < b) && !(b < a)`. The autograder stores a type that has `<` and nothing else: no `==`, no `>`, no default constructor. A tree that uses `==` or `>` does not compile for it.

**Height.** An empty tree has height −1 and a single node 0. The height of a node is one more than the taller of its two subtrees. `BST` does not store heights: `height()` computes one by visiting every node.

**`insert`** walks down from the root, left when the new key is smaller and right when it is larger, and links a new node where the walk reaches `NULL`. A key already present returns `false`.

**`remove`** has three cases, by the number of children of the node holding the key:

```text
No children: remove 40.           One child: remove 20.
Unlink it.                        Its child takes its place.

     30            30                  30            30
    /  \    ->    /                   /  \    ->    /  \
  20    40      20                  20    40      10    40
                                   /
                                 10

Two children: remove 30.  Its successor, 35 (right once, then
left as far as possible), takes its place.

       30                 35
      /  \               /  \
    20    40     ->    20    40
         /  \                  \
       35    45                 45
```

With two children, replace the node with its **in-order successor**: the smallest key in its right subtree, found by going right once and then left as far as possible. The successor has no left child, so taking it out of its old place is the one-child or no-child case. Use the successor, not the predecessor: the autograder checks the shape of the tree after each removal with `preorder`.

You may either move the successor node into the removed node's place or copy the successor's key into the removed node and delete the successor's node. Both produce the same shape.

**Traversals.** `inorder` visits the left subtree, then the node, then the right subtree, so the keys come out in increasing order. `preorder` visits the node first. Two BSTs with the same preorder sequence have the same shape, which is how the tests check shape. Both take a function pointer; C++ lambdas are not part of this course.

**`checkBST`** returns `true` if every key is greater than every key in its left subtree and less than every key in its right subtree, and the number of nodes equals `size()`. Comparing each node with its two children is not enough:

```text
       50
      /  \       every node is between its children,
    30    70     but 60 is in 50's LEFT subtree
      \
       60
```

Pass the allowed range down instead: the left subtree of a node with key *k* must hold keys below *k* and above whatever bound the node itself had. A helper with two `const T *` bounds (`NULL` for no bound) does this.

**Copying.** The copy constructor builds a tree of the **same shape** with `copyOf`: copy the node, then copy each subtree into it (preorder). Copying by inserting `other`'s keys in sorted order produces a tree of height n − 1, and the autograder compares shapes. `operator=` guards against self-assignment and copies before it destroys.

**Recursion depth.** A recursive function on a tree recurses once per level, so its maximum depth is the height of the tree. On a tree built from sorted keys that is n − 1. Each level costs one stack frame, and a stack holds a few megabytes, so a recursive `insert` or `height` on a million sorted keys can crash with a stack overflow. The autograder's sorted-input test uses 3,000 keys, which any correct version survives; Part C asks you about the larger case. `insert`, `contains` and `remove` may be written either recursively or with a loop.

### 4.3 Part C: measuring

`bench.cpp` is a separate program. It loads the same keys into a `HashMap` and a `BST<std::string>`, times the operations, and prints the counters. The STL is allowed in it: `std::vector` holds the keys and `std::sort` sorts them.

```
make bench
./bench          # every experiment
./bench 3        # one experiment
```

The keys are 8 characters long: a lowercase letter, then a 7-digit number (`"a0000000"`, `"b0000001"`, ...). The provided `shuffledKeys(n)` returns n of them in a fixed random order, and `missFor(i)` returns a key that is never inserted but sorts next to `keyFor(i)`.

Experiment 1 is written for you. Write the other four:

| Experiment | What it prints |
|---|---|
| 1. `HashMap`, djb2, 100,000 keys | build time; 100,000 hits; 100,000 misses; `bucketCount`, `loadFactor`, `rehashCount`, `longestChain`, `emptyBuckets`; the average `lastProbeLength` for hits and for misses |
| 2. bad hash, 20,000 keys | `HashMap(8, true)` against `HashMap()`: build time, hit time, `bucketCount`, `rehashCount`, `longestChain`, `emptyBuckets`; the bad table's average `lastProbeLength` for hits |
| 3. `BST<std::string>`, the same 100,000 keys | build time; 100,000 hits; 100,000 misses (`missFor`); `height()` |
| 4. sorted output | all 100,000 keys in increasing order: from the tree with `inorder`, from the table with `forEach` and then `std::sort`; both times; whether the two results are equal |
| 5. sorted input | for n = 1,000, 5,000, 10,000 and 20,000, keys inserted in sorted order: BST build time and height; `HashMap` build time and `longestChain` |

All of it should run in well under a minute. Do not run `./bench` under valgrind.

Fill in this table in `WRITEUP.md` from your own output:

| | `HashMap` | `BST<std::string>` |
|---|---|---|
| Build, 100,000 random keys | | |
| 100,000 hits | | |
| 100,000 misses | | |
| Memory per key (estimate; show your arithmetic) | | |
| Most entries compared by one lookup | `longestChain()` | `height() + 1` |
| All keys in increasing order | | |
| 20,000 keys inserted in sorted order | build time, `longestChain()` | build time, `height()` |
| 20,000 keys, first-character hash | build time, `longestChain()` | (not applicable) |

Then answer:

1. **Sorted order.** How does each structure produce all of its keys in increasing order, and how many steps does each take, as a function of n? Use experiment 4's times.
2. **Rehashing does not fix a bad hash.** In experiment 2, both tables rehash the same number of times and end with the same bucket count. Use `emptyBuckets()` and `longestChain()` to explain why doubling the number of buckets helps the djb2 table and not the first-character table. What is the most buckets the first-character hash can ever use on these keys?
3. **Probe lengths.** From experiment 1, compute the load factor α. A miss compares every entry in one chain; a hit compares, on average, about half of the other entries in its chain plus itself. Compare your two average probe lengths with α and with 1 + α/2.
4. **Height.** Compare the BST's height on 100,000 random keys with log₂ 100,000 ≈ 16.6 and with n − 1. In experiment 5, by what factor does the BST build time grow when n doubles from 10,000 to 20,000? Explain that factor by counting the comparisons a sorted insert sequence makes.
5. **Recursion depth.** What is the recursion depth of your `height()` (and of `destroy`) on the 20,000-key sorted tree? What would happen on 10 million sorted keys, and why? If any of your functions crashed at some size, report the size.
6. **Choosing.** Name one task where the hash table wins outright and one where the BST wins outright. Name the operation that decides each; "faster" is not an answer.

## 5. The Makefile

Write it yourself, modeled on Lab 6's. It must have:

- `all` (the default), which builds `./lab7test` from `main.o` and `hashmap.o`, and `./bench` from `bench.o` and `hashmap.o`;
- **one rule per object file**, each listing every header it depends on: `main.o` and `bench.o` include both `hashmap.h` and `bst.h`; `hashmap.o` depends on `hashmap.cpp` and `hashmap.h`;
- `test`, which builds and runs `./lab7test`;
- `clean`, which removes the object files and the executables;
- `CXXFLAGS = -std=c++11 -Wall -Wextra -Werror -g`.

`bst.h` is a template, so there is no `bst.o`: its code is compiled as part of each `.cpp` that includes it.

Add these two targets as well, for the provided tests (not graded):

```make
public_tests: tests/public_tests.cpp hashmap.o hashmap.h bst.h
	$(CXX) $(CXXFLAGS) -I. -o public_tests tests/public_tests.cpp hashmap.o

check: public_tests
	./public_tests
```

## 6. Testing

```
make test                      # your tests (main.cpp) -> ./lab7test
make check                     # every provided test
./public_tests hash            # one group: hash, rehash, bst, remove,
                               # copy
valgrind --leak-check=full --show-leak-kinds=all ./lab7test
valgrind --leak-check=full --show-leak-kinds=all ./public_tests
```

The provided suite runs the same kinds of checks the autograder runs. Passing it is necessary, not sufficient: the autograder runs more sequences, checks the bucket of every key and the shape of every tree, and counts the allocations a rehash makes.

A test that passes without valgrind and fails under it has still failed.

Your `main.cpp` must contain, at minimum:

- the tests listed at the bottom of the starter file;
- **a randomized stress test for `BST<int>`**: at least 10,000 random inserts and removes, checked against a `std::set`, calling `checkBST()` after **every** operation. At the first failure it prints the operation number, the operation and the key, and stops. Write this early: it finds removal bugs that hand-written cases miss;
- **a randomized stress test for `HashMap`**: at least 10,000 random inserts, erases and gets against a `std::map`, starting from `HashMap(1)` so that it rehashes many times, checking `size()` after every operation.

`./lab7test` must finish in under 10 seconds. The autograder runs it under valgrind, which is about 30 times slower.

## 7. Allowed and not allowed

Allowed: everything from earlier labs, templates, `std::string`, references, function pointers. In `main.cpp` and `bench.cpp` only, any part of the standard library (`std::map` and `std::set` as test models, `std::vector`, `std::sort`, `<chrono>`).

In `hashmap.h`, `hashmap.cpp` and `bst.h`:

| Not allowed | Why |
|---|---|
| `std::vector`, `std::list`, `std::map`, `std::set`, `std::unordered_map` or any other standard container | `HashMap` and `BST` are the containers you are building |
| `std::hash` | you write the hash function |
| `std::unique_ptr`, `std::shared_ptr` | the ownership is yours to manage by hand |
| `malloc` / `free` / `realloc` | memory from `new` is released with `delete`, from `new[]` with `delete[]` |
| `virtual` | runtime polymorphism is not part of this course |
| changing the public section or the data members of either class | the autograder compiles against them; adding private member functions is fine |

The autograder scans `hashmap.h`, `hashmap.cpp` and `bst.h` for everything in this table, with comments and string literals blanked out first, so the words in a comment are fine. A finding **halves your autograded score**.

## 8. Submission and grading

Submit these files to **Gradescope**, and upload the same files in one zip to **Canvas**, by **Sun Nov 15, 11:59 pm**:

`hashmap.h` · `hashmap.cpp` · `bst.h` · `main.cpp` · `bench.cpp` · `Makefile` · `WRITEUP.md` · `AI_LOG.md`

| | |
|---|---|
| `HashMap`: insert / get / erase / contains / forEach | 12 |
| `HashMap`: rehashing (buckets recomputed, entries moved), the bad hash, the four counters | 12 |
| `BST<T>`: insert / contains / traversals / height / checkBST, generic | 10 |
| `BST<T>`: remove, all three cases | 8 |
| Rule of Three on `HashMap` and `BST<T>` | 8 |
| `main.cpp`: your tests and the two stress tests | 5 |
| Part C: measurements and the six answers | 15 |
| **Oral checkout** | **30** |
| **Valgrind: any leak or invalid access** | **−20** |

The first five lines (50 points) are awarded by the autograder, which you may run as often as you like before the deadline. `main.cpp` and Part C (20 points) are read by a human, and the checkout (30 points) is scored by your TA. Valgrind is run twice — on the grader's own memory tests against your classes, and on your `./lab7test` — and a leak or invalid access in either costs the 20 points once.

## 9. Oral checkout

Ten minutes, one-on-one with a TA, during office hours the week of Nov 16. It is worth 30 of the lab's 100 points, and it is required: a student who does not attend a checkout scores 0 for it.

**Bring** a laptop with the code you submitted to Gradescope open in an editor, and your `WRITEUP.md`. The TA may ask you to find a line, explain it, or say what would happen if it changed. No notes are needed beyond your own code.

**Expect five questions**, one of each kind (these are just examples; the TA may ask different ones):

1. **By hand.** On paper: insert a short sequence of keys into a BST, or remove a key with two children, and draw the tree after each step. Or: given a small table and a hash, say which bucket each key goes to.
2. **Your rehash.** Walk through your `rehash`. Why must every entry's bucket be recomputed? What goes wrong if chain *i* is copied to new chain *i*? Why are the entries relinked rather than copied?
3. **Your remove.** Walk through the two-children case in your `remove`. Why the successor? Why does the successor never have a left child?
4. **Your numbers.** Read one number from your Part C table and say what it demonstrates.
5. **A choice.** Hash table or BST for a task the TA names, and why not the other.

Each question is scored 0 to 4:

| Score | Meaning |
|---|---|
| 4 | Correct and complete; explains why, and finds the relevant lines in your own code without help |
| 3 | Correct, with a small gap or one prompt from the TA |
| 2 | Partly correct; can say what the code does but not why, or needs several prompts |
| 1 | Mostly incorrect, or only reads the code aloud |
| 0 | No answer, or cannot find the code in question |

Your checkout score is the total out of 20, scaled to 30 points.

The checkout grades your understanding of the code you submitted. Code you wrote yourself, and debugged, is the best preparation.

## 10. Checklist before you submit

- [ ] `make` produces zero warnings with `-Wall -Wextra -Werror`, and builds `./lab7test` and `./bench`
- [ ] `make check` passes, and both valgrind runs report 0 errors and 0 bytes lost
- [ ] the public sections and data members of `HashMap` and `BST` are as given
- [ ] the `PLACEHOLDER` casts in `hashmap.cpp`'s constructor are gone
- [ ] `hash` is exactly the djb2 code in Section 4.1, with `unsigned char`
- [ ] `rehash` moves entries: no `new Entry` or entry `delete` inside it
- [ ] `BST` compares keys only with `<`, and `remove` uses the in-order successor
- [ ] `a = a` works for both classes
- [ ] `main.cpp` has both stress tests, and `./lab7test` runs in under 10 seconds
- [ ] nothing from the "Not allowed" table appears in `hashmap.h`, `hashmap.cpp` or `bst.h`
- [ ] `WRITEUP.md` (the table, the six answers, the valgrind summary) and `AI_LOG.md` are filled in
- [ ] the same files are uploaded to both Gradescope and Canvas

## 11. AI policy for this lab

Standard course policy: log substantive assistant use in `AI_LOG.md` (what you asked, what you got, what you changed and why).

**The oral checkout grades your understanding of the code you submitted.** Anything you cannot explain costs more at the checkout than it saved you writing.

**Two good uses:**

- **Ask for adversarial test cases.** *"Give me BST insert and remove sequences where the node removed has two children and its successor has a right child."* That produces tests, not answers.
- **Ask it to review your `remove` or `rehash`, and argue with it.** If it reports a bug, confirm it with a trace or a test before you change anything: assistants report bugs in correct pointer code with the same confidence as real ones. Record in `AI_LOG.md` which reports were real.

**Expect a specific failure.** Assistants write hash tables well and *instrumented* hash tables badly. `longestChain`, `lastProbeLength` and the rehash counter come back missing, wrong, or measuring something else, and the rehash usually allocates new entries instead of moving the old ones. Write the counters yourself and check each one by hand on a table of five keys.

**A bad use:** asking for `bst.h` or `hashmap.cpp` whole. It will compile, it will probably pass, and you will then be asked in the checkout to explain its two-children case.
