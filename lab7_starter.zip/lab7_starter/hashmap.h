/* ------------------------------------------------------------------ *
 * hashmap.h -- ECE 412 Lab 7, Part A.  A map from std::string to int,
 *              stored in a hash table with separate chaining.
 *
 * The public section and the data members are the specification.
 * Do not change them: the autograder compiles its own test programs
 * against them.  You MAY add private member functions (helpers).
 *
 *   buckets_[0 .. bucketCount_-1]      each a chain of Entry nodes
 *
 *   buckets_ --> [0] --> NULL
 *                [1] --> ("ant",3) --> ("bee",9) --> NULL
 *                [2] --> NULL
 *                [3] --> ("cat",1) --> NULL
 *                ...
 * ------------------------------------------------------------------ */
#ifndef HASHMAP_H
#define HASHMAP_H

#include <cstddef>
#include <string>

class HashMap {
public:
    HashMap(std::size_t initialBuckets = 8, bool badHash = false);
                                          // 0 buckets is treated as 1;
                                          // badHash selects the
                                          // first-character hash
    ~HashMap();
    HashMap(const HashMap &other);
    HashMap &operator=(const HashMap &other);

    bool insert(const std::string &key, int value);
                                          // true if the key was NEW;
                                          // an existing key gets the
                                          // new value, returns false
    bool get(const std::string &key, int *out) const;
                                          // false (and *out untouched)
                                          // if absent
    bool erase(const std::string &key);   // false if absent
    bool contains(const std::string &key) const;

    std::size_t size()        const;      // number of keys
    std::size_t bucketCount() const;
    double      loadFactor()  const;      // size() / bucketCount()

    void forEach(void (*visit)(const std::string &key, int value)) const;
                                          // every entry once, bucket 0
                                          // first, each chain in order

    // Instrumentation, for Part C.
    std::size_t longestChain()    const;  // most entries in one bucket
    std::size_t emptyBuckets()    const;  // buckets with no entries
    std::size_t rehashCount()     const;  // rehashes by this object
    std::size_t lastProbeLength() const;  // entries compared by the
                                          // last get() or contains()

private:
    struct Entry {
        std::string key;
        int         value;
        Entry      *next;
        Entry(const std::string &k, int v)
            : key(k), value(v), next(NULL) {}
    };

    Entry     **buckets_;                 // new Entry*[bucketCount_]
    std::size_t bucketCount_;
    std::size_t size_;
    std::size_t rehashes_;
    bool        badHash_;
    mutable std::size_t lastProbe_;       // mutable: set by const get()

    std::size_t hash(const std::string &key) const;  // 0..bucketCount_-1
    void        rehash(std::size_t newBucketCount);

    // Add private helper functions here if you want them, e.g. one
    // that deletes every entry (the destructor and operator= both
    // need it).  Add no data members.
};

#endif /* HASHMAP_H */
