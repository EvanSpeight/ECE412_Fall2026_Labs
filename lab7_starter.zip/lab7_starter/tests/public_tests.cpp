/* ------------------------------------------------------------------ *
 * public_tests.cpp -- ECE 412 Lab 7 provided tests.  Do not edit or
 *                     submit this file.
 *
 *     ./public_tests            every group
 *     ./public_tests hash       one group: hash, rehash, bst, remove,
 *                               copy
 *
 * Run it under valgrind as well.
 *
 * One element type is defined here besides int and std::string:
 *
 *   OnlyLess   has < and nothing else: no ==, no >, no default
 *              constructor.  BST<T> must compare keys with < alone,
 *              so it must compile and work for OnlyLess.
 * ------------------------------------------------------------------ */
#include <cstdio>
#include <cstring>
#include <iostream>
#include <string>
#include <vector>

#include "hashmap.h"
#include "bst.h"

/* ---- harness ----------------------------------------------------- */

static int g_checks    = 0;
static int g_fails     = 0;
static int g_testFails = 0;

static void check_(bool cond, const char *expr, int line)
{
    g_checks++;
    if (!cond) {
        g_fails++;
        g_testFails++;
        std::cout << "    FAIL line " << line << ": " << expr << '\n';
    }
}
#define CHECK(cond) check_((cond), #cond, __LINE__)

/* ---- element types and helpers ----------------------------------- */

class OnlyLess {
public:
    OnlyLess(int v) : v_(v) {}
    bool operator<(const OnlyLess &o) const { return v_ < o.v_; }
    int  value() const { return v_; }
private:
    int v_;
};

/* Compiles EVERY member function of BST for OnlyLess.  If your tree
 * uses == or >, or needs T(), the build stops here. */
template class BST<OnlyLess>;

static std::vector<int> g_seen;
static void record(const int &k) { g_seen.push_back(k); }

static std::vector<int> preorderOf(const BST<int> &t)
{
    g_seen.clear();
    t.preorder(record);
    return g_seen;
}

static std::vector<int> inorderOf(const BST<int> &t)
{
    g_seen.clear();
    t.inorder(record);
    return g_seen;
}

static std::vector<int> vec(const int *a, int n)
{
    return std::vector<int>(a, a + n);
}

static std::string key(int i)
{
    char buf[16];
    std::snprintf(buf, sizeof buf, "k%d", i);
    return std::string(buf);
}

/* djb2, exactly as README section 4.1 specifies it */
static std::size_t djb2(const std::string &k, std::size_t buckets)
{
    std::size_t h = 5381;
    for (std::size_t i = 0; i < k.size(); i++) {
        h = h * 33 + static_cast<unsigned char>(k[i]);
    }
    return h % buckets;
}

/* ================================================================== *
 * hash
 * ================================================================== */

static void hash_empty(void)
{
    HashMap m;
    int v = -7;
    CHECK(m.size() == 0);
    CHECK(m.bucketCount() == 8);
    CHECK(m.loadFactor() == 0.0);
    CHECK(!m.get("a", &v) && v == -7);
    CHECK(!m.contains("a"));
    CHECK(!m.erase("a"));
    CHECK(HashMap(0).bucketCount() == 1);
    CHECK(HashMap(5).bucketCount() == 5);
}

static void hash_insert_get(void)
{
    HashMap m(1000);
    int v = 0;
    CHECK(m.insert("ant", 1));
    CHECK(m.insert("bee", 2));
    CHECK(m.insert("", 3));                    /* "" is a key       */
    CHECK(m.size() == 3);
    CHECK(m.get("ant", &v) && v == 1);
    CHECK(m.get("", &v) && v == 3);
    CHECK(!m.insert("ant", 10));               /* overwrite         */
    CHECK(m.get("ant", &v) && v == 10);
    CHECK(m.size() == 3);
    CHECK(m.contains("bee") && !m.contains("be"));
    v = 99;
    CHECK(!m.get("cat", &v) && v == 99);
}

static void hash_erase(void)
{
    HashMap m(64, true);                       /* one chain of five */
    const char *k[] = { "pa", "pb", "pc", "pd", "pe" };
    for (int i = 0; i < 5; i++) m.insert(k[i], i);
    CHECK(m.erase("pc"));                      /* middle            */
    CHECK(m.erase("pa"));                      /* one end           */
    CHECK(m.erase("pe"));                      /* the other end     */
    CHECK(!m.erase("pa") && !m.erase("zz"));
    int v = -1;
    CHECK(m.size() == 2);
    CHECK(m.get("pb", &v) && v == 1);
    CHECK(m.get("pd", &v) && v == 3);
    CHECK(m.insert("pc", 7) && m.get("pc", &v) && v == 7);
}

static int g_visits = 0;
static void countVisit(const std::string &, int) { g_visits++; }

static void hash_foreach(void)
{
    HashMap m;
    for (int i = 0; i < 100; i++) m.insert(key(i), i);
    m.erase(key(3));
    g_visits = 0;
    m.forEach(countVisit);
    CHECK(g_visits == 99);
}

/* ================================================================== *
 * rehash
 * ================================================================== */

static void rehash_schedule(void)
{
    HashMap m;                                 /* 8 buckets         */
    for (int i = 0; i < 6; i++) m.insert(key(i), i);
    CHECK(m.bucketCount() == 8);               /* 6/8 = 0.75        */
    CHECK(m.rehashCount() == 0);
    m.insert(key(0), 100);                     /* overwrite: no     */
    CHECK(m.bucketCount() == 8);
    m.insert(key(6), 6);                       /* 7/8 > 0.75        */
    CHECK(m.bucketCount() == 16);
    CHECK(m.rehashCount() == 1);
    for (int i = 7; i < 13; i++) m.insert(key(i), i);   /* 13/16 */
    CHECK(m.bucketCount() == 32);
    CHECK(m.rehashCount() == 2);
    int v = 0;
    bool ok = true;
    for (int i = 1; i < 13; i++) ok = ok && m.get(key(i), &v) && v == i;
    CHECK(ok);                                 /* all found         */
    CHECK(m.get(key(0), &v) && v == 100);
    for (int i = 0; i < 13; i++) m.erase(key(i));
    CHECK(m.bucketCount() == 32);              /* never shrinks     */
}

static void rehash_buckets(void)
{
    /* after rehashing, every key must sit in the bucket djb2 picks
     * for the NEW bucket count */
    HashMap m;
    for (int i = 0; i < 30; i++) m.insert(key(i), i);
    std::size_t b = m.bucketCount();
    CHECK(b == 64);
    if (b == 0) {
        return;                                /* nothing to check  */
    }
    std::vector<int> count(b, 0);
    for (int i = 0; i < 30; i++) count[djb2(key(i), b)]++;
    std::size_t empty = 0, longest = 0;
    for (std::size_t j = 0; j < b; j++) {
        if (count[j] == 0) empty++;
        if ((std::size_t)count[j] > longest) longest = count[j];
    }
    CHECK(m.emptyBuckets() == empty);
    CHECK(m.longestChain() == longest);
}

static void rehash_probe(void)
{
    HashMap m(64, true);                       /* first-character   */
    int v = 0;
    CHECK(m.lastProbeLength() == 0);
    const char *k[] = { "ma", "mb", "mc", "md" };
    for (int i = 0; i < 4; i++) m.insert(k[i], i);
    CHECK(m.longestChain() == 4);
    CHECK(m.emptyBuckets() == 63);
    std::size_t total = 0;
    for (int i = 0; i < 4; i++) {
        m.get(k[i], &v);
        total += m.lastProbeLength();
    }
    CHECK(total == 1 + 2 + 3 + 4);             /* hits: 1..4        */
    m.get("mz", &v);
    CHECK(m.lastProbeLength() == 4);           /* miss: whole chain */
    m.get("x", &v);
    CHECK(m.lastProbeLength() == 0);           /* empty bucket      */
}

static void rehash_bad_hash(void)
{
    HashMap m(8, true);
    for (int i = 0; i < 100; i++) m.insert(key(i), i);  /* all 'k' */
    CHECK(m.bucketCount() == 256);             /* still rehashes    */
    CHECK(m.longestChain() == 100);            /* but one chain     */
    CHECK(m.emptyBuckets() == 255);
}

/* ================================================================== *
 * bst
 * ================================================================== */

static void bst_empty(void)
{
    BST<int> t;
    CHECK(t.size() == 0);
    CHECK(t.height() == -1);
    CHECK(!t.contains(5));
    CHECK(!t.remove(5));
    CHECK(inorderOf(t).empty());
    CHECK(t.checkBST());
    t.insert(5);
    CHECK(t.height() == 0);
}

static void bst_insert(void)
{
    BST<int> t;
    const int k[] = { 50, 30, 70, 20, 40, 60, 80 };
    for (int i = 0; i < 7; i++) CHECK(t.insert(k[i]));
    CHECK(!t.insert(40));
    CHECK(t.size() == 7);
    CHECK(t.height() == 2);
    const int pre[] = { 50, 30, 20, 40, 70, 60, 80 };
    const int in[]  = { 20, 30, 40, 50, 60, 70, 80 };
    CHECK(preorderOf(t) == vec(pre, 7));
    CHECK(inorderOf(t) == vec(in, 7));
    CHECK(t.contains(60) && !t.contains(65));
    CHECK(t.checkBST());
}

static void bst_sorted(void)
{
    BST<int> t;
    for (int k = 0; k < 1000; k++) t.insert(k);
    CHECK(t.height() == 999);
    CHECK(t.size() == 1000);
    CHECK(t.contains(999) && !t.contains(1000));
    CHECK(t.checkBST());
}

static std::vector<std::string> g_words;
static void recordWord(const std::string &w) { g_words.push_back(w); }

static void bst_generic(void)
{
    BST<std::string> s;
    s.insert("mango");
    s.insert("apple");
    s.insert("zucchini");
    g_words.clear();
    s.inorder(recordWord);
    CHECK(g_words.size() == 3 && g_words[0] == "apple");
    CHECK(s.contains("mango") && !s.contains("kiwi"));

    BST<OnlyLess> o;
    o.insert(OnlyLess(5));
    o.insert(OnlyLess(2));
    CHECK(!o.insert(OnlyLess(5)));
    CHECK(o.contains(OnlyLess(2)) && o.size() == 2);
}

/* ================================================================== *
 * remove
 *
 *                50
 *            /        \
 *          30          70
 *         /  \        /  \
 *       20    40    60    80
 *      /     /  \     \
 *    10    35    45    65
 * ================================================================== */

static void build(BST<int> &t)
{
    const int k[] = { 50, 30, 70, 20, 40, 60, 80, 10, 35, 45, 65 };
    for (int i = 0; i < 11; i++) t.insert(k[i]);
}

static void remove_leaf(void)
{
    BST<int> t;
    build(t);
    CHECK(t.remove(10));
    const int pre[] = { 50, 30, 20, 40, 35, 45, 70, 60, 65, 80 };
    CHECK(preorderOf(t) == vec(pre, 10));
    CHECK(!t.remove(10));
    CHECK(t.size() == 10);
}

static void remove_one_child(void)
{
    BST<int> t;
    build(t);
    CHECK(t.remove(20));                       /* left child only  */
    const int a[] = { 50, 30, 10, 40, 35, 45, 70, 60, 65, 80 };
    CHECK(preorderOf(t) == vec(a, 10));
    CHECK(t.remove(60));                       /* right child only */
    const int b[] = { 50, 30, 10, 40, 35, 45, 70, 65, 80 };
    CHECK(preorderOf(t) == vec(b, 9));
}

static void remove_two_children(void)
{
    BST<int> t;
    build(t);
    CHECK(t.remove(30));                       /* successor 35     */
    const int a[] = { 50, 35, 20, 10, 40, 45, 70, 60, 65, 80 };
    CHECK(preorderOf(t) == vec(a, 10));
    CHECK(t.remove(50));                       /* root; succ 60,   */
    const int b[] = { 60, 35, 20, 10, 40, 45, 70, 65, 80 };  /* who */
    CHECK(preorderOf(t) == vec(b, 9));         /* had a right child */
    CHECK(t.checkBST());
    CHECK(t.size() == 9);
}

/* ================================================================== *
 * copy
 * ================================================================== */

static void copy_hashmap(void)
{
    HashMap *orig = new HashMap;
    for (int i = 0; i < 20; i++) orig->insert(key(i), i);
    HashMap c(*orig);
    CHECK(c.size() == 20);
    CHECK(c.bucketCount() == orig->bucketCount());
    CHECK(c.rehashCount() == 0);
    c.insert(key(0), 100);
    int v = 0;
    CHECK(orig->get(key(0), &v) && v == 0);
    delete orig;
    CHECK(c.get(key(19), &v) && v == 19);

    HashMap small;
    small.insert("x", 1);
    HashMap a(c);
    a = small;
    CHECK(a.size() == 1 && a.contains("x") && !a.contains(key(5)));
    a = c;
    CHECK(a.size() == 20);
    HashMap &alias = a;
    a = alias;
    CHECK(a.size() == 20 && a.get(key(7), &v) && v == 7);
}

static void copy_bst(void)
{
    BST<int> *orig = new BST<int>;
    build(*orig);
    BST<int> c(*orig);
    CHECK(preorderOf(c) == preorderOf(*orig));  /* same shape */
    c.remove(50);
    CHECK(orig->contains(50));
    delete orig;
    CHECK(c.size() == 10 && c.checkBST());

    BST<int> a;
    a.insert(1);
    a = c;
    CHECK(preorderOf(a) == preorderOf(c));
    BST<int> &alias = a;
    a = alias;
    CHECK(a.size() == 10 && a.checkBST());
}

/* ================================================================== *
 * runner
 * ================================================================== */

struct Test {
    const char *group;
    const char *name;
    void (*fn)(void);
};

static const Test TESTS[] = {
    { "hash",   "hash_empty",          hash_empty          },
    { "hash",   "hash_insert_get",     hash_insert_get     },
    { "hash",   "hash_erase",          hash_erase          },
    { "hash",   "hash_foreach",        hash_foreach        },
    { "rehash", "rehash_schedule",     rehash_schedule     },
    { "rehash", "rehash_buckets",      rehash_buckets      },
    { "rehash", "rehash_probe",        rehash_probe        },
    { "rehash", "rehash_bad_hash",     rehash_bad_hash     },
    { "bst",    "bst_empty",           bst_empty           },
    { "bst",    "bst_insert",          bst_insert          },
    { "bst",    "bst_sorted",          bst_sorted          },
    { "bst",    "bst_generic",         bst_generic         },
    { "remove", "remove_leaf",         remove_leaf         },
    { "remove", "remove_one_child",    remove_one_child    },
    { "remove", "remove_two_children", remove_two_children },
    { "copy",   "copy_hashmap",        copy_hashmap        },
    { "copy",   "copy_bst",            copy_bst            },
};
static const int NTESTS = (int)(sizeof TESTS / sizeof TESTS[0]);

int main(int argc, char *argv[])
{
    const char *only = (argc > 1) ? argv[1] : NULL;
    int ran = 0, passed = 0;

    std::cout.setf(std::ios::unitbuf);   /* output survives a crash */

    for (int i = 0; i < NTESTS; i++) {
        if (only != NULL && std::strcmp(only, TESTS[i].group) != 0) {
            continue;
        }
        g_testFails = 0;
        std::cout << TESTS[i].name << '\n';
        TESTS[i].fn();
        ran++;
        if (g_testFails == 0) {
            passed++;
        }
    }

    if (ran == 0) {
        std::cout << "no tests in group \"" << only << "\"; groups are "
                  << "hash, rehash, bst, remove, copy\n";
        return 2;
    }
    std::cout << '\n' << passed << " of " << ran << " tests passed ("
              << g_checks << " checks, " << g_fails << " failed)\n";
    return (passed == ran) ? 0 : 1;
}
