/* ------------------------------------------------------------------ *
 * bench.cpp -- ECE 412 Lab 7, Part C.  Builds to ./bench.
 *
 * Loads the same keys into a HashMap and a BST<std::string> and
 * measures them.  The STL is allowed in this file: std::vector holds
 * the keys, and std::sort is the hash table's route to sorted order.
 *
 *     ./bench              every experiment
 *     ./bench 1            one experiment, 1..5
 *
 * Times are wall-clock seconds and vary from run to run.  Build with
 * the course flags (-O0); report what your machine prints.
 *
 * The helpers marked PROVIDED and experiment 1 are written for you.
 * Experiment 1 shows the pattern; write 2 through 5 the same way
 * (README section 4.3 lists what each must print).
 * ------------------------------------------------------------------ */
#include <algorithm>
#include <chrono>
#include <cstdio>
#include <cstdlib>
#include <iostream>
#include <string>
#include <vector>

#include "hashmap.h"
#include "bst.h"

/* ---- PROVIDED: timing and keys ----------------------------------- */

typedef std::chrono::steady_clock Clock;

inline double secondsSince(Clock::time_point start)
{
    return std::chrono::duration<double>(Clock::now() - start).count();
}

/* Key i: a lowercase letter, then i in 7 digits.  "a0000000",
 * "b0000001", ... "z0000025", "a0000026", ...  All distinct, all 8
 * characters, first letters spread evenly over a..z. */
inline std::string keyFor(std::size_t i)
{
    char buf[16];
    std::snprintf(buf, sizeof buf, "%c%07lu", 'a' + (int)(i % 26),
                  (unsigned long)i);
    return std::string(buf);
}

/* A key that is never inserted: keyFor(i) with a '+' appended.  It
 * sorts just after keyFor(i), so a tree search for it goes as deep as
 * a search for a real key. */
inline std::string missFor(std::size_t i)
{
    return keyFor(i) + "+";
}

/* keyFor(0) .. keyFor(n-1) in a shuffled order, the same order on
 * every run. */
inline std::vector<std::string> shuffledKeys(std::size_t n)
{
    std::vector<std::string> keys;
    for (std::size_t i = 0; i < n; i++) {
        keys.push_back(keyFor(i));
    }
    unsigned long seed = 2026;
    for (std::size_t i = n; i > 1; i--) {        /* Fisher-Yates */
        seed = seed * 6364136223846793005UL + 1442695040888963407UL;
        std::size_t j = (std::size_t)((seed >> 33) % i);
        std::swap(keys[i - 1], keys[j]);
    }
    return keys;
}

/* ---- PROVIDED: visitors ------------------------------------------ */

/* inorder() and forEach() take function pointers, so these write
 * into whichever vector g_out points at.  Experiment 4 uses them. */

static std::vector<std::string> *g_out = NULL;

inline void collectKey(const std::string &key, int)
{
    g_out->push_back(key);
}

inline void collectTreeKey(const std::string &key)
{
    g_out->push_back(key);
}

/* ---- the experiments --------------------------------------------- */

static const std::size_t N = 100000;

/* 1: HashMap, good hash, N random keys. */
static void experimentHashMap(void)
{
    std::cout << "== 1. HashMap, djb2, " << N << " keys ==\n";
    std::vector<std::string> keys = shuffledKeys(N);
    HashMap m;
    int v = 0;

    Clock::time_point t = Clock::now();
    for (std::size_t i = 0; i < N; i++) m.insert(keys[i], (int)i);
    double build = secondsSince(t);

    std::size_t probes = 0;
    t = Clock::now();
    for (std::size_t i = 0; i < N; i++) {
        m.get(keys[i], &v);
        probes += m.lastProbeLength();
    }
    double hits = secondsSince(t);

    std::size_t missProbes = 0;
    t = Clock::now();
    for (std::size_t i = 0; i < N; i++) {
        m.get(missFor(i), &v);
        missProbes += m.lastProbeLength();
    }
    double misses = secondsSince(t);

    std::cout << "build            " << build  << " s\n"
              << "100k hits        " << hits   << " s\n"
              << "100k misses      " << misses << " s\n"
              << "bucketCount      " << m.bucketCount()  << '\n'
              << "loadFactor       " << m.loadFactor()   << '\n'
              << "rehashCount      " << m.rehashCount()  << '\n'
              << "longestChain     " << m.longestChain() << '\n'
              << "emptyBuckets     " << m.emptyBuckets() << '\n'
              << "avg probe, hit   " << (double)probes / N << '\n'
              << "avg probe, miss  " << (double)missProbes / N << "\n\n";
}

/* 2: TODO.  HashMap(8, true) against HashMap() on the same 20,000
 * keys: build time, hit time, bucketCount, rehashCount, longestChain,
 * emptyBuckets, and the bad table's average probe length for hits. */
static void experimentBadHash(void)
{
    std::cout << "== 2. bad hash: not written ==\n\n";
}

/* 3: TODO.  BST<std::string> on the same N shuffled keys as
 * experiment 1: build time, N hits, N misses (missFor), height(). */
static void experimentTree(void)
{
    std::cout << "== 3. BST: not written ==\n\n";
}

/* 4: TODO.  All N keys in increasing order, from each structure:
 * the BST through inorder(collectTreeKey); the HashMap through
 * forEach(collectKey) and then std::sort.  Time both, and check the
 * two vectors are equal. */
static void experimentSortedOutput(void)
{
    std::cout << "== 4. sorted output: not written ==\n\n";
}

/* 5: TODO.  For n = 1,000, 5,000, 10,000 and 20,000: sort the keys
 * first (std::sort), insert them in that order into a BST and a
 * HashMap, and print one line per n: BST build time, BST height,
 * HashMap build time, HashMap longestChain. */
static void experimentSortedInput(void)
{
    std::cout << "== 5. sorted input: not written ==\n\n";
}

int main(int argc, char *argv[])
{
    int only = (argc > 1) ? std::atoi(argv[1]) : 0;
    if (only == 0 || only == 1) experimentHashMap();
    if (only == 0 || only == 2) experimentBadHash();
    if (only == 0 || only == 3) experimentTree();
    if (only == 0 || only == 4) experimentSortedOutput();
    if (only == 0 || only == 5) experimentSortedInput();
    return 0;
}
