/* ------------------------------------------------------------------ *
 * hashmap.cpp -- ECE 412 Lab 7, Part A.  Your implementation of
 *                hashmap.h.
 *
 * Invariants to keep true before and after every public function:
 *   I1. buckets_ points at an array of bucketCount_ chain heads from
 *       new[], and bucketCount_ >= 1
 *   I2. every entry is in chain hash(entry->key)
 *   I3. no key appears twice
 *   I4. size_ is the number of entries in all chains together
 *   I5. size_ * 4 <= bucketCount_ * 3   (load factor <= 0.75)
 *
 * Allowed here: std::string and its members.  Not allowed: any other
 * standard container, std::hash (README section 7).
 * ------------------------------------------------------------------ */
#include "hashmap.h"

/* ---- lifetime ---------------------------------------------------- */

HashMap::HashMap(std::size_t initialBuckets, bool badHash)
{
    /* TODO: initializer list in declaration order (0 buckets becomes
     * 1), then allocate the bucket array and set every head to NULL */
    (void)initialBuckets; (void)badHash; /* avoid unused warnings */

    /* PLACEHOLDER: clang (g++ on macOS) rejects a private member that
     * no function uses.  These casts use them until your code does.
     * Delete them. */
    (void)buckets_; (void)bucketCount_; (void)size_;
    (void)rehashes_; (void)badHash_; (void)lastProbe_;
}

HashMap::~HashMap()
{
    /* TODO: delete the hash map*   */
}

HashMap::HashMap(const HashMap &other)
{
    /* TODO: copy constructor */
    (void)other; /* avoid unused parameter warning */
}

HashMap &HashMap::operator=(const HashMap &other)
{
    /* TODO: assignment operator */
    (void)other; /* avoid unused parameter warning */
    return *this;
}

/* ---- hashing ----------------------------------------------------- */

std::size_t HashMap::hash(const std::string &key) const
{
    /* TODO: djb2 (README section 4.1), or the first-character hash
     * when badHash_ is set.  */
    (void)key; /* avoid unused parameter warning */
    return 0;
}

void HashMap::rehash(std::size_t newBucketCount)
{
    /* TODO: a new array of newBucketCount heads.  MOVE every entry
     * into the chain hash() now selects: relink it, do not new or
     * delete it. */
    (void)newBucketCount; /* avoid unused parameter warning */
}

/* ---- contents ---------------------------------------------------- */

bool HashMap::insert(const std::string &key, int value)
{
    /* TODO: an existing key gets the new value; return false, size
     * unchanged.  Otherwise add an entry and rehash if necessary */
    (void)key; (void)value; /* avoid unused parameter warnings */
    return false;
}

bool HashMap::get(const std::string &key, int *out) const
{
    /* TODO: false (and *out untouched) if absent. */
    (void)key; (void)out; /* avoid unused parameter warnings */
    return false;
}

bool HashMap::contains(const std::string &key) const
{
    /* TODO: implement */
    (void)key; /* avoid unused parameter warning */
    return false;
}

bool HashMap::erase(const std::string &key)
{
    /* TODO: false if absent. */ 
    (void)key; /* avoid unused parameter warning */
    return false;
}

void HashMap::forEach(void (*visit)(const std::string &, int)) const
{
    /* TODO: visit(key, value) for every entry */
    (void)visit; /* avoid unused parameter warning */
}

/* ---- observers --------------------------------------------------- */

std::size_t HashMap::size() const
{
    /* TODO: implement */
    return 0;
}

std::size_t HashMap::bucketCount() const
{
    /* TODO: implement */
    return 0;
}

double HashMap::loadFactor() const
{
    /* TODO: implement */
    return 0.0;
}

std::size_t HashMap::longestChain() const
{
    /* TODO: implement */
    return 0;
}

std::size_t HashMap::emptyBuckets() const
{
    /* TODO: implement */
    return 0;
}

std::size_t HashMap::rehashCount() const
{
    /* TODO: implement */
    return 0;
}

std::size_t HashMap::lastProbeLength() const
{
    /* TODO: implement */
    return 0;
}
