# Lab 7 writeup -- <your name>, <your EID>

Delete the bracketed instructions as you go. Keep each answer short and about your own code and your own numbers.

## Part C -- measurements

[Paste the full output of `./bench` here.]

```
```

| | `HashMap` | `BST<std::string>` |
|---|---|---|
| Build, 100,000 random keys | | |
| 100,000 hits | | |
| 100,000 misses | | |
| Memory per key (estimate) | | |
| Most entries compared by one lookup | `longestChain()` = | `height() + 1` = |
| All keys in increasing order | | |
| 20,000 keys inserted in sorted order | build: , `longestChain()`: | build: , `height()`: |
| 20,000 keys, first-character hash | build: , `longestChain()`: | (not applicable) |

**Memory per key.** [Show your arithmetic for each structure: the size of each field of an `Entry` and of a `Node` (`sizeof(std::string)` on your machine is a number you can print), any padding, the per-allocation overhead you assume, and, for the table, the bucket array's share per key at your final load factor.]

## Part C -- answers

1. **Sorted order.** [How does each structure produce all its keys in increasing order? How many steps does each take, as a function of n? Use experiment 4's times.]

2. **Rehashing does not fix a bad hash.** [Use experiment 2's `emptyBuckets()` and `longestChain()` for both tables. Why does doubling the bucket count help one table and not the other? What is the most buckets the first-character hash can ever use on these keys?]

3. **Probe lengths.** [Compute α from experiment 1. Compare your average probe lengths for misses and for hits with α and with 1 + α/2.]

4. **Height.** [Compare the height on 100,000 random keys with 16.6 and with n − 1. By what factor did the sorted-input build time grow from n = 10,000 to n = 20,000? Explain the factor by counting comparisons.]

5. **Recursion depth.** [The recursion depth of your `height()` and `destroy` on the 20,000-key sorted tree; what would happen at 10 million sorted keys, and why; any size at which your code crashed.]

6. **Choosing.** [One task where the hash table wins outright, one where the BST wins outright, and the operation that decides each.]

## valgrind

[Paste the HEAP SUMMARY and ERROR SUMMARY lines from `valgrind --leak-check=full --show-leak-kinds=all ./lab7test`.]

```
```
