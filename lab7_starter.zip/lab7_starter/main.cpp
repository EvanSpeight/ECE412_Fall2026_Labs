/* ------------------------------------------------------------------ *
 * main.cpp -- your test program for Lab 7.  Builds to ./lab7test.
 *
 * This file is a CLIENT of HashMap and BST<T>.  It uses only their
 * public member functions.  The STL is allowed here: std::map and
 * std::set make good reference models for the stress tests.
 *
 * Three examples are written for you.  The list at the bottom is
 * yours.  ./lab7test must finish in under 10 seconds: the autograder
 * runs it under valgrind, which is about 30 times slower.
 * ------------------------------------------------------------------ */
#include <cstdio>
#include <cstdlib>
#include <iostream>
#include <map>
#include <set>
#include <string>
#include <vector>

#include "hashmap.h"
#include "bst.h"

/* ---- a small test harness ---------------------------------------- */

static int g_checks = 0;
static int g_fails  = 0;

static void check(bool cond, const char *what)
{
    g_checks++;
    if (!cond) {
        g_fails++;
        std::cout << "  FAIL: " << what << '\n';
    }
}

/* ---- seeing the shape of a tree ---------------------------------- */

/* preorder() takes a function pointer, so the visitor writes into a
 * file-scope vector.  preorderOf(t) returns t's keys in preorder:
 * node, then left subtree, then right subtree.  Two BSTs with the
 * same preorder have the same shape. */
static std::vector<int> g_seen;

static void record(const int &key)
{
    g_seen.push_back(key);
}

static std::vector<int> preorderOf(const BST<int> &t)
{
    g_seen.clear();
    t.preorder(record);
    return g_seen;
}

static std::vector<int> inorderOf(const BST<int> &t)
{
    g_seen.clear();
    t.inorder(record);
    return g_seen;
}

static bool sameAs(const std::vector<int> &v, const int *want, int n)
{
    return v == std::vector<int>(want, want + n);
}

/* ---- example 1: insert, get, overwrite --------------------------- */

static void test_hashmap_basic(void)
{
    std::cout << "test_hashmap_basic\n";

    HashMap m;
    int v = -1;
    check(m.insert("ant", 3),             "new key: insert returns true");
    check(m.insert("bee", 9),             "second new key");
    check(m.size() == 2,                  "size 2");
    check(m.get("ant", &v) && v == 3,     "get(ant) == 3");
    check(!m.insert("ant", 4),            "existing key: returns false");
    check(m.get("ant", &v) && v == 4,     "...and the value is replaced");
    check(m.size() == 2,                  "...and size is unchanged");
    v = -1;
    check(!m.get("cat", &v) && v == -1,   "a miss leaves *out untouched");
}

/* ---- example 2: the rehash rule, checked by hand ----------------- */

/* With 4 buckets, the load factor after each new key is 0.25, 0.50,
 * 0.75, 1.00.  Only the fourth is > 0.75, so the fourth insert doubles
 * the table to 8 buckets. */
static void test_rehash_by_hand(void)
{
    std::cout << "test_rehash_by_hand\n";

    HashMap m(4);
    m.insert("a", 1);
    m.insert("b", 2);
    m.insert("c", 3);
    check(m.bucketCount() == 4 && m.rehashCount() == 0,
          "three keys in four buckets: no rehash yet");
    m.insert("c", 30);
    check(m.bucketCount() == 4,           "an overwrite adds no key");
    m.insert("d", 4);
    check(m.bucketCount() == 8,           "fourth key: doubled to 8");
    check(m.rehashCount() == 1,           "one rehash");
    int v = 0;
    check(m.get("a", &v) && v == 1 && m.get("d", &v) && v == 4,
          "every key still found after the rehash");
}

/* ---- example 3: the sorted-input failure ------------------------- */

static void test_bst_sorted_height(void)
{
    std::cout << "test_bst_sorted_height\n";

    BST<int> t;
    for (int k = 1; k <= 10; k++) {
        t.insert(k);
    }
    check(t.size() == 10,                 "size 10");
    check(t.height() == 9,                "sorted input: height n - 1");
    const int want[] = { 1, 2, 3, 4, 5, 6, 7, 8, 9, 10 };
    check(sameAs(preorderOf(t), want, 10),
          "every node is the right child of the one before");
    check(sameAs(inorderOf(t), want, 10), "inorder is sorted");
    check(t.checkBST(),                   "checkBST");
}

/* ------------------------------------------------------------------ *
 * TODO -- write these.
 *
 *   test_hashmap_erase        with HashMap(8, true), put five keys
 *                             that start with the same letter into
 *                             one chain; erase the first, a middle
 *                             and the last entry of that chain, and
 *                             an absent key; erase a key and insert
 *                             it again
 *   test_hashmap_counters     on a table of five keys, work out
 *                             longestChain(), emptyBuckets() and
 *                             lastProbeLength() by hand first, then
 *                             check them (README section 4.1)
 *   test_hashmap_copy         copy, assign longer <- shorter and
 *                             shorter <- longer, self-assign; change
 *                             one and check the other did not change
 *   test_hashmap_stress       at least 10,000 random inserts, erases
 *                             and gets against a std::map; check
 *                             size() after every operation
 *   test_bst_remove           a leaf, a node with only a left child,
 *                             one with only a right child, one with
 *                             two children, the root, an absent key;
 *                             check preorderOf() after each
 *   test_bst_copy             the copy has the same preorder (same
 *                             shape); assign; self-assign
 *   test_bst_strings          BST<std::string>
 *   test_bst_stress           REQUIRED (README section 6): at least
 *                             10,000 random inserts and removes on a
 *                             BST<int>, checked against a std::set;
 *                             call checkBST() after EVERY operation
 *                             and, at the first failure, print the
 *                             operation number, the operation and
 *                             the key, then stop
 * ------------------------------------------------------------------ */

int main(void)
{
    test_hashmap_basic();
    test_rehash_by_hand();
    test_bst_sorted_height();

    /* TODO: call your tests here. */

    std::cout << '\n' << g_checks << " checks, " << g_fails
              << " failures\n";
    return (g_fails == 0) ? 0 : 1;
}
