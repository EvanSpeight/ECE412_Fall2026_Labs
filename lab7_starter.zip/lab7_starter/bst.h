/* ------------------------------------------------------------------ *
 * bst.h -- ECE 412 Lab 7, Part B.  BST<T>: an unbalanced binary
 *          search tree of distinct keys.
 *
 * Header-only, like Lab 6's templates: the class declaration, then
 * every member definition.
 *
 * The public section and the data members are the specification.
 * Do not change them.  You MAY add private member functions.
 *
 * Keys are compared ONLY with <.  "a equals b" is written
 * !(a < b) && !(b < a).  The autograder stores a type that has < and
 * nothing else: no ==, no >, no default constructor.
 *
 * Height convention: an empty tree has height -1, a single node 0.
 *
 * Invariants to keep true before and after every public function:
 *   I1. every key in a node's left subtree is < the node's key, and
 *       the node's key is < every key in its right subtree
 *   I2. size_ is the number of nodes reachable from root_
 *   I3. root_ == NULL  <=>  size_ == 0
 * ------------------------------------------------------------------ */
#ifndef BST_H
#define BST_H

#include <cstddef>

template <typename T>
class BST {
public:
    BST();                                // empty tree
    ~BST();                               // deletes every node
    BST(const BST &other);                // deep copy, SAME SHAPE
    BST &operator=(const BST &other);     // deep copy, same shape

    bool insert(const T &key);            // false if already present
    bool remove(const T &key);            // false if absent
    bool contains(const T &key) const;

    int         height() const;           // -1 when empty
    std::size_t size()   const;

    void inorder (void (*visit)(const T &)) const;  // left, node, right
    void preorder(void (*visit)(const T &)) const;  // node, left, right

    bool checkBST() const;                // I1 and I2 hold

private:
    struct Node {
        T     key;
        Node *left;
        Node *right;
        Node(const T &k) : key(k), left(NULL), right(NULL) {}
    };
    Node       *root_;
    std::size_t size_;

    // Recursive helpers on a subtree.  PROVIDED as declarations; write
    // their bodies with the others below.  Add more if you like.
    static void  destroy(Node *n);                // delete n's subtree
    static Node *copyOf(const Node *n);           // same shape
    static int   heightOf(const Node *n);         // -1 for NULL

    // inorder, preorder and checkBST need recursive helpers of your
    // own, declared here.  Add no data members.
};

/* ================================================================== *
 * Member definitions.
 * ================================================================== */

/* ---- lifetime ---------------------------------------------------- */

template <typename T>
BST<T>::BST()
{
    /* TODO: implement */ 
}

template <typename T>
BST<T>::~BST()
{
    /* TODO: implement */ 
}

template <typename T>
BST<T>::BST(const BST &other)
{
    /* TODO: copy constructor */ 
    (void)other; /* avoid unused parameter warning */
}

template <typename T>
BST<T> &BST<T>::operator=(const BST &other)
{
    /* TODO: assignment operator */ 
    (void)other; /* avoid unused parameter warning */
    return *this;
}

template <typename T>
void BST<T>::destroy(Node *n)
{
    /* TODO: delete tree */
    (void)n; /* avoid unused parameter warning */
}

/* The return type names a member of BST<T>, so it is written with
 * typename in front.  Copy the first two lines exactly. */
template <typename T>
typename BST<T>::Node *BST<T>::copyOf(const Node *n)
{
    /* TODO: copy */ 
    (void)n; /* avoid unused parameter warning */
    return NULL;
}

/* ---- contents ---------------------------------------------------- */

template <typename T>
bool BST<T>::insert(const T &key)
{
    /* TODO: implement  */
    (void)key; /* avoid unused parameter warning */
    return false;
}

template <typename T>
bool BST<T>::contains(const T &key) const
{
    /* TODO */
    (void)key; /* avoid unused parameter warning */
    return false;
}

template <typename T>
bool BST<T>::remove(const T &key)
{
    /* TODO: false if absent.  Three cases (README section 4.2):
     *   no child     -- the parent's link becomes NULL
     *   one child    -- the parent's link becomes that child
     *   two children -- replace with the in-order SUCCESSOR, the
     *                   smallest key in the right subtree */
    (void)key; /* avoid unused parameter warning */
    return false;
}

/* ---- observers --------------------------------------------------- */

template <typename T>
int BST<T>::heightOf(const Node *n)
{
    /* TODO: -1 for NULL; otherwise 1 + the taller subtree's height */
    (void)n; /* avoid unused parameter warning */
    return -1;
}

template <typename T>
int BST<T>::height() const
{
    /* TODO */
    return -1;
}

template <typename T>
std::size_t BST<T>::size() const
{
    /* TODO */
    return 0;
}

template <typename T>
void BST<T>::inorder(void (*visit)(const T &)) const
{
    /* TODO: call visit(key) on every key so they come out in order */ 
    (void)visit; /* avoid unused parameter warning */
}

template <typename T>
void BST<T>::preorder(void (*visit)(const T &)) const
{
    /* TODO: implement */
    (void)visit; /* avoid unused parameter warning */
}

template <typename T>
bool BST<T>::checkBST() const
{
    /* TODO: README section 4.2. */
    return false;
}

#endif /* BST_H */
