/* ------------------------------------------------------------------ *
 * item.h -- ECE 412 Lab 5: an Item is a Named thing with a sku and a
 *           quantity.
 *
 * DO NOT MODIFY THIS FILE.
 * ------------------------------------------------------------------ */
#ifndef ITEM_H
#define ITEM_H

#include "named.h"

class Item : public Named {
public:
    Item();                               // name "", sku 0, qty 0
    Item(const char *name, int sku, int qty);
    Item(const Item &other);
    Item &operator=(const Item &other);

    int  sku() const;
    int  qty() const;
    void addQty(int n);                   // n may be negative; qty
                                          // never goes below 0
private:
    int sku_;
    int qty_;
};

#endif /* ITEM_H */
