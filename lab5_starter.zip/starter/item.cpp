/* ------------------------------------------------------------------ *
 * item.cpp -- ECE 412 Lab 5, Part A.  Your implementation of item.h.
 *
 * Every constructor names the Named base FIRST in its member-
 * initializer list.  operator= calls Named::operator= explicitly.
 * README section 4.2 shows the copy constructor and operator= in full.
 * ------------------------------------------------------------------ */
#include "item.h"

Item::Item()
{
    /* TODO: name "", sku 0, qty 0 -- all in the initializer list */
}

Item::Item(const char *name, int sku, int qty)
{
    /* TODO: pass name to the Named constructor.  A negative qty
     * is stored as 0. */
    (void)name; (void)sku; (void)qty;
}

/* The ": Named()" below is a PLACEHOLDER so that the starter compiles
 * under -Wextra.  It builds the base with the empty name instead of
 * copying other's -- exactly the bug Part A is about.  Replace it. */
Item::Item(const Item &other) : Named()
{
    /* TODO */
    (void)other; /* avoid unused parameter warning */
}

Item &Item::operator=(const Item &other)
{
    /* TODO: self-assignment guard, then Named::operator=(other),
     * then this class's own members. */
    (void)other; /* avoid unused parameter warning */
    return *this;
}

int Item::sku() const
{
    /* TODO */
    return 0;
}

int Item::qty() const
{
    /* TODO */
    return 0;
}

void Item::addQty(int n)
{
    /* TODO: n may be negative; qty never goes below 0 */
    (void)n; /* avoid unused parameter warning */
}
