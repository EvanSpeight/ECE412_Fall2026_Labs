# ECE 412 -- Lab 5: Inheritance, Composition & Ownership

| | |
|---|---|
| **Assigned** | Wed Oct 14 |
| **Due** | **Wed Oct 21, 11:59 pm** (Gradescope) |
| **Weight** | 1% |
| **Builds on** | L10 (destructors) · L11 (RAII, references, copy constructors, `operator=`) · L12 (Rule of Three) · L13 (inheritance and composition) · your Lab 4 `Deque` |
| **Language** | C++11 — `g++ -std=c++11 -Wall -Wextra -Werror -g` |
| **Work** | Individual |

## 1. What you will build

The pieces of a small game inventory system, made of five classes:

- **`Named`**, a base class for anything with a name. It owns its name as a heap-allocated C string, so it needs a destructor, a copy constructor and `operator=` (the Rule of Three).
- **`Item`** and **`Monster`**, two classes derived from `Named`. An `Item` is a named thing with a stock number (sku) and a quantity; a `Monster` is a named thing with hit points and a damage value.
- **`Inventory`**, a collection of `Item`s. It stores them in an array that it allocates and grows itself, and it remembers the order in which items were picked up in a `Deque`, the class you wrote in Lab 4.
- **`BadStack`**, a stack built by inheriting from `Deque`. It is given to you, and it is wrong on purpose: your job is to show how.

The classes use the two ways one class can be built from another:

```text
Inheritance (is-a)

        Named                owns a heap string, char *name_
       /     \
    Item     Monster         add plain ints; own no memory

        Deque                your Lab 4 class, made copyable
          |
       BadStack              inheritance used wrongly (Part B)

Composition (has-a)

    Inventory
      |-- Item  *items_      an array it allocates, grows and frees
      '-- Deque  recent_     a member object that frees itself

    Stack (Lab 4)
      '-- Deque  d_
```

The lab has three parts:

- **Part A (Named, Item, Monster).** Write a base class that owns memory, then two derived classes whose constructors, copy constructors and `operator=` correctly hand the base part to `Named`. Then break that hand-off on purpose and record what happens.
- **Part B (BadStack).** Use `BadStack`'s inherited `Deque` operations to break its last-in, first-out order, and explain why Lab 4's `Stack`, built by composition, cannot be broken that way.
- **Part C (Inventory).** Make your `Deque` copyable, then write `Inventory`, which owns an array of `Item`s and contains a `Deque`. Its copy operations have to copy both correctly.

## 2. What you start with

| File | Status | What you do with it |
|---|---|---|
| `named.h`, `item.h`, `monster.h` | complete | Read. **Do not modify.** |
| `named.cpp`, `item.cpp`, `monster.cpp` | stubs | Write every function. |
| `deque.h` | complete | Lab 4's header plus a copy constructor and `operator=`. **Do not modify.** |
| `deque.cpp` | stubs | Put your Lab 4 code in, then write the two new functions. |
| `stack.h` | complete | Lab 4's `Stack`, unchanged, for comparison in Part B. **Do not modify.** |
| `badstack.h` | complete | Part B's deliberately wrong class. **Do not modify.** |
| `inventory.h` | complete | **Do not modify.** |
| `inventory.cpp` | stubs | Write every function. |
| `main.cpp` | partial | Your own tests. Three are written; the list of the rest is in the file. |
| `tests/public_tests.cpp` | complete | A provided test suite. Do not edit or submit it. |
| `WRITEUP.md`, `AI_LOG.md` | templates | Fill in. |
| `Makefile` | **missing** | You write it (Step 0). |

The headers are the specification: the autograder compiles its own tests against them, so they must stay exactly as given. Each stub has a comment saying what the function must do; Section 4 has the full specification.

The stubs compile clean with the course flags and do nothing useful, so every test fails until you write the code.

## 3. How to proceed

Work in this order. Each step builds on the one before, and each ends with a test you can run before you move on. `./public_tests` runs the provided tests; give it a group name (`named`, `item`, `monster`, `deque`, `inv`) to run only that group, so that the failures of later steps do not bury the step you are working on.

### Step 0 — Get it building

1. Put your Lab 4 `Deque` implementation into `deque.cpp`, replacing the Lab 4 stubs. Leave the two new stubs (the copy constructor and `operator=`) for Step 4. Fix anything Lab 4's grader or valgrind reported: `Inventory` and `BadStack` are built on this class.
2. Write the `Makefile` (Section 5). It builds `./lab5test` from `main.cpp` and the five `.cpp` files, and it has the `check` target that builds and runs `./public_tests`.
3. Run `make` and `make check`. Everything should compile with no warnings, and most tests should fail.

**Done when:** `make` builds `./lab5test` with no warnings.

### Step 1 — `Named` (Part A)

Write the seven functions in `named.cpp`. Every constructor allocates a fresh array with `new[]` and copies the characters into it; the destructor releases it with `delete[]`; `operator=` replaces this object's array with a copy of the other's. Section 4.1 has the details, including the case `x.setName(x.name())`.

**Done when:** `./public_tests named` passes with no valgrind errors, and `main.cpp`'s example 2 (`test_set_name_to_itself`) passes.

### Step 2 — `Item` and `Monster` (Part A)

Write `item.cpp` and `monster.cpp`. Every constructor names the `Named` part first in its initializer list, and each `operator=` calls `Named::operator=` explicitly. Section 4.2 shows `Item`'s copy constructor and `operator=` in full; `Monster`'s follow the same pattern. Remove the `: Named()` placeholders in the starter's copy constructors.

**Done when:** `./public_tests item` and `./public_tests monster` pass under valgrind, and `main.cpp`'s example 1 (`test_item_copy_outlives_original`) passes.

### Step 3 — The experiment (Part A)

On a scratch copy of `item.cpp`, remove the base-class hand-off from the copy constructor, then from `operator=`, and record what the compiler, your tests and valgrind report each time (Section 4.3). Restore the correct code afterward. Answer the Part A questions in `WRITEUP.md`.

**Done when:** `WRITEUP.md` Part A is complete and `item.cpp` is back to the version that passes Step 2.

### Step 4 — Make `Deque` copyable (Part C)

Write `Deque`'s copy constructor and `operator=` (Section 4.4). Both are a few lines built from functions you wrote in Lab 4.

**Done when:** `./public_tests deque` passes under valgrind.

### Step 5 — `Inventory` (Part C)

Write `inventory.cpp` (Section 4.5). A workable order: the constructor, destructor, `size`, `capacity` and `findBySku`; then `add` without growth; then growth; then `removeBySku` and `mostRecentPickup`; then the copy constructor and `operator=`. Run `./public_tests inv` after each one.

**Done when:** `./public_tests inv` passes under valgrind.

### Step 6 — Break `BadStack` (Part B)

In `main.cpp`, write `breakBadStack` and `test_badstack_violation` (Section 4.6), and answer the three Part B questions in `WRITEUP.md`.

**Done when:** `./lab5test` prints `BadStack` before and after the call, and the pops come out in an order no stack allows.

### Step 7 — Finish

1. Write the rest of the tests listed at the bottom of `main.cpp` (Section 6 lists what they must cover).
2. Run both programs under valgrind (Section 6) until both report 0 errors and 0 bytes lost.
3. Complete `WRITEUP.md` (Part C and the valgrind summary) and `AI_LOG.md`.
4. Work through the checklist in Section 9 and submit.

## 4. Specification

### 4.1 `Named`

```cpp
class Named {
public:
    Named();                              // the empty name ""
    Named(const char *name);              // deep-copies name; NULL is
                                          // treated as ""
    ~Named();
    Named(const Named &other);            // Rule of Three
    Named &operator=(const Named &other);

    const char *name() const;             // borrowed; caller must not
                                          // free or keep it
    void        setName(const char *name);   // NULL is treated as ""
    std::size_t nameLength() const;

protected:
    char *name_;                          // owned; allocated with new[]
                                          // and never NULL
};
```

- **`name_` is never `NULL`.** Every constructor gives it a fresh array, even for the empty name, so `name()` and `nameLength()` never need a special case.
- **Allocate with `new[]` and release with `delete[]`.** Use `std::strlen` and `std::strcpy` from `<cstring>`. A small `static` helper that allocates and copies a string (treating `NULL` as `""`) is worth writing once and using everywhere.
- **The default constructor exists for Part C.** `new Item[n]` needs `Item()`, and `Item()` needs `Named()`.
- **`setName` must survive `x.setName(x.name())`.** The argument then points into the array you are about to release, so copy first and release second. Releasing first and copying from freed memory usually appears to work; valgrind reports it.
- **`operator=` must survive `a = a`**, and it releases the old array exactly once.
- **`protected`** lets the member functions of a derived class use `name_` directly. Neither `Item` nor `Monster` needs to. `WRITEUP.md` asks about this choice.

### 4.2 `Item` and `Monster`

```cpp
class Item : public Named {
public:
    Item();                               // name "", sku 0, qty 0
    Item(const char *name, int sku, int qty);
    Item(const Item &other);
    Item &operator=(const Item &other);

    int  sku() const;
    int  qty() const;
    void addQty(int n);                   // n may be negative; qty
                                          // never goes below 0
private:
    int sku_;
    int qty_;
};

class Monster : public Named {
public:
    Monster(const char *name, int hp, int damage);
    Monster(const Monster &other);
    Monster &operator=(const Monster &other);

    int  hp() const;
    int  damage() const;
    bool alive() const;                   // hp > 0
    void takeDamage(int n);               // n <= 0 does nothing; hp
                                          // never goes below 0
private:
    int hp_;
    int damage_;
};
```

A negative `qty` or `hp` passed to a constructor is stored as 0.

Both classes add only `int`s, so they own no memory of their own. That raises a question `WRITEUP.md` asks you to answer: does `Item` need its own copy constructor and `operator=` at all, or would the ones the compiler writes be correct?

The headers declare both, so you write them. Each must hand the `Named` part of the object to `Named`:

```cpp
Item::Item(const Item &other)
    : Named(other),            // copies the base part
      sku_(other.sku_),
      qty_(other.qty_) {
}

Item &Item::operator=(const Item &other) {
    if (this == &other) return *this;
    Named::operator=(other);   // assigns the base part
    sku_ = other.sku_;
    qty_ = other.qty_;
    return *this;
}
```

`Named(other)` works because an `Item` *is a* `Named`: a `const Item &` can be passed where a `const Named &` is expected. Inside a derived `operator=`, write `Named::operator=(other)`; writing `*this = other` there would call `Item::operator=` again, forever.

### 4.3 The experiment

Do both variants on a scratch copy of `item.cpp`, record the results in `WRITEUP.md`, and restore the correct code.

**Variant 1 — the copy constructor without `Named(other)`.** Delete that line from the initializer list (fix the comma).

- Run `make` with the course flags. g++ refuses: with `-Wextra` it reports that the base class should be explicitly initialized in the copy constructor, and `-Werror` makes that an error. Quote the message. (clang, which is what `g++` runs on macOS, gives no such warning.)
- Rebuild without `-Wextra` (`make CXXFLAGS="-std=c++11 -Wall -g"`) and run example 1 under valgrind. What does `copy.name()` return? Does valgrind report anything?

**Variant 2 — `operator=` without `Named::operator=(other)`.** Delete that line.

- Does it compile with the course flags?
- After `a = b`, what does `a.name()` return? Does valgrind report anything?

Then answer in `WRITEUP.md`: which of the two mistakes is more dangerous, and why?

### 4.4 `Deque`'s copy operations

Lab 4 told you not to copy a `Deque`: the compiler-written copy copies `head_` and `tail_`, so two deques share the same nodes and both destructors delete them. `deque.h` now declares the two functions that fix this:

```cpp
    Deque(const Deque &other);            // NEW: deep copy, same order
    Deque &operator=(const Deque &other); // NEW: deep copy, same order
```

- The **copy constructor** starts empty (member-initializer list), then walks `other` from head to tail, calling `pushBack` with each value. The copy has the same order and its own nodes.
- **`operator=`** returns at once on self-assignment. Otherwise it releases what this deque holds (`clear()` already does that), copies `other` the same way, and returns `*this`.

### 4.5 `Inventory`

```cpp
class Inventory {
public:
    Inventory(std::size_t initialCap = 4);   // 0 is treated as 1
    ~Inventory();
    Inventory(const Inventory &other);
    Inventory &operator=(const Inventory &other);

    bool add(const Item &it);             // copies it into the array;
                                          // false (and no change) if
                                          // that sku is already present
    bool removeBySku(int sku);            // false if absent; keeps the
                                          // order of the others
    const Item *findBySku(int sku) const; // NULL if absent
    bool mostRecentPickup(int *skuOut) const;  // sku of the most
                                          // recently added item still
                                          // present; false if none

    std::size_t size()     const;
    std::size_t capacity() const;
    void        print()    const;

private:
    Item       *items_;      // owned: new[] / delete[], grows by doubling
    std::size_t size_;       // items in use: items_[0] .. items_[size_-1]
    std::size_t capacity_;   // length of the items_ array
    Deque       recent_;     // skus, most recent pickup at the front
};
```

`Inventory` uses both relationships:

- It **owns** `items_`, a raw array that it allocates, grows, copies and releases: the Rule of Three again, on an array whose elements are themselves objects with a destructor.
- It **has a** `Deque` by value, and writes no cleanup code for it: `recent_`'s own destructor frees its nodes.

Behavior:

- **Constructor.** Allocates `items_` with `new Item[capacity]`. A capacity of 0 is treated as 1.
- **`add`** returns `false` and changes nothing if an item with that sku is already present. Otherwise it copies the `Item` into the next free slot and pushes its sku onto the **front** of `recent_`. When the array is full it first **doubles** it: `new[]` a bigger array, copy the `size_` items across, `delete[]` the old one.
- **`removeBySku`** returns `false` if the sku is absent. Otherwise it shifts the later items down one slot, so the order of the others is kept, decrements `size_`, and removes the sku from `recent_` with `Deque::remove`.
- **`findBySku`** returns a pointer into `items_`, or `NULL`.
- **`mostRecentPickup`** is one line: it peeks at the front of `recent_`.
- **`print`**: the format is yours; it is not autograded.
- **Destructor.** `delete[] items_`, and nothing for `recent_`.
- **Copy constructor.** A new array of `other.capacity_` Items, with `other`'s `size_` items copied in. `recent_` is copied in the initializer list.
- **`operator=`.** Self-assignment check; build the new array before releasing the old one; copy `recent_` with one assignment.

### 4.6 `BadStack` (Part B)

`badstack.h` builds a stack by inheriting from `Deque`:

```cpp
// DELIBERATELY WRONG -- this file exists to be broken.
class BadStack : public Deque {
public:
    void push(int v)          { pushFront(v); }
    bool pop (int *out)       { return popFront(out); }
    bool top (int *out) const { return front(out); }
};
```

In `main.cpp`, write

```cpp
static void breakBadStack(BadStack &s)
```

which, **using only public members**, leaves `s` in a state where its next `pop()` does not return the last value `push()`ed. Then write `test_badstack_violation`, which pushes a few values, prints `s` with `printForward()` before and after the call (`BadStack` inherited that too), and then pops everything, printing each value.

Then answer in `WRITEUP.md`:

1. Which inherited member did you call, and how does the result break "the last value pushed is the first value popped"?
2. Lab 4's `Stack` makes that call impossible. Name the two things in `stack.h` that do it: what composition does not give `Stack`, and what `private:` on `d_` adds.
3. Public inheritance promises that every `BadStack` is a `Deque`, so every `Deque` operation is a `BadStack` operation. In one sentence: why is that promise wrong for a stack?

`BadStack` compiles, and every call on it is legal C++. The mistake is in the design.

## 5. The Makefile

Write it yourself, modeled on Lab 4's. It must have:

- `all` (the default), which builds `./lab5test` from `main.o`, `named.o`, `item.o`, `monster.o`, `deque.o` and `inventory.o`;
- **one rule per object file**, each listing every header it depends on, directly or indirectly: `item.o` depends on `item.cpp`, `item.h` **and `named.h`**, because `item.h` includes it;
- `test`, which builds and runs `./lab5test`;
- `clean`, which removes the object files and the executables;
- `CXXFLAGS = -std=c++11 -Wall -Wextra -Werror -g`.

Add these two targets as well, for the provided tests (not graded):

```make
LIBOBJS = named.o item.o monster.o deque.o inventory.o

public_tests: tests/public_tests.cpp $(LIBOBJS) named.h item.h \
              monster.h deque.h badstack.h inventory.h
	$(CXX) $(CXXFLAGS) -I. -o public_tests tests/public_tests.cpp \
	    $(LIBOBJS)

check: public_tests
	./public_tests
```

## 6. Testing

```
make test                      # your tests (main.cpp) -> ./lab5test
make check                     # every provided test
./public_tests named           # one group: named, item, monster,
                               # deque, inv
valgrind --leak-check=full --show-leak-kinds=all ./lab5test
valgrind --leak-check=full --show-leak-kinds=all ./public_tests
```

The provided suite runs the same kinds of checks the autograder runs. Passing it is necessary, not sufficient: it does not check your Makefile, your writeup or the experiment, and the autograder runs several sequences that are not in it.

A test that passes without valgrind and fails under it has still failed. Two likely bugs in this lab cause no failed check at all, only valgrind errors: `setName` releasing before it copies, and a `Named::operator=` that forgets to release the old array. Run the growth path under valgrind specifically: a leaking `Named::operator=` leaks one string per item copied.

Your `main.cpp` must exercise, at minimum:

- copying and assigning an `Item` and a `Monster`;
- **self-assignment** of a `Named`, an `Item`, a `Monster`, a `Deque` and an `Inventory`;
- copying an `Inventory` of at least 10 items, destroying the original, and reading the copy;
- growth through at least two doublings;
- `removeBySku` on the first, a middle and the last item, and on an absent sku;
- the Part B violation.

## 7. Allowed and not allowed

Allowed: references, copy constructors, `operator=`, `<cstring>` (`std::strlen`, `std::strcpy`, `std::strcmp`), `std::cout`. Copying objects is allowed and expected.

| Not allowed | Why |
|---|---|
| `virtual` (it's ok if you don't know what this is) | runtime polymorphism is not part of this course |
| `std::string` | `Named` is the string-owning class you are building |
| `std::vector` or any other standard-library container | `Inventory` is the growable array you are building |
| `std::unique_ptr`, `std::shared_ptr` (again, ok if you don't know these) | the ownership is yours to manage by hand |
| `malloc` / `free` / `strdup` | memory from `new[]` is released with `delete[]` |
| changing any header marked **Do not modify** | the autograder compiles against them |

The autograder scans every `.h` and `.cpp` you submit for everything in this table, with comments and string literals blanked out first, so the words in a comment are fine. A finding costs the "only allowed constructs" points **and halves your score on Parts A and C**.

## 8. Submission and grading

Submit: `named.h` · `named.cpp` · `item.h` · `item.cpp` · `monster.h` · `monster.cpp` · `deque.h` · `deque.cpp` · `stack.h` · `badstack.h` · `inventory.h` · `inventory.cpp` · `main.cpp` · `Makefile` · `WRITEUP.md` · `AI_LOG.md`

| | |
|---|---|
| `Named`: Rule of Three, deep copy, `setName` safe when given its own name | 20 |
| `Item` / `Monster`: base handed to `Named` in every constructor and in `operator=` | 10 |
| `Deque` copy constructor and `operator=` | 10 |
| `Inventory`: add / remove / find, growth by doubling, Rule of Three through the element type, `recent_` copied with it | 25 |
| Compiles clean + `Makefile` + only allowed constructs + headers unchanged | 5 |
| Part A experiment, both variants performed and reported | 10 |
| Part B: violation demonstrated in `main.cpp` + three questions | 10 |
| Writeup: `protected`, `Item`'s copy operations, default-constructor trade-off, `recent_` | 10 |
| **Valgrind: any leak or invalid access** | **−20** |

The first five lines (70 points) are awarded by the autograder, which you may run as often as you like before the deadline. The experiment, Part B and the writeup (30 points) are read by a human. Valgrind is run twice — on the grader's own memory test against your classes, and on your `./lab5test` — and a leak or invalid access in either costs the 20 points once.

## 9. Checklist before you submit

- [ ] `make` produces zero warnings with `-Wall -Wextra -Werror`, and builds `./lab5test`
- [ ] `make check` passes, and both valgrind runs report 0 errors and 0 bytes lost
- [ ] no header marked **Do not modify** has changed
- [ ] the `: Named()` placeholders in `item.cpp` and `monster.cpp` are gone
- [ ] every derived copy constructor names `Named(other)`; every derived `operator=` calls `Named::operator=(other)`
- [ ] `x.setName(x.name())` and `a = a` work for every class
- [ ] `~Inventory` uses `delete[]`, and contains nothing for `recent_`
- [ ] `item.cpp` is restored after the experiment
- [ ] nothing from the "Not allowed" table appears in your code
- [ ] `WRITEUP.md` (Parts A, B, C and the valgrind summary) and `AI_LOG.md` are filled in

## 10. AI policy for this lab

Standard course policy: log substantive assistant use in `AI_LOG.md` (what you asked, what you got, what you changed and why).

**Expect a specific and consistent failure.** Ask an assistant for a C++ class hierarchy and it will give you `virtual ~Named();`, a pure-virtual `describe()`, `std::string` instead of `char *`, and a `std::vector<std::unique_ptr<Named>>` holding both derived types. Every one of those is outside this lab, and the last two remove the lesson entirely: Part A is about what inheritance means for ownership, and Part C is about managing the array yourself. State the constraints in the prompt (*"C++11, no virtual, no std::string, no smart pointers, no STL containers, Rule of Three by hand"*) and check the output against them every few edits.

**A good use: Part B.** Once your `breakBadStack` works, ask an assistant to list every public member of `Deque` that a `BadStack` client could use to break the stack's last-in, first-out order. It will produce a longer list than you did. Checking whether each one really breaks the order is the reasoning the writeup asks for; record in `AI_LOG.md` which of its findings were real.

**A bad use:** asking it why composition beats inheritance here. You will get a fluent, general answer about the Liskov substitution principle that has nothing to do with your code, and the writeup asks specifically what *your* `BadStack` did.
