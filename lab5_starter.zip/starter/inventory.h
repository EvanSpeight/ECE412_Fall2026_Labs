/* ------------------------------------------------------------------ *
 * inventory.h -- ECE 412 Lab 5, Part C: an Inventory OWNS an array of
 *                Items and HAS-A Deque of recent pickups.
 *
 * DO NOT MODIFY THIS FILE.  The autograder compiles its own test
 * programs against these exact declarations, including the private
 * section.
 * ------------------------------------------------------------------ */
#ifndef INVENTORY_H
#define INVENTORY_H

#include <cstddef>
#include "deque.h"
#include "item.h"

class Inventory {
public:
    Inventory(std::size_t initialCap = 4);   // 0 is treated as 1
    ~Inventory();
    Inventory(const Inventory &other);
    Inventory &operator=(const Inventory &other);

    bool add(const Item &it);             // copies it into the array;
                                          // false (and no change) if
                                          // that sku is already present
    bool removeBySku(int sku);            // false if absent; keeps the
                                          // order of the others
    const Item *findBySku(int sku) const; // NULL if absent
    bool mostRecentPickup(int *skuOut) const;  // sku of the most
                                          // recently added item still
                                          // present; false if none

    std::size_t size()     const;
    std::size_t capacity() const;
    void        print()    const;

private:
    Item       *items_;      // owned: new[] / delete[], grows by doubling
    std::size_t size_;       // items in use: items_[0] .. items_[size_-1]
    std::size_t capacity_;   // length of the items_ array
    Deque       recent_;     // skus, most recent pickup at the front
};

#endif /* INVENTORY_H */
