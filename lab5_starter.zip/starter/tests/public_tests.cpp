/* ------------------------------------------------------------------ *
 * tests/public_tests.cpp -- ECE 412 Lab 5 provided test suite.
 *
 *   build:  g++ -std=c++11 -Wall -Wextra -Werror -g -I. \
 *               tests/public_tests.cpp named.o item.o monster.o \
 *               deque.o inventory.o -o public_tests
 *   run:    ./public_tests            (every test)
 *           ./public_tests named      (only the Named tests; also
 *                                      item, monster, deque, inv)
 *   memory: valgrind --leak-check=full ./public_tests
 *
 * (Once your Makefile has a "check" target, those become "make
 * check".)
 *
 * These are the same KINDS of tests the autograder runs.  They are
 * not the whole autograder: passing all of them is necessary, not
 * sufficient.  They do not check your Makefile, your writeup, or the
 * Part A experiment, and the autograder runs several sequences that
 * are deliberately not in here.
 *
 * You do not submit this file, and you should not edit it.  Your own
 * tests belong in main.cpp.
 * ------------------------------------------------------------------ */
#include <cstdio>
#include <cstring>
#include <iostream>
#include <unistd.h>     /* dup, dup2 -- used only to capture stdout */

#include "named.h"
#include "item.h"
#include "monster.h"
#include "deque.h"
#include "badstack.h"
#include "inventory.h"

/* ---- tiny harness ----------------------------------------------- */

static int g_checks = 0;
static int g_fails  = 0;
static const char *g_test = "";

static void ck(bool cond, const char *what)
{
    g_checks++;
    if (!cond) {
        g_fails++;
        printf("  FAIL  [%s] %s\n", g_test, what);
    }
}

static void begin(const char *name)
{
    g_test = name;
    printf("%s\n", name);
}

static bool same(const char *a, const char *b)
{
    return a != NULL && b != NULL && strcmp(a, b) == 0;
}

/* ---- capture what printForward / printBackward write ------------- */

static void squeeze(char *s)
{
    int i = 0, j = 0, sp = 0;
    while (s[i] != '\0') {
        if (s[i] == ' ' || s[i] == '\t' || s[i] == '\n' ||
            s[i] == '\r') {
            sp = 1;
        } else {
            if (sp && j > 0) s[j++] = ' ';
            sp = 0;
            s[j++] = s[i];
        }
        i++;
    }
    s[j] = '\0';
}

static void capture(const Deque &d, bool forward, char *buf, size_t cap)
{
    const char *path = "._print_capture.tmp";
    int   saved;
    FILE *f;
    long  n;

    buf[0] = '\0';
    f = fopen(path, "w+");
    if (f == NULL) return;

    std::cout.flush();
    fflush(stdout);
    saved = dup(1);
    if (saved < 0) { fclose(f); return; }
    if (dup2(fileno(f), 1) < 0) { close(saved); fclose(f); return; }

    if (forward) d.printForward();
    else         d.printBackward();

    std::cout.flush();
    fflush(stdout);
    dup2(saved, 1);
    close(saved);

    fseek(f, 0, SEEK_END);
    n = ftell(f);
    if (n < 0) n = 0;
    if ((size_t)n > cap - 1) n = (long)cap - 1;
    fseek(f, 0, SEEK_SET);
    if (fread(buf, 1, (size_t)n, f) != (size_t)n) { /* short read */ }
    buf[n] = '\0';
    fclose(f);
    remove(path);
    squeeze(buf);
}

static void ck_print(const Deque &d, bool forward, const char *expect)
{
    char got[4096];
    capture(d, forward, got, sizeof got);
    g_checks++;
    if (strcmp(got, expect) != 0) {
        g_fails++;
        printf("  FAIL  [%s] %s\n", g_test,
               forward ? "printForward" : "printBackward");
        printf("          expected: %s\n", expect);
        printf("          got:      %s\n", got);
    }
}

static void ck_both(const Deque &d, const char *fwd, const char *bwd)
{
    ck_print(d, true,  fwd);
    ck_print(d, false, bwd);
}

/* ================================================================== *
 * Named
 * ================================================================== */

static void t_named_basic(void)
{
    begin("t_named_basic");

    Named a("goblin");
    Named b;
    Named c(NULL);

    ck(same(a.name(), "goblin"),  "name() is the constructor argument");
    ck(a.nameLength() == 6,       "nameLength 6");
    ck(same(b.name(), ""),        "default name is \"\"");
    ck(b.nameLength() == 0,       "default nameLength 0");
    ck(same(c.name(), ""),        "NULL is treated as \"\"");

    a.setName("hobgoblin");
    ck(same(a.name(), "hobgoblin"), "setName longer");
    a.setName("orc");
    ck(same(a.name(), "orc"),       "setName shorter");
    a.setName(NULL);
    ck(same(a.name(), ""),          "setName(NULL) gives \"\"");
}

/* The constructor must copy the characters, not keep the pointer. */
static void t_named_ctor_deep(void)
{
    begin("t_named_ctor_deep -- the constructor copies the string");

    char buf[16];
    strcpy(buf, "rope");
    Named a(buf);
    strcpy(buf, "XXXX");
    ck(same(a.name(), "rope"), "changing the caller's buffer changes "
                               "nothing");
}

static void t_named_copy(void)
{
    begin("t_named_copy -- copy, then destroy the original");

    Named *orig = new Named("lantern");
    Named  copy(*orig);
    ck(copy.name() != orig->name(), "copy has its own buffer");
    delete orig;
    ck(same(copy.name(), "lantern"), "copy survives the original");

    copy.setName("torch");
    Named copy2(copy);
    copy2.setName("candle");
    ck(same(copy.name(), "torch"),   "setName on a copy leaves the "
                                     "source alone");
}

static void t_named_assign(void)
{
    begin("t_named_assign");

    Named a("short");
    Named b("a considerably longer name");
    Named c("mid");

    a = b;
    ck(same(a.name(), b.name()), "a = b copies the name");
    ck(a.name() != b.name(),     "a and b have separate buffers");
    b.setName("changed");
    ck(same(a.name(), "a considerably longer name"),
       "changing b afterwards leaves a alone");

    b = c;
    ck(same(b.name(), "mid"),    "longer to shorter");

    a = b = c;
    ck(same(a.name(), "mid") && same(b.name(), "mid"),
       "chained a = b = c");
}

static void t_named_self(void)
{
    begin("t_named_self -- self-assignment and setName(name())");

    Named a("amulet");
    Named &alias = a;
    a = alias;
    ck(same(a.name(), "amulet"), "a = a keeps the name");

    a.setName(a.name());
    ck(same(a.name(), "amulet"), "a.setName(a.name()) keeps the name");
}

/* ================================================================== *
 * Item and Monster
 * ================================================================== */

static void t_item_basic(void)
{
    begin("t_item_basic");

    Item it("arrow", 7, 20);
    ck(same(it.name(), "arrow"), "name");
    ck(it.sku() == 7,            "sku");
    ck(it.qty() == 20,           "qty");

    it.addQty(5);
    ck(it.qty() == 25,           "addQty(5)");
    it.addQty(-30);
    ck(it.qty() == 0,            "qty does not go below 0");

    Item d;
    ck(same(d.name(), "") && d.sku() == 0 && d.qty() == 0,
       "default Item is \"\", 0, 0");
}

static void t_item_copy(void)
{
    begin("t_item_copy -- copy, then destroy the original");

    Item *orig = new Item("shield", 42, 1);
    Item  copy(*orig);
    delete orig;
    ck(same(copy.name(), "shield"), "copy has the name");
    ck(copy.sku() == 42 && copy.qty() == 1, "copy has sku and qty");

    Item copy2(copy);
    copy2.setName("buckler");
    copy2.addQty(3);
    ck(same(copy.name(), "shield") && copy.qty() == 1,
       "changing a copy leaves the source alone");
}

static void t_item_assign(void)
{
    begin("t_item_assign -- the base part must be assigned too");

    Item a("potion", 1, 3);
    Item b("elixir of very long naming", 2, 9);

    a = b;
    ck(same(a.name(), "elixir of very long naming"),
       "operator= copies the name (Named::operator= was called)");
    ck(a.sku() == 2 && a.qty() == 9, "operator= copies sku and qty");
    b.setName("x");
    ck(same(a.name(), "elixir of very long naming"),
       "a and b are independent");

    Item &alias = a;
    a = alias;
    ck(same(a.name(), "elixir of very long naming") && a.sku() == 2,
       "self-assignment");
}

static void t_monster(void)
{
    begin("t_monster");

    Monster m("troll", 10, 4);
    ck(same(m.name(), "troll"), "name");
    ck(m.hp() == 10 && m.damage() == 4 && m.alive(), "hp, damage, "
                                                     "alive");
    m.takeDamage(0);
    m.takeDamage(-5);
    ck(m.hp() == 10, "takeDamage(n <= 0) does nothing");
    m.takeDamage(7);
    ck(m.hp() == 3 && m.alive(),  "hp 3");
    m.takeDamage(50);
    ck(m.hp() == 0 && !m.alive(), "hp stops at 0");

    Monster *orig = new Monster("wyvern", 30, 8);
    Monster  copy(*orig);
    delete orig;
    ck(same(copy.name(), "wyvern") && copy.hp() == 30,
       "copy survives the original");

    m = copy;
    ck(same(m.name(), "wyvern") && m.hp() == 30 && m.damage() == 8,
       "operator= copies name, hp, damage");
    Monster &alias = m;
    m = alias;
    ck(same(m.name(), "wyvern"), "self-assignment");
}

/* ================================================================== *
 * Deque: the new copy operations
 * ================================================================== */

static void t_deque_copy(void)
{
    begin("t_deque_copy");

    Deque a;
    for (int i = 1; i <= 5; ++i) a.pushBack(i);

    Deque b(a);
    ck(b.size() == 5, "copy has size 5");
    ck_both(b, "[ 1 <-> 2 <-> 3 <-> 4 <-> 5 ]",
               "[ 5 <-> 4 <-> 3 <-> 2 <-> 1 ]");

    int v = 0;
    b.popFront(&v);
    b.pushBack(9);
    ck_both(a, "[ 1 <-> 2 <-> 3 <-> 4 <-> 5 ]",
               "[ 5 <-> 4 <-> 3 <-> 2 <-> 1 ]");
    ck_both(b, "[ 2 <-> 3 <-> 4 <-> 5 <-> 9 ]",
               "[ 9 <-> 5 <-> 4 <-> 3 <-> 2 ]");

    Deque e;
    Deque f(e);
    ck(f.empty(), "copy of an empty deque is empty");
    f.pushFront(1);
    ck_both(f, "[ 1 ]", "[ 1 ]");
}

static void t_deque_assign(void)
{
    begin("t_deque_assign");

    Deque a, b, c;
    for (int i = 1; i <= 3; ++i) a.pushBack(i);
    for (int i = 0; i < 6; ++i)  b.pushBack(100 + i);

    b = a;                                  /* longer <- shorter */
    ck(b.size() == 3, "size 3");
    ck_both(b, "[ 1 <-> 2 <-> 3 ]", "[ 3 <-> 2 <-> 1 ]");

    c.pushBack(7);
    a = c;                                  /* shorter */
    ck_both(a, "[ 7 ]", "[ 7 ]");

    Deque empty;
    b = empty;
    ck(b.empty(), "assigning an empty deque empties it");
    b.pushBack(4);
    ck_both(b, "[ 4 ]", "[ 4 ]");

    Deque &alias = c;
    c = alias;
    ck_both(c, "[ 7 ]", "[ 7 ]");

    a = b = c;
    ck_both(a, "[ 7 ]", "[ 7 ]");
}

/* ================================================================== *
 * BadStack (compiled here to show it does compile)
 * ================================================================== */

static void t_badstack_compiles(void)
{
    begin("t_badstack_compiles -- its own three members behave");

    BadStack s;
    int v = 0;
    s.push(1);
    s.push(2);
    ck(s.top(&v) && v == 2, "top 2");
    ck(s.pop(&v) && v == 2, "pop 2");
    ck(s.pop(&v) && v == 1, "pop 1");
    ck(!s.pop(&v),          "empty");
}

/* ================================================================== *
 * Inventory
 * ================================================================== */

static void t_inv_empty(void)
{
    begin("t_inv_empty");

    Inventory inv;
    int s = -1;
    ck(inv.size() == 0,                 "size 0");
    ck(inv.capacity() == 4,             "default capacity 4");
    ck(inv.findBySku(1) == NULL,        "find -> NULL");
    ck(!inv.removeBySku(1),             "remove -> false");
    ck(!inv.mostRecentPickup(&s) && s == -1,
       "mostRecentPickup -> false, *skuOut untouched");

    Inventory one(0);
    ck(one.capacity() == 1,             "Inventory(0) has capacity 1");
    ck(one.add(Item("a", 1, 1)) && one.add(Item("b", 2, 1)),
       "capacity 1 still grows");
    ck(one.capacity() == 2,             "1 -> 2");
}

static void t_inv_add_find(void)
{
    begin("t_inv_add_find");

    Inventory inv;
    Item sword("sword", 10, 1);
    ck(inv.add(sword),                  "add sword");
    ck(inv.add(Item("bow", 20, 1)),     "add bow");
    ck(inv.add(Item("rope", 30, 2)),    "add rope");
    ck(inv.size() == 3,                 "size 3");

    const Item *p = inv.findBySku(20);
    ck(p != NULL && same(p->name(), "bow"), "find bow");
    ck(inv.findBySku(99) == NULL,       "find absent -> NULL");

    ck(!inv.add(Item("other sword", 10, 5)), "duplicate sku -> false");
    ck(inv.size() == 3,                 "duplicate changes nothing");
    p = inv.findBySku(10);
    ck(p != NULL && same(p->name(), "sword") && p->qty() == 1,
       "original sword intact");

    sword.setName("broken sword");
    p = inv.findBySku(10);
    ck(p != NULL && same(p->name(), "sword"),
       "add stored a copy, not the caller's object");
}

static void t_inv_growth(void)
{
    begin("t_inv_growth -- two doublings, names intact");

    Inventory inv;
    char name[32];
    for (int i = 0; i < 9; ++i) {
        snprintf(name, sizeof name, "item-number-%d", i);
        ck(inv.add(Item(name, 100 + i, i)), "add");
    }
    ck(inv.size() == 9,         "size 9");
    ck(inv.capacity() == 16,    "4 -> 8 -> 16");

    bool ok = true;
    for (int i = 0; i < 9; ++i) {
        snprintf(name, sizeof name, "item-number-%d", i);
        const Item *p = inv.findBySku(100 + i);
        if (p == NULL || !same(p->name(), name) || p->qty() != i)
            ok = false;
    }
    ck(ok, "every item survived both copies");
}

static void t_inv_remove(void)
{
    begin("t_inv_remove -- first, middle, last, absent");

    Inventory inv;
    for (int i = 1; i <= 5; ++i) {
        char name[8];
        snprintf(name, sizeof name, "n%d", i);
        inv.add(Item(name, i, 1));
    }

    ck(inv.removeBySku(1),          "remove first");
    ck(inv.removeBySku(3),          "remove middle");
    ck(inv.removeBySku(5),          "remove last");
    ck(!inv.removeBySku(3),         "remove it again -> false");
    ck(!inv.removeBySku(42),        "remove absent -> false");
    ck(inv.size() == 2,             "size 2");
    ck(inv.findBySku(2) != NULL && same(inv.findBySku(2)->name(), "n2"),
       "2 remains");
    ck(inv.findBySku(4) != NULL && same(inv.findBySku(4)->name(), "n4"),
       "4 remains");

    ck(inv.add(Item("n6", 6, 1)),   "add after removes");
    ck(inv.size() == 3,             "size 3");
}

static void t_inv_recent(void)
{
    begin("t_inv_recent -- the Deque of recent pickups");

    Inventory inv;
    int s = 0;
    inv.add(Item("a", 1, 1));
    inv.add(Item("b", 2, 1));
    inv.add(Item("c", 3, 1));
    ck(inv.mostRecentPickup(&s) && s == 3, "most recent is 3");

    inv.removeBySku(3);
    ck(inv.mostRecentPickup(&s) && s == 2, "remove 3 -> most recent 2");
    inv.removeBySku(1);
    ck(inv.mostRecentPickup(&s) && s == 2, "remove 1 -> still 2");
    inv.add(Item("d", 4, 1));
    ck(inv.mostRecentPickup(&s) && s == 4, "add 4 -> 4");
    inv.removeBySku(4);
    inv.removeBySku(2);
    ck(!inv.mostRecentPickup(&s),          "none left -> false");
}

static void t_inv_copy(void)
{
    begin("t_inv_copy -- copy 10 items, destroy the original");

    Inventory *orig = new Inventory;
    char name[32];
    for (int i = 0; i < 10; ++i) {
        snprintf(name, sizeof name, "thing-%d", i);
        orig->add(Item(name, i, i));
    }
    Inventory copy(*orig);
    delete orig;

    ck(copy.size() == 10,       "copy size 10");
    bool ok = true;
    for (int i = 0; i < 10; ++i) {
        snprintf(name, sizeof name, "thing-%d", i);
        const Item *p = copy.findBySku(i);
        if (p == NULL || !same(p->name(), name)) ok = false;
    }
    ck(ok, "every name readable after the original is gone");

    int s = -1;
    ck(copy.mostRecentPickup(&s) && s == 9,
       "the copy kept the pickup history");

    copy.removeBySku(9);
    ck(copy.mostRecentPickup(&s) && s == 8, "and it still works");
    ck(copy.add(Item("late", 50, 1)),       "the copy can grow");
}

static void t_inv_assign(void)
{
    begin("t_inv_assign");

    Inventory a, b;
    for (int i = 0; i < 6; ++i) a.add(Item("from-a", i, 1));
    b.add(Item("from-b", 99, 1));

    b = a;
    ck(b.size() == 6,                       "size 6");
    ck(b.findBySku(99) == NULL,             "old contents are gone");
    ck(b.findBySku(5) != NULL && same(b.findBySku(5)->name(), "from-a"),
       "new contents are there");
    int s = -1;
    ck(b.mostRecentPickup(&s) && s == 5,    "history copied");

    b.removeBySku(5);
    b.add(Item("only-in-b", 77, 1));
    ck(a.findBySku(5) != NULL && a.findBySku(77) == NULL,
       "a is unaffected by changes to b");

    Inventory &alias = a;
    a = alias;
    ck(a.size() == 6 && a.findBySku(0) != NULL &&
       same(a.findBySku(0)->name(), "from-a"), "self-assignment");

    Inventory small(1);
    small = a;
    ck(small.size() == 6, "assign into a smaller inventory");
}

static void t_inv_heap(void)
{
    begin("t_inv_heap -- new and delete an Inventory");

    Inventory *p = new Inventory(2);
    for (int i = 0; i < 20; ++i) p->add(Item("heap item", i, 1));
    ck(p->size() == 20, "size 20");
    delete p;
    ck(true, "delete returned");
}

/* ================================================================== */

struct Test { const char *name; void (*fn)(void); };

static const Test TESTS[] = {
    {"named_basic",     t_named_basic},
    {"named_ctor_deep", t_named_ctor_deep},
    {"named_copy",      t_named_copy},
    {"named_assign",    t_named_assign},
    {"named_self",      t_named_self},
    {"item_basic",      t_item_basic},
    {"item_copy",       t_item_copy},
    {"item_assign",     t_item_assign},
    {"monster",         t_monster},
    {"deque_copy",      t_deque_copy},
    {"deque_assign",    t_deque_assign},
    {"badstack",        t_badstack_compiles},
    {"inv_empty",       t_inv_empty},
    {"inv_add_find",    t_inv_add_find},
    {"inv_growth",      t_inv_growth},
    {"inv_remove",      t_inv_remove},
    {"inv_recent",      t_inv_recent},
    {"inv_copy",        t_inv_copy},
    {"inv_assign",      t_inv_assign},
    {"inv_heap",        t_inv_heap},
};

/* ./public_tests            runs every test
 * ./public_tests named      runs only the tests whose name starts with
 *                           "named" (also: item, monster, deque, inv) */
int main(int argc, char **argv)
{
    const char *prefix = (argc > 1) ? argv[1] : "";
    int ran = 0;
    for (const Test &t : TESTS) {
        if (strncmp(t.name, prefix, strlen(prefix)) == 0) {
            t.fn();
            ran++;
        }
    }
    if (ran == 0) {
        printf("no test name starts with \"%s\"\n", prefix);
        return 2;
    }

    printf("\n----------------------------------------\n");
    printf("%d tests, %d checks, %d failures\n", ran, g_checks, g_fails);
    if (g_fails == 0)
        printf("all selected tests passed "
               "(now run them under valgrind)\n");
    return (g_fails == 0) ? 0 : 1;
}
