/* ------------------------------------------------------------------ *
 * monster.cpp -- ECE 412 Lab 5, Part A.  Your implementation of
 *                monster.h.  Same pattern as item.cpp.
 * ------------------------------------------------------------------ */
#include "monster.h"

Monster::Monster(const char *name, int hp, int damage)
{
    /* TODO: a negative hp is stored as 0 */
    (void)name; (void)hp; (void)damage;
}

/* PLACEHOLDER base initializer -- see the note in item.cpp. */
Monster::Monster(const Monster &other) : Named()
{
    /* TODO */
    (void)other; /* avoid unused parameter warning */
}

Monster &Monster::operator=(const Monster &other)
{
    /* TODO */
    (void)other; /* avoid unused parameter warning */
    return *this;
}

int Monster::hp() const
{
    /* TODO */
    return 0;
}

int Monster::damage() const
{
    /* TODO */
    return 0;
}

bool Monster::alive() const
{
    /* TODO */
    return false;
}

void Monster::takeDamage(int n)
{
    /* TODO: n <= 0 does nothing; hp never goes below 0 */
    (void)n; /* avoid unused parameter warning */
}
