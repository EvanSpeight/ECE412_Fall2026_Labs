/* ------------------------------------------------------------------ *
 * stack.h -- ECE 412 Lab 5.  Lab 4's Stack, unchanged: built by
 *            composition.  Compare it with badstack.h.
 *
 * DO NOT MODIFY THIS FILE.
 * ------------------------------------------------------------------ */
#ifndef STACK_H
#define STACK_H

#include <cstddef>
#include "deque.h"

class Stack {
public:
    void push(int v)          { d_.pushFront(v); }
    bool pop (int *out)       { return d_.popFront(out); }
    bool top (int *out) const { return d_.front(out); }
    std::size_t size()  const { return d_.size(); }
    bool        empty() const { return d_.empty(); }
private:
    Deque d_;              // a Stack contains a Deque
};

#endif /* STACK_H */
