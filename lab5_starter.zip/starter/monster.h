/* ------------------------------------------------------------------ *
 * monster.h -- ECE 412 Lab 5: a Monster is a Named thing with hit
 *              points and a damage value.
 *
 * DO NOT MODIFY THIS FILE.
 * ------------------------------------------------------------------ */
#ifndef MONSTER_H
#define MONSTER_H

#include "named.h"

class Monster : public Named {
public:
    Monster(const char *name, int hp, int damage);
    Monster(const Monster &other);
    Monster &operator=(const Monster &other);

    int  hp() const;
    int  damage() const;
    bool alive() const;                   // hp > 0
    void takeDamage(int n);               // n <= 0 does nothing; hp
                                          // never goes below 0
private:
    int hp_;
    int damage_;
};

#endif /* MONSTER_H */
