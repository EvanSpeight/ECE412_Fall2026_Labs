/* ------------------------------------------------------------------ *
 * inventory.cpp -- ECE 412 Lab 5, Part C.  Your implementation of
 *                  inventory.h.
 *
 * Invariants to keep true before and after every public function:
 *   I1. items_ points at an array of capacity_ Items from new[]
 *   I2. 0 <= size_ <= capacity_, and capacity_ >= 1
 *   I3. no two of items_[0] .. items_[size_-1] share a sku
 *   I4. recent_ holds exactly the skus in items_[0 .. size_-1],
 *       most recently added at the front
 *
 * recent_ is a Deque held by value.  Write no cleanup code for it.
 * ------------------------------------------------------------------ */
#include <iostream>

#include "inventory.h"

/* ---- lifetime ---------------------------------------------------- */

Inventory::Inventory(std::size_t initialCap)
{
    /* TODO: initializer list in declaration order; a capacity of 0
     * becomes 1.  Then allocate items_ with new[]. */
    (void)initialCap; /* avoid unused parameter warning */
}

Inventory::~Inventory()
{
    /* TODO: release items_.  Nothing for recent_ -- WRITEUP.md asks
     * you why. */
}

Inventory::Inventory(const Inventory &other)
{
    /* TODO: a new array of other.capacity_ Items; copy size_ of them.
     * recent_ is copied in the initializer list. */
    (void)other; /* avoid unused parameter warning */
}

Inventory &Inventory::operator=(const Inventory &other)
{
    /* TODO: self-assignment guard.  */
    (void)other; /* avoid unused parameter warning */
    return *this;
}

/* ---- contents ---------------------------------------------------- */

bool Inventory::add(const Item &it)
{
    /* TODO: false if it.sku() is already present.  Grow by doubling
     * when full.  */
    (void)it; /* avoid unused parameter warning */
    return false;
}

bool Inventory::removeBySku(int sku)
{
    /* TODO: false if absent.  Shift the later items down one slot so
     * the order is kept, and remove the sku from recent_. */
    (void)sku; /* avoid unused parameter warning */
    return false;
}

const Item *Inventory::findBySku(int sku) const
{
    /* TODO: a pointer into items_, or NULL */
    (void)sku; /* avoid unused parameter warning */
    return NULL;
}

bool Inventory::mostRecentPickup(int *skuOut) const
{
    /* TODO: one line, through recent_.  false (and *skuOut
     * untouched) if empty. */
    (void)skuOut; /* avoid unused parameter warning */
    return false;
}

/* ---- observers --------------------------------------------------- */

std::size_t Inventory::size() const
{
    /* TODO */
    return 0;
}

std::size_t Inventory::capacity() const
{
    /* TODO */
    return 0;
}

void Inventory::print() const
{
    /* TODO: your format; it is not autograded.  One line per item
     * showing sku, name and qty is enough. */
}
