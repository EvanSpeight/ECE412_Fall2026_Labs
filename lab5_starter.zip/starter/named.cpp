/* ------------------------------------------------------------------ *
 * named.cpp -- ECE 412 Lab 5, Part A.  Your implementation of named.h.
 *
 * Named owns name_, so it needs all three: destructor, copy
 * constructor, copy assignment.
 *
 * Invariant to keep true before and after every public function:
 *   name_ points at a NUL-terminated array from new[] that this
 *   object, and only this object, owns.  It is never NULL.
 *
 * Allowed: new[]/delete[], std::strlen, std::strcpy (<cstring>).
 * Not allowed: malloc/free, strdup, std::string.
 * ------------------------------------------------------------------ */
#include <cstring>

#include "named.h"

/* A helper you may find useful: allocate with new[] and copy s into
 * it, treating NULL as "".  Write it once; every constructor and
 * setName can use it.  (static: visible only in this file.) */
/* static char *dupString(const char *s) { ... } */

Named::Named()
{
    /* TODO: name_ owns a fresh copy of "" */
}

Named::Named(const char *name)
{
    /* TODO: name_ owns a fresh copy of name ("" if name is NULL) */
    (void)name; /* avoid unused parameter warning */
}

Named::~Named()
{
    /* TODO: new[] is released with delete[] */
}

Named::Named(const Named &other)
{
    /* TODO: deep copy -- a new array, not other's pointer */
    (void)other; /* avoid unused parameter warning */
}

Named &Named::operator=(const Named &other)
{
    /* TODO: a = a must leave a unchanged.  Release the old array
     * exactly once.  Return *this. */
    (void)other; /* avoid unused parameter warning */
    return *this;
}

const char *Named::name() const
{
    /* TODO */
    return "";
}

void Named::setName(const char *name)
{
    /* TODO: x.setName(x.name()) must work.  name may point INTO
     * name_, so copy before you release. */
    (void)name; /* avoid unused parameter warning */
}

std::size_t Named::nameLength() const
{
    /* TODO */
    return 0;
}
