# Lab 5 writeup -- <your name>, <your EID>

Delete the bracketed instructions as you go. Keep each part short and about your own code.

## Part A -- Named, Item, Monster

**`protected` vs. `private`.**

[`name_` is `protected`. Nothing in `Item` or `Monster` needs it, because `name()` and `setName()` cover everything they do. What can a derived class do with a `protected` member that it cannot do with a `private` one? What does that cost if `Named` later changes how it stores the name? Would `private` have been the better choice here?]

**Does `Item` need its own copy constructor and `operator=`?**

[`Item` adds two `int`s and no owned memory. If `item.h` declared no copy constructor and no `operator=`, would the ones the compiler writes be correct? Say what the compiler-written copy constructor does with the `Named` part of an `Item`. Then say what you ran to check, and what it printed.]

**The experiment.**

[Variant 1: the copy constructor without `Named(other)`. Does `make` succeed with the course flags? Quote the message. Then build without `-Wextra` and report what `copy.name()` returns and what valgrind reports.]

[Variant 2: `operator=` without `Named::operator=(other)`. Does it compile? What does `a.name()` return after `a = b`? What does valgrind report?]

[One or two sentences: which of the two mistakes is more dangerous, and why?]

## Part B -- BadStack

[Quote `breakBadStack` and paste the before/after output.]

1. [Which inherited member did you call, and how does the result break "the last value pushed is the first value popped"?]
2. [`Stack` makes that call impossible. Name the two things in `stack.h` that do it: what composition does not give `Stack`, and what `private:` on `d_` adds.]
3. [Public inheritance promises that every `BadStack` is a `Deque`, so every `Deque` operation is a `BadStack` operation. In one sentence: why is that promise wrong for a stack?]

## Part C -- Inventory

**Default constructors.**

[`new Item[n]` needs `Item()`, which needs `Named()`. The alternative design stores `Item *` pointers, one `new Item(...)` per item. Name one cost of each design.]

**`recent_`.**

[`~Inventory` contains no code for `recent_`, and valgrind reports its nodes freed. Which function frees them, and does it run before or after the body of `~Inventory`? Your copy constructor names `recent_` once. Which `Deque` function does that call, and what would happen with Lab 4's `Deque`, which had no copy constructor of its own?]

## valgrind

[Paste the HEAP SUMMARY and ERROR SUMMARY lines from `valgrind --leak-check=full --show-leak-kinds=all ./lab5test`.]

```
```
