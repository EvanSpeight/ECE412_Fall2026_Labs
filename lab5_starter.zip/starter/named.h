/* ------------------------------------------------------------------ *
 * named.h -- ECE 412 Lab 5: a base class that owns a heap string.
 *
 * DO NOT MODIFY THIS FILE.  The autograder compiles its own test
 * programs against these exact declarations, including the protected
 * section.
 * ------------------------------------------------------------------ */
#ifndef NAMED_H
#define NAMED_H

#include <cstddef>

class Named {
public:
    Named();                              // the empty name ""
    Named(const char *name);              // deep-copies name; NULL is
                                          // treated as ""
    ~Named();
    Named(const Named &other);            // Rule of Three
    Named &operator=(const Named &other);

    const char *name() const;             // borrowed; caller must not
                                          // free or keep it
    void        setName(const char *name);   // NULL is treated as ""
    std::size_t nameLength() const;

protected:
    char *name_;                          // owned; allocated with new[]
                                          // and never NULL
};

#endif /* NAMED_H */
