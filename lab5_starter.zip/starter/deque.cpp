/* ------------------------------------------------------------------ *
 * deque.cpp -- ECE 412 Lab 5.  Your Lab 4 Deque, plus two functions.
 *
 * START HERE: replace the Lab 4 stubs below with your Lab 4 code.
 * (Or replace this whole file with your Lab 4 deque.cpp and move the
 * two NEW functions into it.)  Fix anything Lab 4's grader or
 * valgrind found first: Inventory and BadStack are built on this
 * class, and a broken Deque fails tests in Part C that are not about
 * the Deque.
 *
 * NEW this week: the copy constructor and operator=.  Lab 4 told you
 * not to copy a Deque because the compiler-written copy copies the
 * pointers.  These two make a copy own its own nodes.
 *
 * Invariants to keep true before and after every public function:
 *   I1. head_ == NULL  <=>  tail_ == NULL  <=>  size_ == 0
 *   I2. head_->prev == NULL  and  tail_->next == NULL
 *   I3. for every node n with a next:  n->next->prev == n
 *   I4. size_ is the number of nodes reachable from head_
 * ------------------------------------------------------------------ */
#include <iostream>

#include "deque.h"

/* ---- lifetime ---------------------------------------------------- */

Deque::Deque()
{
    /* TODO: implement a member-initializer list */
}

Deque::~Deque()
{
    /* TODO: delete the queue */
}

/* ---- NEW: copying ------------------------------------------------ */

Deque::Deque(const Deque &other)
{
    /* TODO: copy a Deque making sure 
     * the copy has the same order and its own nodes. */
    (void)other; /* avoid unused parameter warning */
}

Deque &Deque::operator=(const Deque &other)
{
    /* TODO: a = a must leave a unchanged. */ 
    (void)other; /* avoid unused parameter warning */
    return *this;
}

void Deque::clear()
{
    /* TODO: clear the list */ 
}

/* ---- the two ends ------------------------------------------------ */

void Deque::pushFront(int v)
{
    /* TODO: new Node(v) gives a node whose prev and next are NULL. */
    (void)v; /* avoid unused parameter warning */
}

void Deque::pushBack(int v)
{
    /* TODO: the mirror image of pushFront, through tail_ */ 
    (void)v; /* avoid unused parameter warning */
}

bool Deque::popFront(int *out)
{
    /* TODO: false (and *out untouched) if empty.  Otherwise write the
     * value to *out and return true */ 
    (void)out; /* avoid unused parameter warning */
    return false;
}

bool Deque::popBack(int *out)
{
    /* TODO: the mirror image of popFront, through tail_ and prev. */
    (void)out; /* avoid unused parameter warning */
    return false;
}

bool Deque::front(int *out) const
{
    /* TODO: peek.  false if empty; nothing is removed. */
    (void)out; /* avoid unused parameter warning */
    return false;
}

bool Deque::back(int *out) const
{
    /* TODO */
    (void)out; /* avoid unused parameter warning */
    return false;
}

/* ---- search and removal ------------------------------------------ */

bool Deque::contains(int v) const
{
    /* TODO */ 
    (void)v; /* avoid unused parameter warning */
    return false;
}

bool Deque::remove(int v)
{
    /* TODO: walk to the FIRST node holding v; false if there is none.
     * Then unlink it */ 
    (void)v; /* avoid unused parameter warning */
    return false;
}

/* ---- observers --------------------------------------------------- */

std::size_t Deque::size() const
{
    /* TODO: return the maintained counter.  */
    return 0;
}

bool Deque::empty() const
{
    /* TODO */
    return true;
}

void Deque::printForward() const
{
    /* TODO: one line, then '\n':
     *     [ ]                    empty
     *     [ 1 <-> 2 <-> 3 ]      head to tail  */
}

void Deque::printBackward() const
{
    /* TODO: the same format, tail to head, following prev */ 
}
