/* ------------------------------------------------------------------ *
 * main.cpp -- your test program for Lab 5.  Builds to ./lab5test.
 *
 * This file is a CLIENT of Named, Item, Monster, Deque, BadStack and
 * Inventory.  It uses only their public member functions.
 *
 * References are allowed this week, so helpers take their argument
 * by reference: const T & to look, T & to change.  Copying is
 * allowed too -- most of these tests exist to copy things.
 *
 * Three examples are written for you.  The list at the bottom is
 * yours; WRITEUP.md quotes some of them.
 * ------------------------------------------------------------------ */
#include <cstdio>
#include <cstring>
#include <iostream>

#include "named.h"
#include "item.h"
#include "monster.h"
#include "deque.h"
#include "stack.h"
#include "badstack.h"
#include "inventory.h"

/* ---- a small test harness ---------------------------------------- */

static int g_checks = 0;
static int g_fails  = 0;

static void check(bool cond, const char *what)
{
    g_checks++;
    if (!cond) {
        g_fails++;
        std::cout << "  FAIL: " << what << '\n';
    }
}

static bool same(const char *a, const char *b)
{
    return a != NULL && b != NULL && std::strcmp(a, b) == 0;
}

/* ---- example 1: a copy must outlive its original ----------------- */

/* The original is made with new so that it can be destroyed in the
 * middle of the test.  If the copy shares the original's name_, the
 * name() call after the delete reads freed memory.  It will often
 * print the right thing anyway; valgrind will not agree. */
static void test_item_copy_outlives_original(void)
{
    std::cout << "test_item_copy_outlives_original\n";

    Item *orig = new Item("longsword", 101, 1);
    Item  copy(*orig);                 /* Item's copy constructor */
    delete orig;                       /* ~Item, then ~Named */

    check(same(copy.name(), "longsword"), "copy kept the name");
    check(copy.sku() == 101,              "copy kept the sku");
    check(copy.qty() == 1,                "copy kept the qty");
}

/* ---- example 2: setName with its own name ------------------------ */

static void test_set_name_to_itself(void)
{
    std::cout << "test_set_name_to_itself\n";

    Named n("lantern");
    n.setName(n.name());               /* argument points INTO name_ */
    check(same(n.name(), "lantern"), "name survives setName(name())");
    check(n.nameLength() == 7,       "length 7");
}

/* ---- example 3: an empty Inventory answers every question -------- */

static void test_inventory_empty(void)
{
    std::cout << "test_inventory_empty\n";

    Inventory inv;
    int s = -1;

    check(inv.size() == 0,              "size 0");
    check(inv.capacity() == 4,          "capacity 4");
    check(inv.findBySku(7) == NULL,     "find on empty -> NULL");
    check(!inv.removeBySku(7),          "remove on empty -> false");
    check(!inv.mostRecentPickup(&s),    "no pickups yet");
    check(s == -1,                      "a failed call does not write");
    inv.print();
}                                       /* ~Inventory() runs here */

/* ------------------------------------------------------------------ *
 * TODO -- write these.  The writeup and the valgrind check depend on
 * them.
 *
 *   test_named_copy_and_assign   copy, assign longer <- shorter and
 *                                shorter <- longer; then change one
 *                                and check the other did not change
 *   test_named_self_assign       a = a
 *   test_item_assign             including self-assignment; check the
 *                                NAME, not just sku and qty
 *   test_monster                 takeDamage to 0 and past it; copy,
 *                                assign, self-assign
 *   test_deque_copy              copy, then change the copy; print
 *                                both directions of both deques
 *   test_deque_assign            into a longer deque, a shorter one,
 *                                an empty one; self-assignment
 *   test_inventory_add_find      including a duplicate sku
 *   test_inventory_growth        at least two doublings; then check
 *                                every name
 *   test_inventory_remove        the first, a middle and the last
 *                                item, and an absent sku; check
 *                                mostRecentPickup after each
 *   test_inventory_copy          >= 10 items; copy; destroy the
 *                                original; read every item of the copy
 *   test_inventory_assign        including self-assignment
 *   test_badstack_violation      Part B: see below
 *
 * Part B.  Write
 *
 *     static void breakBadStack(BadStack &s)
 *
 * which, using only public members, leaves s so that its next pop()
 * does NOT return the last value push()ed.  test_badstack_violation
 * pushes a few values, prints s with printForward() before and after
 * breakBadStack, and then pops everything, printing each value.
 * ------------------------------------------------------------------ */

int main(void)
{
    test_item_copy_outlives_original();
    test_set_name_to_itself();
    test_inventory_empty();

    /* TODO: call your tests here. */

    std::cout << '\n' << g_checks << " checks, " << g_fails
              << " failures\n";
    return (g_fails == 0) ? 0 : 1;
}
