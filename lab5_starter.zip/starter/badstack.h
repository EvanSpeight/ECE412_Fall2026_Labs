/* ------------------------------------------------------------------ *
 * badstack.h -- ECE 412 Lab 5, Part B.
 *
 * DELIBERATELY WRONG.  This file exists to be broken.  It compiles,
 * and every call a client can make on it is legal C++.  The mistake
 * is in the design: a BadStack IS a Deque, so every public Deque
 * operation is also a BadStack operation.
 *
 * DO NOT MODIFY THIS FILE.  Your job is in main.cpp.
 * ------------------------------------------------------------------ */
#ifndef BADSTACK_H
#define BADSTACK_H

#include "deque.h"

class BadStack : public Deque {
public:
    void push(int v)          { pushFront(v); }
    bool pop (int *out)       { return popFront(out); }
    bool top (int *out) const { return front(out); }
};

#endif /* BADSTACK_H */
